package com.icicibank.iMobileCA.util;

import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;


public class SMSRequestService {
	private static final Logger logWriter = Logger.getLogger(SMSRequestService.class);
	
	@Resource(name = "imbcaproperties")
	private Properties properties;
	
	public boolean sendSMS(String mobileNo, String message)  throws Exception
	{
		//String message = properties.getProperty("sms.beneficiary.message");
		String appId = properties.getProperty("sms.appid");
		String dept = properties.getProperty("sms.dept");
		logWriter.info("sendSMS Service MoblieNo: "+mobileNo+"AppID : "+appId+" dept : "+dept);
		logWriter.info("Message : "+message);
		Socket socket = null;

		boolean success = true;
		BufferedWriter output;
		StringBuffer inps = new StringBuffer("");
		InputStream toServerinput = null;
		
		String strServer1 = properties.getProperty("sms.IP");//"10.24.155.68"; 
		String strPort1 = properties.getProperty("sms.Port"); //"9001"; 
		int timeoutVal =  Integer.parseInt(properties.getProperty("sms.timeout"));//30000;
		logWriter.info("SMS IP Adress: "+strServer1+" Port : "+strPort1+" timeoutVal: "+timeoutVal);
		try
		{
			logWriter.info("Step1");
			socket = new Socket(strServer1, Integer.parseInt(strPort1));
			System.out.print(" Connected with server1.  " + strServer1 );
			logWriter.info("SMS: Connected with server1.  " + strServer1 );
		        socket.setSoTimeout(timeoutVal);
//			socket = tms.createSocketConnection(socket);
			
		    logWriter.info("SMS: Connected for Socket For Sending SMS.  " );
			System.out.print(" Connected for Socket For Sending SMS.  " );
			if(socket != null)
			{
				logWriter.info("Step2");
				//int count=0;

				output = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), "8859_1"));
				inps = new StringBuffer("");
				
				output.write("CON^`!XML^`!ICICIBANK#END#");
				output.flush();
				logWriter.info("Step3");
				toServerinput = socket.getInputStream();
				int i=0;
				if ((i = toServerinput.read()) == -1)
				{
					logWriter.info("Step4 success : false");
					success = false;
				}
				else
				{
					logWriter.info("Step5");
					inps.append((char) i);
				}
				if (success && toServerinput.available() != 0)
				{
					logWriter.info("Step6");
					while ((i = toServerinput.read()) != -1)
					{
						inps.append((char) i);
						if (toServerinput.available() == 0)
						{
							logWriter.info("Step7");
							break;
						}
					}
					System.out.println("Response is "+ inps.toString());
					logWriter.info("Response is "+ inps.toString());
				}
				//ERROR = false;
				if (inps.toString().indexOf("CON!0") != 0)
				{
					logWriter.info("Step8");
					System.out.println("not connected with ISG Server");
					logWriter.info("SMS:not connected with ISG Server");
				}
				else
				{
//					     			sflag = tms.openPort(socket); //tms.openSMSPort(socket);
                         			//System.out.println(" Sending SMS Port Status.  " + sflag );
					logWriter.info("Step9");
					String alertForCustomer1 = null;
					
					//FileInputStream fstream = new FileInputStream("G:/PROJECT/Table_Partition_Test/Table_Partition_Test.csv");
					  // Get the object of DataInputStream
					  //DataInputStream in = new DataInputStream(fstream);
 
 // BufferedReader br = new BufferedReader(new InputStreamReader(in));
					  //String strLine;
					  //Read File Line By Line
					 // while ((strLine = br.readLine()) != null)   {
					//	  alertForCustomer=strLine;
					  //}
					
						logWriter.info("Before Sending SMS");
						for(int ii=0; ii<1; ii++)
						{
							java.util.Date date = new java.util.Date();
							java.text.SimpleDateFormat sdf= new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
							String dt= sdf.format(date);
							//alertForCustomer = "<DEPT> INBG</DEPT><APPID> ALERT</APPID><MOBILE>919819521923</MOBILE><DEPTMSGID>14-06-2011-SB9710415-   3</DEPTMSGID><MESSAGE>POC  from HP Team </MESSAGE><FROMDATETIME></FROMDATETIME><TODATETIME></TODATETIME><NODELIVERYTIMEFROM> 2200 </NODELIVERYTIMEFROM><NODELIVERYTIMETO> 0700 </NODELIVERYTIMETO><HTTPMODE> S </HTTPMODE><REMARKS> 108201503110 </REMARKS><REMARKS1>PSDWC</REMARKS1><REMARKS2></REMARKS2><REMARKS3></REMARKS3><TRN_GENERATE_TIMESTAMP>2014-09-29 16:37:56</TRN_GENERATE_TIMESTAMP>";
							//alertForCustomer="<DEPT>BT4</DEPT><APPID>TCHALRT</APPID><MOBILE>8297782006</MOBILE><DEPTMSGID>+ strRandom +</DEPTMSGID><MESSAGE>EAIHeartbeat Alert: ActCode 961 from IP: 10.50.37.59 Port: 5163 on 01/10/2014 11:03:10</MESSAGE><FROMDATETIME /><TODATETIME /><HTTPMODE>N</HTTPMODE> ";
							//System.out.println(" Sending SMS Packet . \n " + alertForCustomer );
						
//							System.out.println( dt );
							alertForCustomer1 = "<DEPT>"+dept+"</DEPT><APPID>"+appId+" </APPID><MOBILE> 91"+mobileNo+" </MOBILE><DEPTMSGID> "+System.currentTimeMillis()+" </DEPTMSGID><MESSAGE> "+message+" </MESSAGE><FROMDATETIME></FROMDATETIME><TODATETIME></TODATETIME><NODELIVERYTIMEFROM> 2200 </NODELIVERYTIMEFROM><NODELIVERYTIMETO> 0700 </NODELIVERYTIMETO><HTTPMODE> S </HTTPMODE><REMARKS></REMARKS><REMARKS1></REMARKS1><REMARKS2></REMARKS2><TRN_GENERATE_TIMESTAMP> "+dt+"</TRN_GENERATE_TIMESTAMP>";
							
							
							//sflag = tms.sendSMS(socket, alertForCustomer, output);
							output.write("MSG^`!" + alertForCustomer1 + "#END#");
							
							
							//output.write(alertForCustomer + "#END#");
							//if(ii == 2) output.write("MSG^`!" + alertForCustomer + "#END#");
							output.flush();
							logWriter.info("SMS Request packet : \n"+alertForCustomer1);
							logWriter.info("Step10");
							toServerinput = socket.getInputStream();
							
							/*InputStreamReader isr = new InputStreamReader(toServerinput);
				            BufferedReader br = new BufferedReader(isr);
				            String message = br.readLine();
				            System.out.println("%##% Message received from the server : " +message);*/
							
							
							inps = new StringBuffer("");
							System.out.println(" INPS ..." +  inps.toString() + " -- " + i + " ^^ " + toServerinput.read());
							logWriter.info("SMS: INPS ..." +  inps.toString() + " -- " + i + " ^^ " + toServerinput.read());
							logWriter.info("Step11");
							if ((i = toServerinput.read()) == -1)
							{
								logWriter.info("Step12");
								success = false;
							}
							else
							{
								logWriter.info("Step13");
								inps.append((char) i);
							}
							if (success && toServerinput.available() != 0)
							{
								logWriter.info("Step14");
								while ((i = toServerinput.read()) != -1)
								{
									
									inps.append((char) i);
									if (toServerinput.available() == 0)
									{
										logWriter.info("Step15");
										break;
									}
								}
							}
							
							System.out.println("After writing data on ISG server..." + inps.toString());
							logWriter.info("SMS:After writing data on ISG server... %##% Response : " + inps.toString());
							if ((inps.toString().indexOf("ACK!1") == 0)||(inps.toString().indexOf("ACK!MSGSTATUS=TRUE") == 0))
							{
								logWriter.info("Step16");
								//java.util.Date date = new java.util.Date();
								//java.text.SimpleDateFormat sdf= new java.text.SimpleDateFormat("dd/MM/yyyy 'at' HH:mm:ss");
								//String dt= sdf.format(date);
								//System.out.println( dt + "|"+ no + "|" + add + "|" + message + "|" + inps.toString());
							}
							else
							{
								logWriter.info("Step17");
								System.out.println("Inside else block...");
								logWriter.info("SMS:Inside else block...");
							}
							
							
							
							//Our Code For Status Check
							if((inps.toString().indexOf("K!1") == 0)||(inps.toString().indexOf("K!MSGSTATUS=TRUE") == 0)){
								logWriter.info("SMS Success. Mobile: "+mobileNo);
								return true;
							}else{
								logWriter.info("SMS Failed. Mobile: "+mobileNo);
								return false;
							}
							//End
						}


					}

				logWriter.info("SMS:Before Closing Connection : ");
				System.out.println(" Before Closing Connection : ");
				output.write("EXT^`!CLOSE the Message#END#");
				logWriter.info("SMS:After Closing Connection : ");
				System.out.println(" After Closing Connection : ");
				//socket.close();
			}

                 	 
        }catch(Exception Ex){
        	logWriter.error("SMS Service Before Closing Connection : Exception Msg: " + Ex.getMessage()+" Cause : "+Ex.getCause()+" Class : "+Ex.getClass());
        	success = false;
		}finally{
			socket.close();
		}
        
		return success;
	}
}
