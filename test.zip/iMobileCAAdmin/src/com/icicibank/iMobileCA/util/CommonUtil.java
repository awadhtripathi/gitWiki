package com.icicibank.iMobileCA.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;

import com.google.gson.Gson;





public class CommonUtil{
	
	private static final Logger logger = Logger.getLogger(CommonUtil.class);

	protected static DataSource dataSource;
	
	private static Context initContext;
	private String datasourceName;

	/*static {
		try {
			initContext = new InitialContext();
			
			
			 for Tomcat deployment 
			//dataSource = (DataSource) initContext.lookup("java:/comp/env/" + "outwardRemittance");
			
			 for Oracle Application Server deployment 
			//dataSource = (DataSource) initContext.lookup("jdbc/outwardRemittance");
			
			
			for ICICI Environment
			
			dataSource = (DataSource) initContext.lookup("jdbc/oram2i");
			
			logger.info("Connected datasource::"+dataSource);
			
		} catch (Exception e) {
			logger.error(e);
			logger.info(e);
		}
	}
	*/
	public String generateSeqNumber(){	
		String seqNo = String.valueOf(UUID.randomUUID()).replaceAll("[\\s\\-()]", "");
		return seqNo+"000";
	}
		
	@SuppressWarnings({ "unchecked", "rawtypes" })
	/*public String fetchIfsc(String account){

		String ifsc = "";

		ifsc = validateParams.getProperty("IFSC");

		if ( ifsc == null || "".equals(ifsc)){
			if(account.length() == 9){
				ifsc = "ICIC0"+StringUtils.leftPad(account.substring(0,1),6,"0");
			}else if(account.length() == 10){
				ifsc = "ICIC0"+StringUtils.leftPad(account.substring(0,2),6,"0");
			}else if(account.length() == 11){
				ifsc = "ICIC0"+StringUtils.leftPad(account.substring(0,3),6,"0");
			}else if (account.length() == 12){
				ifsc = "ICIC0"+StringUtils.leftPad(account.substring(0,4),6,"0");
			}else if (account.length() == 13){
				ifsc = "ICIC0"+StringUtils.leftPad(account.substring(0,5),6,"0");
			}else if (account.length() == 14){
				ifsc = "ICIC0"+StringUtils.leftPad(account.substring(0,6),6,"0");
			}
		}
		logger.info("VPAUtil:fetchIfsc........."+ifsc);
		return ifsc;

	}*/

	private static final Random RANDOM = new Random();

	 

	public static String generateGUID()

	       {

	              return new BigInteger(165, RANDOM).toString(36).toUpperCase();

	       }
	
	public String getNotificationFormat(Map<String, String> notifyDetailsMap) {
		StringBuilder sbl = new StringBuilder();
		Set<String> reqResKeys = notifyDetailsMap.keySet();
		if (reqResKeys != null) {
			for (Iterator<String> iterator = reqResKeys.iterator(); iterator
					.hasNext();) {
				String key = (String) iterator.next();
				String value = (String) notifyDetailsMap.get(key);
				if (key != null && value != null) {
					sbl.append(key + ":" + value);
					if (iterator.hasNext()) {
						sbl.append(";");
					}
				}
			}
		}
		return sbl.toString();
	}
	public HashMap<String, String> getMapFromArrayList(
			ArrayList<HashMap<String, String>> list) {
		HashMap<String, String> returnMap = new HashMap<String, String>();
		for (int i = 0; i < list.size(); i++) {
			HashMap<String, String> mapCheck = list.get(i);
			Set<String> reqResKeys = mapCheck.keySet();
			if (reqResKeys != null) {
				for (Iterator<String> iterator = reqResKeys.iterator(); iterator
						.hasNext();) {
					String key = (String) iterator.next();
					String value = (String) mapCheck.get(key);
					if (key != null && value != null) {
						returnMap.put(key, value);
					}
				}
			}
		}
		return returnMap;
	}
	
	
	
	
	
	
	
	public static String getDataFromService(String urlString) {
		StringBuffer response = new StringBuffer();
		try {
			URL obj = new URL(urlString);

			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setConnectTimeout(10000);
			con.setReadTimeout(10000);
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String data = response.toString();
		if (data.contains("&")) {
			data = data.replaceAll("&", "&amp;");
		}
		logger.info("Service data is :" + data.toString());
		return data.trim();		
		
	}
	
	public static Connection getOldDBConnection1(){
		Connection conn = null;
		try{
		      Context ctx = new InitialContext();
		      /*if(ctx == null ) 
		          throw new Exception("No Context found");
		      DataSource ds = (DataSource)ctx.lookup(
		               "java:comp/env/jdbc/imobcanada");
		      if (ds != null) {
		        conn = ds.getConnection();
		      }*/
		//	Class.forName("oracle.jdbc.xa.client.OracleXADataSource");
			Class.forName("oracle.jdbc.driver.OracleDriver"); 
		/*	String URL = "jdbc:oracle:thin:@10.16.240.95:9052:ECECMBCA";
			Properties info = new Properties( );
			info.put( "user", "mbuserca" );
			info.put( "password", "mbuserca_123" );*/

		//	conn = DriverManager.getConnection(URL, info);
//			conn=DriverManager.getConnection("jdbc:oracle:thin:@10.16.240.95:9052:ECECMBCA","mbuserca","mbuserca_123");
		//	conn=DriverManager.getConnection("jdbc:oracle:thin:@10.16.240.95:9003:WLIMBUAT","IMBCA","IMBCA_123");
			logger.info("DBConnection --------------------------------------- :" +conn);
		}catch(Exception ex){
			ex.printStackTrace();
		}     
		
		return conn;
	}
	
	public static Connection getNewDBConnection(){
		Connection conn = null;
		try{
		      Context ctx = new InitialContext();
		      if(ctx == null ) 
		          throw new Exception("No Context found");
		      DataSource ds = (DataSource)ctx.lookup(
		               "java:comp/env/jdbc/IMBCA");
		      if (ds != null) {
		        conn = ds.getConnection();
		      }
		/*//	Class.forName("oracle.jdbc.xa.client.OracleXADataSource");
			Class.forName("oracle.jdbc.driver.OracleDriver"); 
			String URL = "jdbc:oracle:thin:@10.16.240.95:9052:ECECMBCA";
			Properties info = new Properties( );
			info.put( "user", "mbuserca" );
			info.put( "password", "mbuserca_123" );

		//	conn = DriverManager.getConnection(URL, info);
		//	conn=DriverManager.getConnection("jdbc:oracle:thin:@10.16.240.95:9052:ECECMBCA","mbuserca","mbuserca_123");
			conn=DriverManager.getConnection("jdbc:oracle:thin:@10.16.240.95:9003:WLIMBUAT","IMBCA","IMBCA_123");*/
			logger.info("NEWDBConnection --------------------------------------- :" +conn);
		}catch(Exception ex){
			ex.printStackTrace();
		}     
		
		return conn;
	}
	
	
	/*public static Connection getConnectionUK(){
		Connection conn = null;
		try{
		      Context ctx = new InitialContext();
		      if(ctx == null ) 
		          throw new Exception("No Context found");
		  //    DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/imobuk");
		      DataSource  ds = (DataSource) new InitialContext().lookup("jdbc/imobuk");
		      if (ds != null) {
		        conn = ds.getConnection();
		      }
		}catch(Exception ex){
			ex.printStackTrace();
		}     
		
		return conn;
	}*/
	
	public static double distance(double lat1, double lon1, double lat2, double lon2) {
		double theta = lon1 - lon2;
		double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
		dist = Math.acos(dist);
		dist = rad2deg(dist);
		dist = dist * 60 * 1.1515;
		/*if (unit == "K") {
			dist = dist * 1.609344;
		} else if (unit == "N") {
			dist = dist * 0.8684;
		}*/

		return (dist);
	}

	/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
	/*::	This function converts decimal degrees to radians						 :*/
	/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
	private static double deg2rad(double deg) {
		return (deg * Math.PI / 180.0);
	}

	/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
	/*::	This function converts radians to decimal degrees						 :*/
	/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
	private static double rad2deg(double rad) {
		return (rad * 180 / Math.PI);
	}
	
	public static String getLocalTxnDtTime() {
		Date dt = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		sdf.setTimeZone(TimeZone.getTimeZone("EST"));
		String PST = sdf.format(dt);
		logger.info((new StringBuilder("Date Time :")).append(PST).toString());
		return PST;
	}

	public static String getCaptureDt() {
		Date dt = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		sdf.setTimeZone(TimeZone.getTimeZone("EST"));
		String PST = sdf.format(dt);
		return PST;
	}

	public static String getStan() {
		Date dt = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
		sdf.setTimeZone(TimeZone.getTimeZone("EST"));
		String PST = sdf.format(dt);
		return PST;
	}
	
	public static long getDateTime(String strDate, String format) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		Date date = formatter.parse(strDate);
		long dt = date.getTime();
		logger.info("Date :: "+date+"  :longdate: "+dt);
		return dt;
	}
	
	public static String getDateTime(long dt, String format) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		Date date = new Date(dt);
		String strDt = formatter.format(dt);
		logger.info("Date :: "+date+"  :longdate: "+dt);
		return strDt;
	}
	
	public static String getDateTime(long dt, String format, String timezone) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		formatter.setTimeZone(TimeZone.getTimeZone(timezone));
		Date date = new Date(dt);
		String strDt = formatter.format(dt);
		logger.info("Date :: "+date+"  :longdate: "+dt);
		return strDt;
	}
	
	public static String getCurrentDateTime() throws ParseException {
		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.FULL);
		df.setTimeZone(TimeZone.getTimeZone("EST"));
		final String dateTimeString = df.format(DateUtils.addDays(new Date(), -1));
		logger.info("dateTimeString :: "+dateTimeString);
		return dateTimeString;
	}
	
	public static long getTimeZoneDateTime() throws ParseException {
		Date dt = new Date();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
		df.setTimeZone(TimeZone.getTimeZone("EST"));
		String EST = df.format(dt);
		long dateTime = getDateTime(EST,"yyyyMMddHHmmss");
		logger.info("dateTime :: "+dateTime);
		return dateTime;
	}
	
	public static String getTxnAmount(String amount) {
		String  finalAmount= null;
		if (amount.length() < 13) {
			BigDecimal finalAmount1 = BigDecimal.valueOf(Double.valueOf(amount) * 100);
			amount = String.valueOf(finalAmount1.toBigInteger());
			finalAmount = StringUtils.leftPad(amount, 13, "0");
		} else {
			BigDecimal finalAmount1 = BigDecimal.valueOf(Double.valueOf(amount) * 100);
			amount = String.valueOf(finalAmount1);
			finalAmount = amount;
		}
		return finalAmount; 
	}
	
	public static String getImageSize(String amount,int i) {
		String  finalAmount= null;
		if (amount.length() < i) {
			BigDecimal finalAmount1 = BigDecimal.valueOf(Double.valueOf(amount));
			amount = String.valueOf(finalAmount1.toBigInteger());
			finalAmount = StringUtils.leftPad(amount, i, "0");
		} else {
			BigDecimal finalAmount1 = BigDecimal.valueOf(Double.valueOf(amount));
			amount = String.valueOf(finalAmount1.toBigInteger());
			finalAmount = amount;
		}
		return finalAmount; 
	}
	
	
	public static boolean validSchemecode(String schemecode, String csvList)
	{
		String[] schemeList = csvList.split(",");
		boolean isValid = false;
		for(int i=0;i<schemeList.length;i++)
		{
			if(schemecode.equalsIgnoreCase(schemeList[i].trim()))
			{
				isValid=true;
				break;
			}
		}
		
		return isValid;
	}
	public static Date getESTDateWithCutoff(Date date,String cutOffTime) {
		String hour = cutOffTime.split(":")[0];
		String min = cutOffTime.split(":")[1];
		//TimeZone tz = TimeZone.getTimeZone("EST");
		Calendar calendar = Calendar.getInstance();
		//calendar.clear();
		//calendar.setTimeZone(tz);
		calendar.setTime(date);
		calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hour));
		calendar.set(Calendar.MINUTE, Integer.parseInt(min));
		calendar.set(Calendar.SECOND,0);
		calendar.set(Calendar.MILLISECOND,000);
	    return calendar.getTime();
	}
	public static Date beginOfDay(Date date) {
	    Calendar cal = Calendar.getInstance();
	    cal.setTime(date);
	    cal.set(Calendar.HOUR_OF_DAY, 0);
	    cal.set(Calendar.MINUTE, 0);
	    cal.set(Calendar.SECOND, 0);
	    cal.set(Calendar.MILLISECOND, 0);

	    return cal.getTime();
	}

	public static Date endOfDay(Date date) {
	    Calendar cal = Calendar.getInstance();
	    cal.setTime(date);
	    cal.set(Calendar.HOUR_OF_DAY, 23);
	    cal.set(Calendar.MINUTE, 59);
	    cal.set(Calendar.SECOND, 59);
	    cal.set(Calendar.MILLISECOND, 999);

	    return cal.getTime();
	}
	public static void main(String[] args) throws Exception {
		getCurrentDateTime();
		String txnDate = getDateTime(new Date().getTime(), "yyyyMMddhhmmss");
		logger.info("txnDate ::" + txnDate);
	
	}
	public String convertToJson(Object obj){
		Gson gson = new Gson();
		String jsonInString = gson.toJson(obj);
		logger.info("json value:"+jsonInString);
		return jsonInString;
	}
	 
}


