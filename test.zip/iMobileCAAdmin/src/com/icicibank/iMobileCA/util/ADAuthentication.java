package com.icicibank.iMobileCA.util;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;

import javax.naming.AuthenticationException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.apache.log4j.Logger;


public class ADAuthentication {

	
	private String INITCTX = "";
	private String URL = "";
	private String USRPRNCPL = "";
	private String PASSWD = "";
	private static final Logger logWriter = Logger.getLogger(ADAuthentication.class.getName());
	
	public ADAuthentication() {

	}

	public Hashtable formatResults(NamingEnumeration namingenumeration)
			throws Exception {
		//logger.info("Start Class :- ADAuthentication : Method :- formatResults()");
//		int i = 0;
		logWriter.info("Test:: In formatResults");
		Hashtable hashtable = null;
		try {
			logWriter.info("Test:: before Loop");
			while (namingenumeration.hasMore()) {
			    
				hashtable = new Hashtable();
				SearchResult searchresult = (SearchResult) namingenumeration
						.next();		
				formatAttributes(searchresult.getAttributes(), hashtable);
//				i++;
			}
		} catch (NamingException namingexception) {
			//errlog.error("#### $$$$ Class :- ADAuthentication : Method :- formatResults() Message :- No Result Found");
			logWriter.error("Test:: Exception msg: "+namingexception.getMessage()+" - Explanation: "+namingexception.getExplanation());
			return hashtable;
		}
		return hashtable;
	}

	public Hashtable formatAttributes(Attributes attributes, Hashtable hashtable)
			throws Exception {
		//logger.info("Start Class :- ADAuthentication : Method :- formatAttributes()");
		logWriter.info("Test:: In formatAttributes");
		if (attributes == null) {
			//logger.debug("Class :- ADAuthentication : Method :- formatAttributes() Message :- This result has no attributes");
			throw new Exception("This result has no attributes");
		}
		try {
			logWriter.info("Test:: In formatAttributes attributes not NULL");
			for (NamingEnumeration namingenumeration = attributes.getAll(); namingenumeration
					.hasMore();) {
				Attribute attribute = (Attribute) namingenumeration.next();
				for (NamingEnumeration namingenumeration1 = attribute.getAll(); namingenumeration1
						.hasMore(); hashtable.put(attribute.getID(),
						namingenumeration1.next()))
					;
			}
			Enumeration<String> e = hashtable.keys();
			String key  = null;
			logWriter.info("Test:: Hash table data: ");
			while(e.hasMoreElements()){
				key = e.nextElement(); 
				logWriter.info("Test:: Key - "+key+" :: Value - "+hashtable.get(key));
			}
		} catch (NamingException namingexception) {
			//errlog.error("#### $$$$ Class :- ADAuthentication : Method :- formatAttributes() Message :- This result has no attributes in catch loop");
			throw new Exception("This result has no attributes in catch loop");
		}
		return hashtable;
	}

	public Hashtable getSelectedAttributeVal(String s, String s1, Vector vector)
			throws Exception {
		//logger.info("Start Class :- ADAuthentication : Method :- getSelectedAttributeVal()");
		DirContext dircontext = getDirContext();
//		String s2 = "";
		String s3 = "(&(mailNickname=" + s + ")";
		String as[] = new String[vector.size()];
		for (int i = 0; i < vector.size(); i++) {
			as[i] = (String) vector.get(i);
			s3 = s3 + "(" + (String) vector.get(i) + "=*)";
		}
		s3 = s3 + ")";
		SearchControls searchcontrols = new SearchControls();
		searchcontrols.setReturningAttributes(as);
		searchcontrols.setSearchScope(2);
		Hashtable hashtable = null;
		try {
			authenticateUser(s, s1, "dummy");
			NamingEnumeration namingenumeration = dircontext.search(
					"DC=icicibankltd,DC=com", s3, searchcontrols);
			hashtable = formatResults(namingenumeration);
			if (hashtable == null)
				throw new Exception("Invalid attributes passed");
		} catch (Exception exception) {
			throw new Exception(exception.getMessage());
		}
		dircontext.close();
		return hashtable;
	}

	private Hashtable getDN(String s, String s1) throws Exception {
		//logger.info("Start Class :- ADAuthentication : Method :- getDN(String s, String s1)");
		DirContext dircontext = null;
		Hashtable hashtable = null;
		try {
			dircontext = getDirContext();
		} catch (Exception exception) {
			//errlog.error("#### $$$$ Class :- ADAuthentication : Method :- getDN(String s, String s1) Message :- Inside the getDN Function Could not get the DirContext. "+exception.getMessage());
			// writeLog("\n In getDN === There was an exception ");
			// IVException.handleException(exception,
			// "\n In getDN === There was an exception ", true, false, false);
			throw exception;
		}
		String as[] = { "mailNickName", "distinguishedName", "mail", "name",
				"lname", "sAMAccountName" };
		SearchControls searchcontrols = new SearchControls();
		searchcontrols.setReturningAttributes(as);
		searchcontrols.setSearchScope(2);
		String s2 = "(&(sAMAccountName=" + s + ")( distinguishedName=*))";
		NamingEnumeration namingenumeration = dircontext.search("DC=" + s1
				+ ",DC=com", s2, searchcontrols);
		hashtable = formatResults(namingenumeration);
		//logWriter.info("User Data :-"+hashtable);
		if (hashtable == null) {
			return hashtable;
		} else {
			dircontext.close();
			return hashtable;
		}
	}

	public boolean checkEmployeeNo(String s) throws Exception {
		//logger.info("Start Class :- ADAuthentication : Method :- checkEmployeeNo()");
		DirContext dircontext = getDirContext();
		String as[] = { "mailNickName", "distinguishedName" };
		SearchControls searchcontrols = new SearchControls();
		searchcontrols.setReturningAttributes(as);
		searchcontrols.setSearchScope(2);
		String s1 = "(&(mailNickName=" + s + ")( distinguishedName=*))";
		NamingEnumeration namingenumeration = dircontext.search(
				"DC=icicibankltd,DC=com", s1, searchcontrols);
		Hashtable hashtable = formatResults(namingenumeration);
		if (hashtable == null) {
			throw new Exception(
					"Employee No Does not Exist  checkEmployeeNo function");
		} else {
			dircontext.close();
			return true;
		}
	}

	public DirContext getDirContext() throws Exception {
		//logger.info("Start Class :- ADAuthentication : Method :- getDirContext()");
		InitialDirContext initialdircontext = null;
		Hashtable hashtable = new Hashtable(11);
		hashtable.put("java.naming.factory.initial", INITCTX.trim());
		hashtable.put("java.naming.provider.url", URL.trim());
		// Ldap Time Out Period
		hashtable.put("com.sun.jndi.ldap.connect.timeout", "60000");
		try {
			initialdircontext = new InitialDirContext(hashtable);
		} catch (Exception exception) {
			//errlog.error("#### $$$$ Class :- ADAuthentication : Method :- getDirContext() Message :- \n In getDirContext == Could not connect to server");
			throw new Exception("Could not connect to server");
		}
		//logger.debug("Class :- ADAuthentication : Method :- getDirContext() Message :- Inside getDirContext()  initialdircontext == "+ initialdircontext);
		return initialdircontext;
	}

	public Hashtable authenticateUser(String s, String s1, String attr)
			throws Exception {
		//logger.info("Start Class :- ADAuthentication : Method :- authenticateUser()");
		//boolean flag = true;
		Properties properties = new Properties();
		properties.load(this.getClass().getResourceAsStream("/log.properties"));
		Enumeration enumeration = properties.propertyNames();
		String v;
		for (; enumeration.hasMoreElements();) {
			v = (String) enumeration.nextElement();
			if (v.equals("provider"))
				INITCTX = properties.getProperty(v);
			else if (v.equals("url"))
				URL = properties.getProperty(v);
		}

		//InitialDirContext initialdircontext = null;
		Hashtable hashtable = new Hashtable(11);
		hashtable.put("java.naming.factory.initial", INITCTX);
		hashtable.put("java.naming.provider.url", URL);
		String s3 = "ICICIBANKLTD";
		Hashtable hashtable1 = getDN(s, s3);
		/*if (hashtable1 == null) {
			return hashtable1;
		}
		
		String s2 = (String) hashtable1.get("distinguishedName");
		USRPRNCPL = s2;
		hashtable.put("java.naming.security.authentication", "simple");
		hashtable.put("java.naming.security.principal", USRPRNCPL);
		hashtable.put("java.naming.security.credentials", s1);
		
		try {
			initialdircontext = new InitialDirContext(hashtable);
		} catch (javax.naming.AuthenticationException exception) {
			flag = false;
			logWriter.info("\n Invalid Username/Password !!! authenticateUser function "
					+ exception);
			// return flag;
		} catch (Exception exception) {
			flag = false;
			logWriter.info("Error Occured  " + exception);
			// return flag;
		}
		*/
		return hashtable1;
	}

	public Hashtable authenticateUser(String s, String s1) throws Exception {
		return authenticateUser(s, s1, "");
	}

	public boolean checkUserCredentials(String s, String s1) throws Exception {
		//logger.info("Start Class :- ADAuthentication : Method :- checkUserCredentials()");
		boolean flag = true;

		Properties properties = new Properties();

		properties.load(this.getClass().getResourceAsStream("/log.properties"));
		Enumeration enumeration = properties.propertyNames();
		String v;
		for (; enumeration.hasMoreElements();) {
			v = (String) enumeration.nextElement();
			if (v.equals("provider"))
				INITCTX = properties.getProperty(v);
			else if (v.equals("url"))
				URL = properties.getProperty(v);
		}
		//InitialDirContext initialdircontext = null;
		Hashtable hashtable = new Hashtable(11);
		hashtable.put("java.naming.factory.initial", INITCTX);
		hashtable.put("java.naming.provider.url", URL);
		String s2 = "ICICIBANKLTD";
		Hashtable hashtable1 = getDN(s, s2);
		if (hashtable1 == null) {
			flag = false;
			return flag;
		}
		/*String s3 = (String) hashtable1.get("distinguishedName");
		USRPRNCPL = s3;
		hashtable.put("java.naming.security.authentication", "simple");
		hashtable.put("java.naming.security.principal", USRPRNCPL);
		hashtable.put("java.naming.security.credentials", s1);
		try {
			initialdircontext = new InitialDirContext(hashtable);
		} catch (AuthenticationException authenticationexception) {
			flag = false;
			System.out
					.println("\n Invalid Username/Password !!! authenticateUser function "
							+ authenticationexception);
			// IVException.handleException(authenticationexception,
			// "\n Invalid Username/Password !!! authenticateUser function ",
			// true, false, false);
			return flag;
		} catch (Exception exception) {
			flag = false;
			// writeLog("Error Occured  " + exception);
			return flag;
		}*/
		return flag;
	}

	// SOC ==== Added By K.K.Challenger on 23-04-08

	public DirContext getDirContext(String s) throws Exception {
		//logger.info("Start Class :- ADAuthentication : Method :- getDirContext(String s)");
		logWriter.info("Test:: In getDirContext");
		InitialDirContext initialdircontext = null;
		Hashtable hashtable = new Hashtable(11);
		hashtable.put("java.naming.factory.initial", INITCTX.trim());
		hashtable.put("java.naming.provider.url", URL.trim());
		// Ldap Time Out Period
		hashtable.put("com.sun.jndi.ldap.connect.timeout", "60000");
		hashtable.put("java.naming.security.authentication", "simple");
		logWriter.info("Test:: after setting LDAP Env HashMap");
		
		if (s.equalsIgnoreCase("ICICIBANKLTD")) {
			hashtable.put("java.naming.security.principal", "icicibankltd\\"
					+ USRPRNCPL.trim());
			logWriter.info("Test:: after setting icicibankltd\\"+hashtable.get("java.naming.security.principal"));		
		} else if (s.equalsIgnoreCase("I-SEC")) {
			hashtable.put("java.naming.security.principal", "I-SEC\\"
					+ USRPRNCPL.trim());
		}
		hashtable.put("java.naming.security.credentials", PASSWD.trim());
		try {
			logWriter.info("Test:: Before InitialDirContext Object Creation");
			initialdircontext = new InitialDirContext(hashtable);
			logWriter.info("Test:: After InitialDirContext Object Creation-- Success LDAP");
		} catch (AuthenticationException exception) {
			logWriter.error("LDAP Exception: ");
			logWriter.error("Cause: "+exception.getCause());
			logWriter.error("Explanation: "+exception.getExplanation());
			logWriter.error("Localized Msg: "+exception.getLocalizedMessage());
			logWriter.error("Root Cause: "+exception.getRootCause());
			logWriter.error("Resolved Name: "+exception.getResolvedName());
			
		}catch (Exception exception) {
			//errlog.error("#### $$$$ Class :- ADAuthentication : Method :- getDirContext(String s) Message :- \n In getDirContext == Could not connect to server");
			 //throw new Exception(
				///	"Could not connect to server. Please check the property file. URL or userID or Password May be incorrect");
				logWriter.error("Test:: In getDirContext Exception Msg: "+exception.getMessage()+" -- Cause: "+exception.getCause());
				logWriter.error("Test::Could not connect to server -- LDAP Auth Failed (its value will be NULL");
		}
		return initialdircontext;
	}

	public Hashtable getDN(String s, String s1, String attr) throws Exception {
		//logger.info("Start Class :- ADAuthentication : Method :- getDN(String s, String s1, String attr)");
		logWriter.info("Test:: in getDN");
		DirContext dircontext = null;
		Hashtable hashtable = null;
		try {
			dircontext = getDirContext(s1);
		} catch (Exception exception) {
			logWriter.error("Test:: In getDN Exception Msg: "+exception.getMessage()+" -- Cause: "+exception.getCause());
			throw exception;
		}
		//String as[] = { "mail" };
		SearchControls searchcontrols = new SearchControls();
		searchcontrols.setSearchScope(2);
		String s2 = null;
		if (!attr.equals("dn"))
			s2 = "(&(sAMAccountName=" + s + ")( distinguishedName=*))";
		else
			s2 = "(&(distinguishedName=" + s + "))";
		try {
			NamingEnumeration namingenumeration = dircontext.search("DC=" + s1
					+ ",DC=com", s2, searchcontrols);
			hashtable = formatResults(namingenumeration);

		} catch (Exception Xce) {
			//errlog.error("#### $$$$ Class :- ADAuthentication : Method :- getDN(String s, String s1, String attr) Message :- Improper Login ID. " + Xce.getMessage());
			logWriter.error("Test: In getDN Exception : "+Xce.getMessage()+" - Cause: "+Xce.getCause());
		}
		if (hashtable == null) {
			return hashtable;
		} else {
			dircontext.close();
			return hashtable;
		}
	}

	public Hashtable checkUserCredentials(String s, String s1, String s2)
			throws Exception {
		//for log capture error written
		//logger.error("########## ADAuthentication started :::::: checking user credintioal from LDAP :::::: For User id :-"+s +":::::Domain "+s2);

		boolean flag = true;
		Properties properties = new Properties();
		//String proF = null;
		if (s2.equalsIgnoreCase("ICICIBANKLTD")) {
			properties.load(this.getClass().getResourceAsStream(
					"/log.properties"));
		} else if (s2.equalsIgnoreCase("I-SEC")) {
			properties.load(this.getClass().getResourceAsStream(
					"/I-Seclog.properties"));
		}

		Enumeration enumeration = properties.propertyNames();
		String v;
		for (; enumeration.hasMoreElements();) {
			v = (String) enumeration.nextElement();
			if (v.equals("provider"))
				INITCTX = properties.getProperty(v);

			else if (v.equals("url"))
				URL = properties.getProperty(v);
			else if (v.equals("UserID"))
				USRPRNCPL = properties.getProperty(v);

			else if (v.equals("PassWD"))
				PASSWD = properties.getProperty(v);
		}
		USRPRNCPL = s;
		PASSWD = s1;
		logWriter.info("");
		logWriter.info("Test::URL: "+URL);
		logWriter.info("Test::provider: "+INITCTX);
		logWriter.info("Test::USRPRNCPL: "+USRPRNCPL);
		
		Hashtable hashtable1 = getDN(s, s2, "");
		logWriter.info("User Data :-"+hashtable1);
		//logWriter.info("User Data From LDAP :-"+hashtable1);
		if (hashtable1 != null) {
			//logger.error("#### $$$$ Class :- ADAuthentication : Method :- checkUserCredentials() Message :- Could not get the USER Details from LDAP. User Credentials is false");
			//flag = false;
			return hashtable1;
		}
		//InitialDirContext initialdircontext = null;
		/*
		Hashtable hashtable = new Hashtable(11);
		hashtable.put("java.naming.factory.initial", INITCTX);
		hashtable.put("java.naming.provider.url", URL);
		String s3 = (String) hashtable1.get("distinguishedName");
		USRPRNCPL = s3;
		hashtable.put("java.naming.security.authentication", "simple");
		hashtable.put("java.naming.security.principal", USRPRNCPL);
		hashtable.put("java.naming.security.credentials", s1);
		try {
			initialdircontext = new InitialDirContext(hashtable);
		} catch (AuthenticationException authenticationexception) {
			flag = false;
			System.out
					.println("\n Invalid Username/Password !!! authenticateUser function "
							+ authenticationexception);
			// IVException.handleException(authenticationexception,
			// "\n Invalid Username/Password !!! authenticateUser function ",
			// true, false, false);
			return flag;
		} catch (Exception exception) {
			flag = false;
			
			return flag;
		}
		*/
		return hashtable1;
	}

	public Hashtable authenticateUser(String s, String s1, String attr,
			String s3) throws Exception {
		//logger.info("Start Class :- ADAuthentication : Method :- authenticateUser()");
		//boolean flag = true;
		Properties properties = new Properties();
		//String proF = null;
		if (s3.equalsIgnoreCase("ICICIBANKLTD")) {
			properties.load(this.getClass().getResourceAsStream(
					"/log.properties"));
		} else if (s3.equalsIgnoreCase("I-SEC")) {
			properties.load(this.getClass().getResourceAsStream(
					"/I-Seclog.properties"));
		}
		Enumeration enumeration = properties.propertyNames();
		String v;
		for (; enumeration.hasMoreElements();) {
			v = (String) enumeration.nextElement();
			if (v.equals("provider"))
				INITCTX = properties.getProperty(v);
			else if (v.equals("url"))
				URL = properties.getProperty(v);
			else if (v.equals("UserID"))
				USRPRNCPL = properties.getProperty(v);
			else if (v.equals("PassWD"))
				PASSWD = properties.getProperty(v);
		}
		Hashtable hashtable1 = getDN(s, s3, attr);
		if (hashtable1 == null) {
			return hashtable1;

		}
		return hashtable1;
	}

	public boolean checkEmployeeNo(String s, String s2) throws Exception {
		//logger.info("Start Class :- ADAuthentication : Method :- checkEmployeeNo()");
		DirContext dircontext = getDirContext();
		String as[] = { "mailNickName", "distinguishedName" };
		SearchControls searchcontrols = new SearchControls();
		s2 = "DC=" + s2 + ",DC=com";
		//logger.debug("Class :- ADAuthentication : Method :- checkEmployeeNo() Message :- Inside Check Employee === " + s2);
		searchcontrols.setReturningAttributes(as);
		searchcontrols.setSearchScope(2);
		String s1 = "(&(mailNickName=" + s + ")( distinguishedName=*))";
		NamingEnumeration namingenumeration = dircontext.search(s2, s1,
				searchcontrols);
		Hashtable hashtable = formatResults(namingenumeration);
		if (hashtable == null) {
			throw new Exception(
					"Employee No Does not Exist  checkEmployeeNo function");
		} else {
			dircontext.close();
			return true;
		}
	}

}