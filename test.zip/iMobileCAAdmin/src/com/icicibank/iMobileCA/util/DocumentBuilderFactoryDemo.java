package com.icicibank.iMobileCA.util;


import java.io.File;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

public class DocumentBuilderFactoryDemo {

   public static void main(String[] args) {

      // create a new DocumentBuilderFactory
      DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
      try {
         File file = new File("files"+File.separator+"IACheck.ExternalImport.xsd");

         // create schema
         String constant = XMLConstants.W3C_XML_SCHEMA_NS_URI;
         SchemaFactory xsdFactory = SchemaFactory.newInstance(constant);
         Schema schema = xsdFactory.newSchema(file);
         
         // set schema
         factory.setSchema(schema);

         // get the schema
         System.out.println("" + factory.getSchema());

      } catch (Exception ex) {
         ex.printStackTrace();
      }

   }
}
