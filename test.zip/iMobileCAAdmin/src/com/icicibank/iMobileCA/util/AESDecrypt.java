package com.icicibank.iMobileCA.util;

import java.security.GeneralSecurityException;
import java.security.spec.KeySpec;
import java.util.Map;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;



@SuppressWarnings("all")
public class AESDecrypt {

	private static final Random RANDOM = new Random(); 
	
	public String encrypt(String Key,String Value) throws Exception{
		byte[] abyte2 = null;
		String plainText = Value;
		byte s1[]=plainText.getBytes();
		byte[] abyte1 = Key.getBytes();
		SecretKeySpec secretkeyspec = new  SecretKeySpec(abyte1, "AES");
		SecretKeySpec secretkeyspec1 = secretkeyspec;
		Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
		cipher.init(1, secretkeyspec1);
		abyte2 = cipher.doFinal(s1);
		BASE64Encoder encoder = new BASE64Encoder();
		String base64 = encoder.encode(abyte2);
		return base64;
	}
	
	private static byte[] getRandomBytes(int length) { 
	    byte[] result = new byte[length]; 
	    RANDOM.nextBytes(result); 
	    return result; 
	}
	
	public static String generateEncryptedString(Map<String, String> map, String encryptedMpin) throws Exception{
		
		byte[] saltBytes = hexStringToByteArray(map.get("salt"));
	    byte[] ivBytes = hexStringToByteArray(map.get("iv"));
	    String password = "Secret Passphrase";
	    IvParameterSpec ivParameterSpec = new IvParameterSpec(ivBytes);        
	    SecretKeySpec sKey = (SecretKeySpec) generateKeyFromPassword(password, saltBytes);
	    return decrypt( encryptedMpin , sKey ,ivParameterSpec);
	}
	
	public static SecretKey generateKeyFromPassword(String password, byte[] saltBytes) throws GeneralSecurityException {

	    KeySpec keySpec = new PBEKeySpec(password.toCharArray(), saltBytes, 100, 128);
	    SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
	    SecretKey secretKey = keyFactory.generateSecret(keySpec);
	    return new SecretKeySpec(secretKey.getEncoded(), "AES");
	}

	public static byte[] hexStringToByteArray(String s) {

	    int len = s.length();
	    byte[] data = new byte[len / 2];

	    for (int i = 0; i < len; i += 2) {
	        data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
	                + Character.digit(s.charAt(i+1), 16));
	    }

	    return data;
	}

	public static String decrypt(String encryptedData, SecretKeySpec sKey, IvParameterSpec ivParameterSpec) throws Exception { 

	    Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
	    c.init(Cipher.DECRYPT_MODE, sKey, ivParameterSpec);
	    byte[] decordedValue = new BASE64Decoder().decodeBuffer(encryptedData);
	    byte[] decValue = c.doFinal(decordedValue);
	    String decryptedValue = new String(decValue);
	    return decryptedValue;
	}
}
