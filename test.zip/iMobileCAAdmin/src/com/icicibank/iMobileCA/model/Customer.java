package com.icicibank.iMobileCA.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IMCA_CUSTOMER_MST")
public class Customer {
	@Id
	@Column(name = "BAYUSERID")
	private String bayUserId;
	
	@Column(name = "CUST_FNAME")
	private String custFName;
	
	@Column(name = "CUST_LNAME")
	private String custLName;
	
	@Column(name = "CUST_LOGIN_PREF")
	private int custLoginPref;
	
	@Column(name = "CUST_MPIN")
	private String custMPin;
	
	@Column(name = "MOBILE_NO")
	private String mobileNo;
	
	@Column(name = "PASSWORD")
	private String password;
	
	@Column(name = "CUSTID")
	private String custId;
	
	@Column(name = "STATUS")
	private int status;
	
	@Column(name = "TOKENID")
	private String tokenId;
	
	@Column(name = "CUST_MNAME")
	private String custMName;
	
	@Column(name = "CUST_ALIAS")
	private String custAlias;
	
	@Column(name = "LAST_LOGIN")
	private Timestamp lastLogin;
	
	public String getBayUserId() {
		return bayUserId;
	}

	public void setBayUserId(String bayUserId) {
		this.bayUserId = bayUserId;
	}

	public String getCustFName() {
		return custFName;
	}

	public void setCustFName(String custFName) {
		this.custFName = custFName;
	}

	public String getCustLName() {
		return custLName;
	}

	public void setCustLName(String custLName) {
		this.custLName = custLName;
	}

	public int getCustLoginPref() {
		return custLoginPref;
	}

	public void setCustLoginPref(int custLoginPref) {
		this.custLoginPref = custLoginPref;
	}

	public String getCustMPin() {
		return custMPin;
	}

	public void setCustMPin(String custMPin) {
		this.custMPin = custMPin;
	}

	@Override
	public String toString() {
		return "Customer [bayUserId=" + bayUserId + ", custFName=" + custFName
				+ ", custLName=" + custLName + ", custLoginPref="
				+ custLoginPref + ", custMPin=" + custMPin + ", mobileNo="
				+ mobileNo + ", password=" + password + ", custId=" + custId
				+ ", status=" + status + ", tokenId=" + tokenId
				+ ", custMName=" + custMName + ", custAlias=" + custAlias
				+ ", lastLogin=" + lastLogin + "]";
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public String getCustMName() {
		return custMName;
	}

	public void setCustMName(String custMName) {
		this.custMName = custMName;
	}

	public String getCustAlias() {
		return custAlias;
	}

	public void setCustAlias(String custAlias) {
		this.custAlias = custAlias;
	}

	public Timestamp getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Timestamp lastLogin) {
		this.lastLogin = lastLogin;
	}

}
