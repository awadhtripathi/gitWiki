package com.icicibank.iMobileCA.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IMCA_CITY_DETAILS_MST")
public class Cities implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Column(name="CITY_NAME")
	private String cityName;
	@Column(name="PROVINCE_CODE")
	private String provinceCode;
	@Column(name="PINCODE")
	private String pinCode;
	@Column(name="ACTIVE")
	private String active;
	@Column(name="MAKER")
	private String maker;
	@Column(name="MAKERDT")
	private Timestamp makerDt;
	@Column(name="CHECKER")
	private String checker;
	@Column(name="CHECKER_DT")
	private Timestamp checkerDt;
	@Column(name="REASON")
	private String reason;
	@Id
	@Column(name="CITY_CODE")
	private String cityCode;
	@Column(name="LATITUDE")
	private String latitude;
	@Column(name="LONGITUDE")
	private String longitude;
	
	@Column(name="STATUS")
	private String status;
	
	private int branchCount;
	
	public int getBranchCount() {
		return branchCount;
	}
	public void setBranchCount(int branchCount) {
		this.branchCount = branchCount;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getProvinceCode() {
		return provinceCode;
	}
	public void setProvinceCode(String provinceCode) {
		this.provinceCode = provinceCode;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	public String getMaker() {
		return maker;
	}
	public void setMaker(String maker) {
		this.maker = maker;
	}
	public Timestamp getMakerDt() {
		return makerDt;
	}
	public void setMakerDt(Timestamp makerDt) {
		this.makerDt = makerDt;
	}
	public String getChecker() {
		return checker;
	}
	public void setChecker(String checker) {
		this.checker = checker;
	}
	public Timestamp getCheckerDt() {
		return checkerDt;
	}
	public void setCheckerDt(Timestamp checkerDt) {
		this.checkerDt = checkerDt;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
