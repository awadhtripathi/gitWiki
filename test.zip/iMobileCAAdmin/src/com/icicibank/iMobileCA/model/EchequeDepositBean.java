package com.icicibank.iMobileCA.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IMCA_ECHEQUE_DETAILS")

public class EchequeDepositBean {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="CUSTID")
	private String cusId;
	@Column(name="MOBILENO")
	private String mobileNo;
	@Column(name="BENEFICIARY_ACCOUNT")
	private String beneficiaryAccount;
	@Column(name="CHEQUE_AMOUNT")
	private BigDecimal chequeAmount;
	@Column(name="CHEQUE_DATE")
	private Timestamp chequeDate;
	@Column(name="CHEQUE_NUMBER")
	private String chequeNumber;
	@Column(name="TRANSIT_NUMBER")
	private String transitNo;
	@Column(name="INSTITUTION_ID")
	private String institutionId;
	@Column(name="ISSUER_ACC_NO")
	private String issuerAccNo;
	@Column(name="MEMO")
	private String memo;
	@Column(name="SUBMITTED_DATE")
	private Timestamp submittedDate;
	@Column(name="CLEARING_ZONE")
	private String clearingZone;
	@Column(name="REPORT_CODE")
	private String reportCode;
	@Column(name="TRAN_CODE")
	private String TranCode;
	@Column(name="IMAGE_FRONT_SIZE")
	private String frontImageSize;
	@Column(name="IMAGE_BACK_SIZE")
	private String backImageSize;
	@Column(name="IMAGE_FRONT_LOCATION")
	private String frontImagePath;
	@Column(name="IMAGE_BACK_LOCATION")
	private String backImagePath;
	@Column(name="STATUS")
	private String status;
	
	public String getCusId() {
		return cusId;
	}
	public void setCusId(String cusId) {
		this.cusId = cusId;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getBeneficiaryAccount() {
		return beneficiaryAccount;
	}
	public void setBeneficiaryAccount(String beneficiaryAccount) {
		this.beneficiaryAccount = beneficiaryAccount;
	}
	
	public Timestamp getChequeDate() {
		return chequeDate;
	}
	public void setChequeDate(Timestamp chequeDate) {
		this.chequeDate = chequeDate;
	}
	public String getChequeNumber() {
		return chequeNumber;
	}
	public void setChequeNumber(String chequeNumber) {
		this.chequeNumber = chequeNumber;
	}
	public String getTransitNo() {
		return transitNo;
	}
	public void setTransitNo(String transitNo) {
		this.transitNo = transitNo;
	}
	public String getInstitutionId() {
		return institutionId;
	}
	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}
	public String getIssuerAccNo() {
		return issuerAccNo;
	}
	public void setIssuerAccNo(String issuerAccNo) {
		this.issuerAccNo = issuerAccNo;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public Timestamp getSubmittedDate() {
		return submittedDate;
	}
	public void setSubmittedDate(Timestamp submittedDate) {
		this.submittedDate = submittedDate;
	}
	public String getClearingZone() {
		return clearingZone;
	}
	public void setClearingZone(String clearingZone) {
		this.clearingZone = clearingZone;
	}
	public String getReportCode() {
		return reportCode;
	}
	public void setReportCode(String reportCode) {
		this.reportCode = reportCode;
	}
	public String getTranCode() {
		return TranCode;
	}
	public void setTranCode(String tranCode) {
		TranCode = tranCode;
	}
	public String getFrontImageSize() {
		return frontImageSize;
	}
	public void setFrontImageSize(String frontImageSize) {
		this.frontImageSize = frontImageSize;
	}
	public String getBackImageSize() {
		return backImageSize;
	}
	public void setBackImageSize(String backImageSize) {
		this.backImageSize = backImageSize;
	}
	public String getFrontImagePath() {
		return frontImagePath;
	}
	public void setFrontImagePath(String frontImagePath) {
		this.frontImagePath = frontImagePath;
	}
	public String getBackImagePath() {
		return backImagePath;
	}
	public void setBackImagePath(String backImagePath) {
		this.backImagePath = backImagePath;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public BigDecimal getChequeAmount() {
		return chequeAmount;
	}
	public void setChequeAmount(BigDecimal chequeAmount) {
		this.chequeAmount = chequeAmount;
	}
	
}
