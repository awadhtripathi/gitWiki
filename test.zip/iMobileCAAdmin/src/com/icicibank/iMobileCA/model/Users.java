package com.icicibank.iMobileCA.model;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@Entity
@Table(name = "IMCA_USER_DETAILS")
public class Users {

	
	@Column(name = "USER_IDENTITY")
	private String userIdentity;

	@Column(name = "USER_NAME")
	private String userName;

	@Column(name = "EMPLOYEE_NO")
	private String employeeNo;

	@Column(name = "USER_ROLE")
	private String userRole;
    
	@Column(name="ACTIVE_STATUS")
	private String activeStatus;
	
	@Column(name = "STATUS")
	private String status;

	@Column(name = "VALID_UPTO")
	private String validUpto;

	@Column(name = "ISADMIN")
	private String isAdmin;

	@Column(name = "DISABLE_FLAGE")
	private String disableFlage;

	@Column(name = "MAKER")
	private String maker;

	@Column(name = "MAKER_DT")
	private Timestamp makerDt;

	@Column(name = "CHECKER")
	private String checker;

	@Column(name = "CHECKER_DT")
	private Timestamp checkerDt;

	@Column(name = "REASON")
	private String reason;

	

	public String getUserIdentity() {
		return userIdentity;
	}

	public void setUserIdentity(String userIdentity) {
		this.userIdentity = userIdentity;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmployeeNo() {
		return employeeNo;
	}

	public void setEmployeeNo(String employeeNo) {
		this.employeeNo = employeeNo;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getValidUpto() {
		return validUpto;
	}

	public void setValidUpto(String validUpto) {
		this.validUpto = validUpto;
	}

	public String getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(String isAdmin) {
		this.isAdmin = isAdmin;
	}

	public String getDisableFlage() {
		return disableFlage;
	}

	public void setDisableFlage(String disableFlage) {
		this.disableFlage = disableFlage;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public Timestamp getMakerDt() {
		return makerDt;
	}

	public void setMakerDt(Timestamp makerDt) {
		this.makerDt = makerDt;
	}

	public String getChecker() {
		return checker;
	}

	public void setChecker(String checker) {
		this.checker = checker;
	}

	public Timestamp getCheckerDt() {
		return checkerDt;
	}

	public void setCheckerDt(Timestamp checkerDt) {
		this.checkerDt = checkerDt;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(String activeStatus) {
		this.activeStatus = activeStatus;
	}

}
