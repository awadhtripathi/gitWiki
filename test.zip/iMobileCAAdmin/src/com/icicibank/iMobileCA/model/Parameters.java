package com.icicibank.iMobileCA.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "IMCA_GENERAL_PARAMS")
public class Parameters {
    @Id
	@Column(name = "ID")
	private int id;

	@Column(name = "PARAM")
	private String param;

	@Column(name = "PARAM_VALUE")
	private String paramValue;

	@Column(name = "ACTIVE")
	private String active;

	@Column(name = "ENVIRONMENT")
	private String environment;

	@Column(name = "MAKER")
	private String maker;

	@Column(name = "MAKER_DT")
	private Timestamp makerDt;

	@Column(name = "CHECKER")
	private String checker;

	@Column(name = "CHECKER_DT")
	private Timestamp checkerDt;

	@Column(name = "REASON")
	private String reason;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getParam() {
		return param;
	}

	public void setParam(String param) {
		this.param = param;
	}

	public String getParamValue() {
		return paramValue;
	}

	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public Timestamp getMakerDt() {
		return makerDt;
	}

	public void setMakerDt(Timestamp makerDt) {
		this.makerDt = makerDt;
	}

	public String getChecker() {
		return checker;
	}

	public void setChecker(String checker) {
		this.checker = checker;
	}

	public Timestamp getCheckerDt() {
		return checkerDt;
	}

	public void setCheckerDt(Timestamp checkerDt) {
		this.checkerDt = checkerDt;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

}
