package com.icicibank.iMobileCA.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IMCA_BRANCH_DETAILS_NEW")
public class Branches {

private static final long serialVersionUID = 1L;
	
	@Column(name="BRANCH_NAME")
	private String branchName;
	
	@Column(name="PROVINCE_CODE")
	private String provinceCode;
	@Column(name="ACTIVE")
	private String active;
	@Column(name="MAKER")
	private String maker;
	@Column(name="MAKERDT")
	private Timestamp makerDt;
	@Column(name="CHECKER")
	private String checker;
	@Column(name="CHECKER_DT")
	private Timestamp checkerDt;
	@Column(name="ADDRESS")
	private String address;
	@Column(name="TELEPHONE")
	private String telephone;
	@Column(name="FAX")
	private String fax;
	@Column(name="BRANCH_CODE")
	private String branchCode;
	
	@Column(name="POSTAL_CODE")
	private String postalCode;
	@Column(name="TIMINGS")
	private String timings;
	@Column(name="REASON")
	private String reason;
	@Id
	@Column(name="CITY_CODE")
	private String cityCode;
	@Column(name="LATITUDE")
	private String latitude;
	@Column(name="LONGITUDE")
	private String longitude;
	
	@Column(name="STATUS")
	private String status;

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getProvinceCode() {
		return provinceCode;
	}

	public void setProvinceCode(String provinceCode) {
		this.provinceCode = provinceCode;
	}
	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public Timestamp getMakerDt() {
		return makerDt;
	}

	public void setMakerDt(Timestamp makerDt) {
		this.makerDt = makerDt;
	}

	public String getChecker() {
		return checker;
	}

	public void setChecker(String checker) {
		this.checker = checker;
	}

	public Timestamp getCheckerDt() {
		return checkerDt;
	}

	public void setCheckerDt(Timestamp checkerDt) {
		this.checkerDt = checkerDt;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getTimings() {
		return timings;
	}

	public void setTimings(String timings) {
		this.timings = timings;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}
