package com.icicibank.iMobileCA.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

public class AddFields implements Serializable {

	/*private Boolean payeeName;
	private Boolean signature;
	private Boolean codeLine;
	private Boolean date;
	private Boolean amount;*/
	private String MIN_AMOUNT;
	private String MAX_AMOUNT;
	private String MAX_NO_OF_ECHEQUES;
	private String AMOUNT_PRESENCE;
	private String SIGNATURE;
	private String CODELINE;
	private String DATE_PRESENCE;
	private String UNDER_SIZE;
	private String OVER_SIZE;
	private String FOLDER_OR_TORN_CORNERS;
	private String TOO_LIGHT;
	private String TOO_DARK;
	private String SPOT_NOISE;
	private String OUT_OF_FOCUS;
	public String getMIN_AMOUNT() {
		return MIN_AMOUNT;
	}
	public void setMIN_AMOUNT(String mIN_AMOUNT) {
		MIN_AMOUNT = mIN_AMOUNT;
	}
	public String getMAX_AMOUNT() {
		return MAX_AMOUNT;
	}
	public void setMAX_AMOUNT(String mAX_AMOUNT) {
		MAX_AMOUNT = mAX_AMOUNT;
	}
	public String getMAX_NO_OF_ECHEQUES() {
		return MAX_NO_OF_ECHEQUES;
	}
	public void setMAX_NO_OF_ECHEQUES(String mAX_NO_OF_ECHEQUES) {
		MAX_NO_OF_ECHEQUES = mAX_NO_OF_ECHEQUES;
	}
	public String getAMOUNT_PRESENCE() {
		return AMOUNT_PRESENCE;
	}
	public void setAMOUNT_PRESENCE(String aMOUNT_PRESENCE) {
		AMOUNT_PRESENCE = aMOUNT_PRESENCE;
	}
	public String getSIGNATURE() {
		return SIGNATURE;
	}
	public void setSIGNATURE(String sIGNATURE) {
		SIGNATURE = sIGNATURE;
	}
	public String getCODELINE() {
		return CODELINE;
	}
	public void setCODELINE(String cODELINE) {
		CODELINE = cODELINE;
	}
	public String getDATE_PRESENCE() {
		return DATE_PRESENCE;
	}
	public void setDATE_PRESENCE(String dATE_PRESENCE) {
		DATE_PRESENCE = dATE_PRESENCE;
	}
	public String getUNDER_SIZE() {
		return UNDER_SIZE;
	}
	public void setUNDER_SIZE(String uNDER_SIZE) {
		UNDER_SIZE = uNDER_SIZE;
	}
	public String getOVER_SIZE() {
		return OVER_SIZE;
	}
	public void setOVER_SIZE(String oVER_SIZE) {
		OVER_SIZE = oVER_SIZE;
	}
	public String getFOLDER_OR_TORN_CORNERS() {
		return FOLDER_OR_TORN_CORNERS;
	}
	public void setFOLDER_OR_TORN_CORNERS(String fOLDER_OR_TORN_CORNERS) {
		FOLDER_OR_TORN_CORNERS = fOLDER_OR_TORN_CORNERS;
	}
	public String getTOO_LIGHT() {
		return TOO_LIGHT;
	}
	public void setTOO_LIGHT(String tOO_LIGHT) {
		TOO_LIGHT = tOO_LIGHT;
	}
	public String getTOO_DARK() {
		return TOO_DARK;
	}
	public void setTOO_DARK(String tOO_DARK) {
		TOO_DARK = tOO_DARK;
	}
	public String getSPOT_NOISE() {
		return SPOT_NOISE;
	}
	public void setSPOT_NOISE(String sPOT_NOISE) {
		SPOT_NOISE = sPOT_NOISE;
	}
	public String getOUT_OF_FOCUS() {
		return OUT_OF_FOCUS;
	}
	public void setOUT_OF_FOCUS(String oUT_OF_FOCUS) {
		OUT_OF_FOCUS = oUT_OF_FOCUS;
	}
	
	/*@Column(name="im_timeGeneratede")
	private Timestamp timeGenerated;*/

	
	
}
