package com.icicibank.iMobileCA.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IMCA_MENU_DETAILS")
public class MenuItem {

	private static final long serialVersionUID = 1L;

	@Column(name = "MENU_NAME")
	private String menuName;
	@Id
	@Column(name = "MENU_ID")
	private String menuId;
	@Column(name = "MENU_STATUS")
	private String menuStatus;
	@Column(name = "MAKER")
	private String maker;
	@Column(name = "MAKER_DT")
	private Timestamp makerDt;
	@Column(name = "CHECKER")
	private String checker;
	@Column(name = "CHECKER_DT")
	private Timestamp checkerDt;
	@Column(name = "REASON")
	private String reason;
	@Column(name = "STATUS")
	private String status;

	public String getMenuName() {
		return menuName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	public String getMenuId() {
		return menuId;
	}

	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	public String getMenuStatus() {
		return menuStatus;
	}

	public void setMenuStatus(String menuStatus) {
		this.menuStatus = menuStatus;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public Timestamp getMakerDt() {
		return makerDt;
	}

	public void setMakerDt(Timestamp makerDt) {
		this.makerDt = makerDt;
	}

	public String getChecker() {
		return checker;
	}

	public void setChecker(String checker) {
		this.checker = checker;
	}

	public Timestamp getCheckerDt() {
		return checkerDt;
	}

	public void setCheckerDt(Timestamp checkerDt) {
		this.checkerDt = checkerDt;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "MenuItem [menuName=" + menuName + ", menuId=" + menuId
				+ ", menuStatus=" + menuStatus + ", maker=" + maker
				+ ", makerDt=" + makerDt + ", checker=" + checker
				+ ", checkerDt=" + checkerDt + ", reason=" + reason
				+ ", status=" + status + "]";
	}

}
