package com.icicibank.iMobileCA.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IMCA_ACC_SCHEME_CODE")
public class Scheme {
	
	@Column(name = "SCHEME_NAME")
	private String schemeName;
	
	@Column(name = "ACC_TYPE")
	private String accType;
	
	@Column(name = "DESCRIPTION")
	private String description;
	
	@Id
	@Column(name = "SCHEME_CODE")
	private String schemeCode;
	
	@Column(name = "SCHEME_TYPE")
	private String schemeType;
	
	@Column(name = "ACTIVE")
	private String active;
	
	@Column(name = "MAKER")
	private String maker;
	
	@Column(name = "MAKER_DT")
	private Timestamp makerDt;
	
	@Column(name = "CHECKER")
	private String checker;
	
	@Column(name = "CHECKER_DT")
	private Timestamp checkerDt;
	
	@Column(name = "REASON")
	private String reason;
	
	@Column(name = "STATUS")
	private String status;

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSchemeName() {
		return schemeName;
	}

	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}

	public String getSchemeCode() {
		return schemeCode;
	}

	public void setSchemeCode(String schemeCode) {
		this.schemeCode = schemeCode;
	}

	public String getSchemeType() {
		return schemeType;
	}

	public void setSchemeType(String schemeType) {
		this.schemeType = schemeType;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public Timestamp getMakerDt() {
		return makerDt;
	}

	public void setMakerDt(Timestamp makerDt) {
		this.makerDt = makerDt;
	}

	public String getChecker() {
		return checker;
	}

	public void setChecker(String checker) {
		this.checker = checker;
	}

	public Timestamp getCheckerDt() {
		return checkerDt;
	}

	public void setCheckerDt(Timestamp checkerDt) {
		this.checkerDt = checkerDt;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
