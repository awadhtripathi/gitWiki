package com.icicibank.iMobileCA.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IMCA_ECHEQUE_ATTEMPTS")
public class Attempts {
	@Id
	@Column(name="CIFNUMBER")
	private String CIFNumber;
	@Column(name="MOBILENO")
	private String mobileNo;
	@Column(name="BENEFICIARY_ACCOUNT")
	private String beneficiaryAccount;
	@Column(name="CHEQUE_DATE")
	private Timestamp chequeDate;
	@Column(name="CHEQUE_AMOUNT")
	private BigDecimal chequeAmount;
	@Column(name="CHEQUE_NUMBER")
	private String chequeNumber;
	@Column(name="TRANSIT_NUMBER")
	private String transitNumber;
	@Column(name="INSTITUTION_ID")
	private String institutionId;
	@Column(name="ISSUER_ACC_NO")//
	private String issuerAccNo;
	@Column(name="MEMO")
	private String memo;
	@Column(name="SUBMITTED_DATE")
	private Timestamp submittedDate;
	@Column(name="REASON")
	private String reason;
	@Column(name="STATUS")
	private String status;
	@Column(name="CLEARING_ZONE")
	private String clearingZone;
	@Column(name="REFERENCENUMBER")
	private String referenceNumber;
	@Column(name="MAKER")
	private String maker;
	@Column(name="MAKERDT")
	private Timestamp makerDt;
	@Column(name="CHECKER")
	private String checker;
	@Column(name="CHECKER_DT")
	private Timestamp checkerDt;
	@Column(name="CHANGED_STATUS")
	private String changedStatus;
	
	@Column(name="AUTHORING_STATUS")
	private String authStatus;
	
	public String getAuthStatus() {
		return authStatus;
	}
	public void setAuthStatus(String authStatus) {
		this.authStatus = authStatus;
	}
	public String getChangedStatus() {
		return changedStatus;
	}
	public void setChangedStatus(String changedStatus) {
		this.changedStatus = changedStatus;
	}
	public String getReferenceNumber() {
		return referenceNumber;
	}
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}
	public String getClearingZone() {
		return clearingZone;
	}
	public void setClearingZone(String clearingZone) {
		this.clearingZone = clearingZone;
	}
	public BigDecimal getChequeAmount() {
		return chequeAmount;
	}
	public void setChequeAmount(BigDecimal chequeAmount) {
		this.chequeAmount = chequeAmount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getCIFNumber() {
		return CIFNumber;
	}
	public void setCIFNumber(String cIFNumber) {
		CIFNumber = cIFNumber;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getBeneficiaryAccount() {
		return beneficiaryAccount;
	}
	public void setBeneficiaryAccount(String beneficiaryAccount) {
		this.beneficiaryAccount = beneficiaryAccount;
	}
	public Timestamp getChequeDate() {
		return chequeDate;
	}
	public void setChequeDate(Timestamp chequeDate) {
		this.chequeDate = chequeDate;
	}
	public String getChequeNumber() {
		return chequeNumber;
	}
	public void setChequeNumber(String chequeNumber) {
		this.chequeNumber = chequeNumber;
	}
	public String getTransitNumber() {
		return transitNumber;
	}
	public void setTransitNumber(String transitNumber) {
		this.transitNumber = transitNumber;
	}
	public String getInstitutionId() {
		return institutionId;
	}
	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}
	public String getIssuerAccNo() {
		return issuerAccNo;
	}
	public void setIssuerAccNo(String issuerAccNo) {
		this.issuerAccNo = issuerAccNo;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public Timestamp getSubmittedDate() {
		return submittedDate;
	}
	public void setSubmittedDate(Timestamp submittedDate) {
		this.submittedDate = submittedDate;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getMaker() {
		return maker;
	}
	public void setMaker(String maker) {
		this.maker = maker;
	}
	public Timestamp getMakerDt() {
		return makerDt;
	}
	public void setMakerDt(Timestamp makerDt) {
		this.makerDt = makerDt;
	}
	public String getChecker() {
		return checker;
	}
	public void setChecker(String checker) {
		this.checker = checker;
	}
	public Timestamp getCheckerDt() {
		return checkerDt;
	}
	public void setCheckerDt(Timestamp checkerDt) {
		this.checkerDt = checkerDt;
	}
	
	
}
