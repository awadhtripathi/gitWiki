package com.icicibank.iMobileCA.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import oracle.sql.CLOB;

@Entity
@Table(name = "ADMIN_AUDIT_TRAIL_DTL")
public class AuditLog {
	private static final long serialVersionUID = 1L;	
	@Id
	@Column(name = "TABLE_NAME")
	private String tableName;
	
	@Column(name="REQUEST")
	private String request;
	
	/*@Column(name="COLUMN_NAME")
	private String columnName;
	
	@Column(name="OLD_VALUE")
	private String oldValue;
	
	@Column(name="NEW_VALUE")
	private String newValue;
	*/
	/*@Column(name="BANK_ID")
	private String bankId;*/
	
	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	@Column(name="MAKER_CD")
	private String makerCd;
	
	@Column(name="MAKER_DT")
	private Timestamp makerDt;
	
	/*@Column(name="USER_ID")
	private String userId;
	
	@Column(name="USER_ROLE")
	private String userRole;
	
	@Column(name="USER_DT")
	private Timestamp userDt;
	
	@Column(name="AUTH_STATUS")
	private String authStatus;*/
	
	@Column(name="AUTHOR_CD")
	private String authorCd;
	
	@Column(name="OPERATION")
	private String operation;
	
	@Column(name="AUTHOR_DT")
	private Timestamp authorDt;

	
	/*public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public Timestamp getUserDt() {
		return userDt;
	}

	public void setUserDt(Timestamp userDt) {
		this.userDt = userDt;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getOldValue() {
		return oldValue;
	}

	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}

	public String getNewValue() {
		return newValue;
	}

	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}*/

	/*public CLOB getRequest() {
		return request;
	}

	public void setRequest(CLOB request) {
		this.request = request;
	}*/

	public String getAuthorCd() {
		return authorCd;
	}

	public void setAuthorCd(String authorCd) {
		this.authorCd = authorCd;
	}

//	public String getAuthStatus() {
//		return authStatus;
//	}
//
//	public void setAuthStatus(String authStatus) {
//		this.authStatus = authStatus;
//	}

	public Timestamp getAuthorDt() {
		return authorDt;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getMakerCd() {
		return makerCd;
	}

	public void setMakerCd(String makerCd) {
		this.makerCd = makerCd;
	}

	public Timestamp getMakerDt() {
		return makerDt;
	}

	public void setMakerDt(Timestamp makerDt) {
		this.makerDt = makerDt;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public void setAuthorDt(Timestamp authorDt) {
		this.authorDt = authorDt;
	}
	
	

}
