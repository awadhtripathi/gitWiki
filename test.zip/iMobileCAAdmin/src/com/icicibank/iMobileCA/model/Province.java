package com.icicibank.iMobileCA.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IMCA_PROVINCE_DETAILS")
public class Province {
	private static final long serialVersionUID = 1L;
	
	@Column(name="PROVINCE_NAME")
	private String provinceName;
	@Id
	@Column(name="PROVINCE_CODE")
	private String provinceCode;
	@Column(name="ACTIVE")
	private String active;
	@Column(name="MAKER")
	private String maker;
	@Column(name="MAKERDT")
	private Timestamp makerDt;
	@Column(name="CHECKER")
	private String checker;
	@Column(name="CHECKER_DT")
	private Timestamp checkerDt;
	@Column(name="REASON")
	private String reason;
	@Column(name="STATUS")
	private String status;
	
	private int cityCount;
	
	public int getCityCount() {
		return cityCount;
	}
	public void setCityCount(int cityCount) {
		this.cityCount = cityCount;
	}
	public String getProvinceName() {
		return provinceName;
	}
	public void setProvinceName(String provinceName) {
		this.provinceName = provinceName;
	}
	public String getProvinceCode() {
		return provinceCode;
	}
	public void setProvinceCode(String provinceCode) {
		this.provinceCode = provinceCode;
	}
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	public String getMaker() {
		return maker;
	}
	public void setMaker(String maker) {
		this.maker = maker;
	}
	public Timestamp getMakerDt() {
		return makerDt;
	}
	public void setMakerDt(Timestamp makerDt) {
		this.makerDt = makerDt;
	}
	public String getChecker() {
		return checker;
	}
	public void setChecker(String checker) {
		this.checker = checker;
	}
	public Timestamp getCheckerDt() {
		return checkerDt;
	}
	public void setCheckerDt(Timestamp checkerDt) {
		this.checkerDt = checkerDt;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
