package com.icicibank.iMobileCA.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IMCA_CUST_DEVICES")
public class CustomerDevice {

	@Override
	public String toString() {
		return "CustomerDevice [bay_User_Id=" + bay_User_Id + ", wl_Device_Id="
				+ wl_Device_Id + ", device_Os_Version=" + device_Os_Version
				+ ", device_Os_Type=" + device_Os_Type + ", app_Version="
				+ app_Version + ", device_Status_Flag=" + device_Status_Flag
				+ ", last_Login_Success_Dt=" + last_Login_Success_Dt
				+ ", touch_Enabled=" + touch_Enabled + ", first_Activated_Dt="
				+ first_Activated_Dt + ", last_ReActivated_Dt="
				+ last_ReActivated_Dt + ", OTP_Status=" + OTP_Status
				+ ", OTP_Verification_Dt=" + OTP_Verification_Dt
				+ ", device_Blocked_By=" + device_Blocked_By
				+ ", device_Blocked_Reaon=" + device_Blocked_Reaon
				+ ", device_Blocked_Dt=" + device_Blocked_Dt
				+ ", device_Model=" + device_Model + ", user_Agent="
				+ user_Agent + ", GCM_Key=" + GCM_Key + ", X_Id=" + X_Id + "]";
	}

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "BAYUSERID")
	private String bay_User_Id;
	
	@Column(name = "WLDEVICEID")
	private String wl_Device_Id;
	
	@Column(name = "DEVICE_OS_VERSION")
	private String device_Os_Version;
	
	@Column(name = "DEVICE_OS_TYPE")
	private String device_Os_Type;
	
	@Column(name = "APP_VERSION")
	private String app_Version;
	
	@Column(name = "DEVICE_STATUS_FLAG")
	private BigDecimal device_Status_Flag;
	
	@Column(name = "LAST_LOGIN_SUCCESS_DATE")
	private Timestamp last_Login_Success_Dt;
	
	@Column(name = "TOUCH_ENABLED")
	private BigDecimal touch_Enabled;
	
	@Column(name = "FIRST_ACTIVATED_DATE")
	private Timestamp first_Activated_Dt;
	
	@Column(name = "LAST_REACTIVATED_DATE")
	private Timestamp last_ReActivated_Dt;
	
	@Column(name = "OTP_STATUS")
	private BigDecimal OTP_Status;
	
	@Column(name = "OTP_VERIFICATION_DATE")
	private Timestamp OTP_Verification_Dt;
	
	@Column(name = "DEVICE_BLOCKEDBY")
	private String device_Blocked_By;
	
	@Column(name = "DEVICE_BLOCKED_REASON")
	private String device_Blocked_Reaon;
	
	@Column(name = "DEVICE_BLOCKED_DATE")
	private Timestamp device_Blocked_Dt;
	
	@Column(name = "DEVICE_MODEL")
	private String device_Model;
	
	@Column(name = "USERAGENT")
	private String user_Agent;
	
	@Column(name = "GCMKEY")
	private String GCM_Key;
	
	@Column(name = "XID")
	private String X_Id;

	public String getBay_User_Id() {
		return bay_User_Id;
	}

	public void setBay_User_Id(String bay_User_Id) {
		this.bay_User_Id = bay_User_Id;
	}

	public String getWl_Device_Id() {
		return wl_Device_Id;
	}

	public void setWl_Device_Id(String wl_Device_Id) {
		this.wl_Device_Id = wl_Device_Id;
	}

	public String getDevice_Os_Version() {
		return device_Os_Version;
	}

	public void setDevice_Os_Version(String device_Os_Version) {
		this.device_Os_Version = device_Os_Version;
	}

	public String getDevice_Os_Type() {
		return device_Os_Type;
	}

	public void setDevice_Os_Type(String device_Os_Type) {
		this.device_Os_Type = device_Os_Type;
	}

	public String getApp_Version() {
		return app_Version;
	}

	public void setApp_Version(String app_Version) {
		this.app_Version = app_Version;
	}

	public BigDecimal getDevice_Status_Flag() {
		return device_Status_Flag;
	}

	public void setDevice_Status_Flag(BigDecimal device_Status_Flag) {
		this.device_Status_Flag = device_Status_Flag;
	}

	public Timestamp getLast_Login_Success_Dt() {
		return last_Login_Success_Dt;
	}

	public void setLast_Login_Success_Dt(Timestamp last_Login_Success_Dt) {
		this.last_Login_Success_Dt = last_Login_Success_Dt;
	}

	public BigDecimal getTouch_Enabled() {
		return touch_Enabled;
	}

	public void setTouch_Enabled(BigDecimal touch_Enabled) {
		this.touch_Enabled = touch_Enabled;
	}

	public Timestamp getFirst_Activated_Dt() {
		return first_Activated_Dt;
	}

	public void setFirst_Activated_Dt(Timestamp first_Activated_Dt) {
		this.first_Activated_Dt = first_Activated_Dt;
	}

	public Timestamp getLast_ReActivated_Dt() {
		return last_ReActivated_Dt;
	}

	public void setLast_ReActivated_Dt(Timestamp last_ReActivated_Dt) {
		this.last_ReActivated_Dt = last_ReActivated_Dt;
	}

	public BigDecimal getOTP_Status() {
		return OTP_Status;
	}

	public void setOTP_Status(BigDecimal oTP_Status) {
		OTP_Status = oTP_Status;
	}

	public Timestamp getOTP_Verification_Dt() {
		return OTP_Verification_Dt;
	}

	public void setOTP_Verification_Dt(Timestamp oTP_Verification_Dt) {
		OTP_Verification_Dt = oTP_Verification_Dt;
	}

	public String getDevice_Blocked_By() {
		return device_Blocked_By;
	}

	public void setDevice_Blocked_By(String device_Blocked_By) {
		this.device_Blocked_By = device_Blocked_By;
	}

	public String getDevice_Blocked_Reaon() {
		return device_Blocked_Reaon;
	}

	public void setDevice_Blocked_Reaon(String device_Blocked_Reaon) {
		this.device_Blocked_Reaon = device_Blocked_Reaon;
	}

	public Timestamp getDevice_Blocked_Dt() {
		return device_Blocked_Dt;
	}

	public void setDevice_Blocked_Dt(Timestamp device_Blocked_Dt) {
		this.device_Blocked_Dt = device_Blocked_Dt;
	}

	public String getDevice_Model() {
		return device_Model;
	}

	public void setDevice_Model(String device_Model) {
		this.device_Model = device_Model;
	}

	public String getUser_Agent() {
		return user_Agent;
	}

	public void setUser_Agent(String user_Agent) {
		this.user_Agent = user_Agent;
	}

	public String getGCM_Key() {
		return GCM_Key;
	}

	public void setGCM_Key(String gCM_Key) {
		GCM_Key = gCM_Key;
	}

	public String getX_Id() {
		return X_Id;
	}

	public void setX_Id(String x_Id) {
		X_Id = x_Id;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
