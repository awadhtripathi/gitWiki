package com.icicibank.iMobileCA.model;

import java.util.List;

public class CitiesListResponse {
	
	private List<Cities> citiesList;

	public List<Cities> getCitiesList() {
		return citiesList;
	}

	public void setCitiesList(List<Cities> citiesList) {
		this.citiesList = citiesList;
	}

}
