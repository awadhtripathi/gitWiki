package com.icicibank.iMobileCA.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IMCA_TRANSATION_RANGE")
public class Limits implements Serializable {

	private static final long serialVersionUID = 1L;
	/*@Column(name="im_payeeName")
	private Boolean payeeName;*/
	@Id
	@Column(name="LIMIT_TYPE")
	private String limitType;
	@Column(name="TXN_TYPE")
	private String txnType;
	@Column(name="ACTIVE")
	private String active;
	@Column(name="LIMIT")
	private String limit;
	@Column(name="MAKER")
	private String maker;
	@Column(name="MAKERDT")
	private Timestamp makerDt;
	@Column(name="CHECKER")
	private String checker;
	@Column(name="CHECKER_DT")
	private Timestamp checkerDt;
	@Column(name="REASON")
	private String reason;
	@Column(name="LIMIT_VALUE")
	private String limitValue;
	@Column(name="CHANGED_VALUE")
	private String changedValue;
	@Column(name="AUTHORING_STATUS")
	private String authoringStatus;
	
	public String getLimitType() {
		return limitType;
	}
	public void setLimitType(String limitType) {
		this.limitType = limitType;
	}
	
	public String getLimit() {
		return limit;
	}
	public void setLimit(String limit) {
		this.limit = limit;
	}
	public String getTxnType() {
		return txnType;
	}
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	public String getMaker() {
		return maker;
	}
	public void setMaker(String maker) {
		this.maker = maker;
	}
	public Timestamp getMakerDt() {
		return makerDt;
	}
	public void setMakerDt(Timestamp makerDt) {
		this.makerDt = makerDt;
	}
	public String getChecker() {
		return checker;
	}
	public void setChecker(String checker) {
		this.checker = checker;
	}
	public Timestamp getCheckerDt() {
		return checkerDt;
	}
	public void setCheckerDt(Timestamp checkerDt) {
		this.checkerDt = checkerDt;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getLimitValue() {
		return limitValue;
	}
	public void setLimitValue(String limitValue) {
		this.limitValue = limitValue;
	}
	
	public String getChangedValue() {
		return changedValue;
	}
	public void setChangedValue(String changedValue) {
		this.changedValue = changedValue;
	}
	public String getAuthoringStatus() {
		return authoringStatus;
	}
	public void setAuthoringStatus(String authoringStatus) {
		this.authoringStatus = authoringStatus;
	}
	
	
}
