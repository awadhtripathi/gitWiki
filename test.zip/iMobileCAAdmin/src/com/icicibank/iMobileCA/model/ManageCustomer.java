package com.icicibank.iMobileCA.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IMCA_CUSTOMERS")
public class ManageCustomer {
	
	@Id
	@Column(name = "ID")
	private String id;
	
	@Column(name = "CUSTID")
	private String custId;
	
	@Column(name = "CUST_ALIAS_NAME")
	private String custAliasName;
	
	@Column(name = "MOBILENO")
	private String mobileNo;
	
	@Column(name = "REG_DATE")
	private Timestamp regDt;
	
	@Column(name = "TOKENID")
	private String tokenId;
	
	@Column(name = "INVALID_LOGIN_ATTEMPTS")
	private int invalidLoginAttempts;
	
	@Column(name = "LOCKED")
	private String locked;
	
	@Column(name = "UPDATED_DATE")
	private Timestamp updatedDt;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getCustAliasName() {
		return custAliasName;
	}

	public void setCustAliasName(String custAliasName) {
		this.custAliasName = custAliasName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Timestamp getRegDt() {
		return regDt;
	}

	public void setRegDt(Timestamp regDt) {
		this.regDt = regDt;
	}

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public int getInvalidLoginAttempts() {
		return invalidLoginAttempts;
	}

	public void setInvalidLoginAttempts(int invalidLoginAttempts) {
		this.invalidLoginAttempts = invalidLoginAttempts;
	}

	public String getLocked() {
		return locked;
	}

	public void setLocked(String locked) {
		this.locked = locked;
	}

	public Timestamp getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(Timestamp updatedDt) {
		this.updatedDt = updatedDt;
	}
	
}
