package com.icicibank.iMobileCA.service;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.icicibank.iMobileCA.dao.BranchMasterDAO;
import com.icicibank.iMobileCA.model.Branches;
import com.icicibank.iMobileCA.model.Cities;

public class BranchMasterService {
	@Autowired
	private BranchMasterDAO branchMasterDAO;
	ServletContext servletContext;
	private static final Logger logWriter = Logger
			.getLogger(BranchMasterService.class.getName());
	private HttpSession session;
	
	public void setBranchMasterDAO(BranchMasterDAO branchMasterDAO) {
		this.branchMasterDAO = branchMasterDAO;
	}
	public List<Cities> getCity(){
		logWriter.info("In updateAddFields param : ");
		return branchMasterDAO.getCityList();
	}
	public List<Branches> getBranchDetails() {
		logWriter.info("Getting Fields Data List");
		return branchMasterDAO.getBranchDetails();
	}
	public List<Branches> getBranchDetailsForAuthor(String userId) {
		logWriter.info("Getting Fields Data List");
		return branchMasterDAO.getBranchDetailsForAuthoring(userId);
	}
	public int saveBranch(Branches b,String s){
		logWriter.info("In UserAction Service saveAddFields");
		return branchMasterDAO.addBranch(b,s);
	}
	public int rejectBranch(Branches b){
		logWriter.info("In UserAction Service rejectBranch");
		return branchMasterDAO.rejectBranch(b);
	}
	public int authorBranch(Branches a){
		logWriter.info("In UserAction Service saveAddFields");
		return branchMasterDAO.authorBranch(a);
	}
	public List<Branches> searchBranch(Branches a){
		logWriter.info("In UserAction Service saveAddFields");
		return branchMasterDAO.searchBranch(a);
	}
	public int updateBranch(Branches v){
		logWriter.info("In updateAddFields param : "+v);
		return branchMasterDAO.updateBranch(v);
	}
	
}
