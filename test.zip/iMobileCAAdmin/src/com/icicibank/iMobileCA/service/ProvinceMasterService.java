package com.icicibank.iMobileCA.service;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icicibank.iMobileCA.dao.ProvinceMasterDAO;
import com.icicibank.iMobileCA.model.Province;

@Service
public class ProvinceMasterService {
	@Autowired
	private ProvinceMasterDAO provinceMasterDAO;

	public void setProvinceMasterDAO(ProvinceMasterDAO provinceMasterDAO) {
		this.provinceMasterDAO = provinceMasterDAO;
	}

	ServletContext servletContext;
	private static final Logger logWriter = Logger
			.getLogger(ProvinceMasterService.class.getName());
	private HttpSession session;

	public List<Province> getProvinceDetails() {
		logWriter.info("Getting Fields Data List");
		return provinceMasterDAO.getProvinceDetails();
	}

	public List<Province> getAuthorizedProvinceDetails() {
		logWriter.info("Getting Fields Data List");
		return provinceMasterDAO.getAuthorizedProvinceDetails();
	}

	public Province viewProvince(String provinceCode, String status) {
		logWriter.info("In MenuMaster Service view menu param : "
				+ provinceCode + " " + status);
		return provinceMasterDAO.viewProvince(provinceCode, status);
	}

	public List<Province> getProvinceDetailsForAuthor(String userId) {
		logWriter.info("Getting Fields Data List");
		return provinceMasterDAO.getProvinceDetailsForAuthoring(userId);
	}

	public int saveProvince(Province a, String param) {
		logWriter.info("In UserAction Service saveAddFields");
		return provinceMasterDAO.addProvince(a, param);
	}

	public int authorProvince(Province a) {
		logWriter.info("In UserAction Service saveAddFields");
		return provinceMasterDAO.authorProvince(a);
	}
	public int rejectProvince(Province a) {
		logWriter.info("In UserAction Service rejectProvince");
		return provinceMasterDAO.rejectProvince(a);
	}
	
	public List<Province> searchProvince(Province a) {
		logWriter.info("In UserAction Service saveAddFields");
		return provinceMasterDAO.searchProvince(a);
	}

	public int updateProvince(Province v) {
		logWriter.info("In updateAddFields param : " + v);
		return provinceMasterDAO.updateProvince(v);
	}

	public int deleteProvince(Province v) {
		logWriter.info("In updateAddFields param : " + v);
		return provinceMasterDAO.deleteProvince(v);
	}
}
