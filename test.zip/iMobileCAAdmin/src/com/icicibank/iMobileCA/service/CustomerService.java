package com.icicibank.iMobileCA.service;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icicibank.iMobileCA.dao.CustomerDAO;
import com.icicibank.iMobileCA.model.Customer;
import com.icicibank.iMobileCA.model.CustomerDevice;
import com.icicibank.iMobileCA.model.ManageCustomer;

@Service
public class CustomerService {

	@Autowired
	private CustomerDAO customerDAO;
	ServletContext servletContext;

	private static final Logger logWriter = Logger
			.getLogger(CustomerService.class.getName());

	private HttpSession session;

	public void setCustomerDAO(CustomerDAO customerDAO) {
		this.customerDAO = customerDAO;
	}

	public List<Customer> getCustomerDetails() {
		logWriter.info("In CustomerService Getting Fields Data List");
		return customerDAO.getCustomerDetails();
	}

	public Customer getCustomer(String custMobileNo, String custID, String selected) {
		logWriter.info("In CustomerService  Getting Fields Data");
		return customerDAO.getCustomer(custMobileNo, custID, selected);
	}

	public List<Customer> searchCustomer(String custMobileNo,
			String custID) {
		logWriter.info("In CustomerService searching cusotmer param :"
				+ custMobileNo + " " + custID);
		return customerDAO.searchCustomer(custMobileNo, custID);
	}

	public Customer getCustomerForUpdate(String custID) {
		logWriter.info("In CustomerService  Getting Fields Data");
		return customerDAO.getCustomerForUpdate(custID);
	}

	public List<CustomerDevice> getCustomerDevice(String bayUserId) {
		 logWriter.info("In CustomerService getting customer devices param : " + bayUserId);
		return  customerDAO.getCustomerDevice(bayUserId);
	}

	public int blockDevice(CustomerDevice device) {
		 logWriter.info("In CustomerService blocking customer device param : " +device.toString());
		return customerDAO.blockDevice(device);
		
	}
	
	public String getUrl(String type) {
		logWriter.info("Getting URL ");
		return customerDAO.getUrl(type);
	}

}
