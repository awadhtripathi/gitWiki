package com.icicibank.iMobileCA.service;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Properties;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.io.FileUtils;
//import org.apache.commons.collections.map.HashedMap;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.icicibank.iMobileCA.dao.UserActionDAO;
import com.icicibank.iMobileCA.model.Attempts;
import com.icicibank.iMobileCA.model.AuditLog;
import com.icicibank.iMobileCA.model.EchequeDepositBean;
import com.icicibank.iMobileCA.model.ExchangeATMs;
import com.icicibank.iMobileCA.model.Limits;
import com.icicibank.iMobileCA.util.CommonUtil;
import com.icicibank.iMobileCA.util.ZipDownloadServlet;

@Service
// @SuppressWarnings("all")
public class UserActionService {

	@Autowired
	private UserActionDAO userActionDAO;
	ServletContext servletContext;
	private static final Logger logWriter = Logger
			.getLogger(UserActionService.class.getName());
	private HttpSession session;
	public void setUserDetailsDAO(UserActionDAO userActionDAO) {
		this.userActionDAO = userActionDAO;
	}

	@Resource(name = "imbcaproperties")
	private Properties imbcaproperties;
	//@Transactional(readOnly = true)
	/*public List<AdminUser> getAdminUserDetailList(String adminId) {
		logWriter.info("In getAdminUserDetailList adminId: "+adminId);
		return userActionDAO.getAdminUserDtls(adminId);
	}*/

	public int updateLastLogin(String userId, String password,Timestamp currentTime) {
		int updateCount = userActionDAO.updateLastLogin(userId,password,currentTime);
		return updateCount;
	}
	public void updateAuditLog(AuditLog auditlist) {
		 userActionDAO.updateAuditLogStatus(auditlist);
		//return updateCount;
	}
	public void updateAuditLog(List<AuditLog> auditlist) {
		 userActionDAO.updateAuditLogStatus(auditlist);
		//return updateCount;
	}
	public String getLastLogin(String userId) {
		String updateCount = userActionDAO.getLastLogin(userId);
		return updateCount;
	}
	//@Transactional(readOnly = true)
	public List<Limits> getFieldsData() {
		logWriter.info("Getting Fields Data List");
		return userActionDAO.getFields();
	}
	public List<Attempts> getZoneData() {
		logWriter.info("Getting Fields Data List");
		return userActionDAO.getZones();
	}
	
	/*public List<Limits> getFieldsDataByType(Limits limit) {
		logWriter.info("Getting Fields Data List");
		return userActionDAO.getFieldsByType(limit);
	}*/
	//@Transactional(readOnly = true)
	/*public List<Limits> getAuthoringFields() {
		logWriter.info("Getting Fields Data List");
		return userActionDAO.getFieldsForAuthor();
	}*/
	public List<Limits> getAuthoringField(String userId) {
		logWriter.info("Getting Fields Data List");
		return userActionDAO.getFieldsForAuthoring(userId);
	}
	//@Transactional(readOnly = true)
	/*public List<EchequeDepositBean> getImageLocation(Date fromDate,Date toDate) throws Exception {
		logWriter.info("In saveMediaService param : "+fromDate+""+toDate);
		return userActionDAO.getImageLocation(fromDate,toDate);
	}*/
	//@Transactional(readOnly = true)
	public List<List<EchequeDepositBean>> generateRequestPacket(Timestamp toDate) throws Exception{
		logWriter.info("In generateRequestPacket fromDate : "+" toDate"+toDate);
		return userActionDAO.generateRequestPacketData( toDate);
	}
	public List<EchequeDepositBean> generateRequestPacketForZone(Timestamp toDate,String zone) throws Exception{
		logWriter.info("In generateRequestPacket fromDate : "+zone);
		return userActionDAO.generateRequestPacketDataForZone(toDate,zone);
	}
	public String getCuttOffTime(){
		logWriter.info("In updateAddFields param : ");
		return userActionDAO.getCuttOffTime();
	}
	
	public int updateFields(List<Limits> v){
		logWriter.info("In updateAddFields param : "+v);
		return userActionDAO.updateField(v);
	}
	
	public int authorFields(List<Limits> v){
		logWriter.info("In updateAddFields param : "+v);
		 return userActionDAO.authorField(v);
	}
	public int authorLimits(List<Limits> v){
		logWriter.info("In updateAddFields param : "+v);
		 return userActionDAO.authorLimit(v);
	}
	public int updateEchequeDetails(EchequeDepositBean v){
		logWriter.info("In updateEchequeDetails param : "+v);
		return userActionDAO.updateEchequeDetails(v);
	}
	public int ABMDataUpload(ExchangeATMs v){
		logWriter.info("In updateAddFields param : "+v);
		return userActionDAO.updateABMData(v);
	}
	public void saveFields(Limits a){
		logWriter.info("In UserAction Service saveAddFields");
		userActionDAO.addField(a);
	}
	/*public int checkFields(Limits request) {
		logWriter.info("checkPayee--------");
		return userActionDAO.checkField(request);
	}*/
	public List<Attempts> getFailureEchequeAttempts(Date fromDate,Date toDate) {
		logWriter.info("Getting EchequeAttempts Data List");
		return userActionDAO.getFailureEchequeAttempts(fromDate,toDate);
	}
	public List<Attempts> getReportForCustomerActivities(Date fromDate,Date toDate,String mobileNumber) {
		logWriter.info("Getting EchequeAttempts Data List");
		return userActionDAO.getReportForCustomerActivities(fromDate,toDate,mobileNumber);
	}
	public List<Attempts> getReportForCustomerActivitiesWithStatus(Date fromDate,Date toDate) {
		logWriter.info("Getting EchequeAttempts Data List");
		return userActionDAO.getReportForCustomerActivitiesWithStatus(fromDate,toDate);
	}
	public List<Attempts> getCustomerSuccessReport(Date fromDate,Date toDate,String mobileNumber,String status) {
		logWriter.info("Getting EchequeAttempts Data List");
		return userActionDAO.getCustomerSuccessReport(fromDate,toDate,mobileNumber,status);
	}
	public List<Attempts> getCustomerFailureReport(Date fromDate,Date toDate,String mobileNumber) {
		logWriter.info("Getting EchequeAttempts Data List");
		return userActionDAO.getCustomerFailureReport(fromDate,toDate,mobileNumber);
	}//
	public List<Attempts> getEchequeAttempts(Date fromDate,Date toDate,String status) {
		logWriter.info("Getting EchequeAttempts Data List");
		return userActionDAO.getEchequeAttempts(fromDate,toDate,status);
	}
	public List<Attempts> getPendingEchequeAttempts(Date fromDate,Date toDate,String status) {
		logWriter.info("Getting EchequeAttempts Data List");
		return userActionDAO.getPendingEchequeAttempts(fromDate,toDate,status);
	}
	public List<Attempts> getPendingEchequeAttemptswithMobile(Date fromDate,Date toDate,String mobileNo) {
		logWriter.info("Getting EchequeAttempts Data List");
		return userActionDAO.getPendingEchequeAttemptswithMobile(fromDate,toDate,mobileNo);
	}
	
	/**
	 * Method to generate Echeque deposit report to CI
	 * @param request
	 * @return json Object -Mails, Message, Status
	 * @throws Exception
	 */
	public void getEchequeDepositRequestPacket(HttpServletRequest request,HttpServletResponse response, List<EchequeDepositBean> echequelist) throws Exception{
		logWriter.info("in getEchequeDeposit ---------" );
		//List<EchequeDepositBean> echequelist= UserActionDAO.generateRequestPacket(fromDate,toDate);
		UUID uuid=UUID.randomUUID();
		session = request.getSession();
		int count=1;
		try{
			if(session.getAttribute("userid") != null){
			if(echequelist!=null && echequelist.size()>0)
				{
			  final String NS_PREFIX = "xs:";
					String rootPath1 = request.getServletContext().getRealPath("/");
					logWriter.info("rootPath1"+rootPath1);
					int chequeId=1;
					File rootDir=new File(rootPath1+File.separator+"generated_Files"+File.separator+uuid);
					logWriter.info("rootDir "+ rootDir);
					Boolean flag=rootDir.mkdir();
					logWriter.info("flag is"+flag);
					if (rootDir.exists()) {
						logWriter.info("Directory is created!");
						/*Element root = doc.createElement("root");
						root.setAttributeNS("http://www.w3.org/2001/XMLSchema-instance",
						    "xsi:noNamespaceSchemaLocation", "my.xsd");
						root.appendChild(doc.createElement("foo"));
						doc.appendChild(root);
						// see result
						DOMImplementationLS dls = (DOMImplementationLS) doc.getImplementation();
						System.out.println(dls.createLSSerializer().writeToString(doc));*/
						DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
						DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
						Document doc = docBuilder.newDocument();
						/*docFactory.setValidating(true);
						docFactory.setNamespaceAware(true);
						docFactory.setAttribute("http://java.sun.com/xml/jaxp/properties/schemaLanguage", 
					              "http://www.w3.org/2001/XMLSchema");*/
						doc.setXmlVersion("1.0");
						doc.setXmlStandalone(true);
						//IACheck.ExternalImport xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="IACheck.ExternalImport.xsd">
						Element cancelacion = doc.createElement("IACheck.ExternalImport");
						cancelacion.setAttributeNS("http://www.w3.org/2001/XMLSchema-instance",
							    "xsi:noNamespaceSchemaLocation", "IACheck.ExternalImport.xsd");
						/*cancelacion.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
						cancelacion.setAttribute("xsi:noNamespaceSchemaLocation", "IACheck.ExternalImport.xsd");*/
						doc.appendChild(cancelacion);
						String rootPath = request.getServletContext().getRealPath("/");
						logWriter.info("rootPath"+rootPath);
						Element importElement = doc.createElement("Import");
						cancelacion.appendChild(importElement);
						Element bundlesElement = doc.createElement("ForwardPresentmentBundles");
						importElement.appendChild(bundlesElement);
						Element bundleElement = doc.createElement("ForwardPresentmentBundle");
						bundlesElement.appendChild(bundleElement);
						Element headerElement= doc.createElement("BundleHeader");
						bundleElement.appendChild(headerElement);
						Element browser = doc.createElement("CollectionTypeIndicator");
						browser.appendChild(doc.createTextNode("01"));
						headerElement.appendChild(browser);
						//for (EchequeDepositBean ebean : echequelist) {
						/*Element browser1 = doc.createElement("DestinationRoutingNumber");
						//browser1.appendChild(doc.createTextNode(ebean.getTransitNo()+"-"+ebean.getInstitutionId()));
						headerElement.appendChild(browser1);*/
						/*Element browser2 = doc.createElement("ECEInstitutionRoutingNumber");
						//browser2.appendChild(doc.createTextNode(ebean.getTransitNo()+"-"+ebean.getInstitutionId()));//need to update
						headerElement.appendChild(browser2);*/
						
						Element browser3 = doc.createElement("BundleBusinessDate");
						String currentDate=CommonUtil.getDateTime(new java.util.Date().getTime(), "YYYYMMdd","EST");
						logWriter.info("currentDate1 : "+currentDate);
						/*java.util.Date date = new java.util.Date();
						String currentDate= new SimpleDateFormat("yyyyMMdd").format(date);*/
						browser3.appendChild(doc.createTextNode(currentDate));//need to update
						//browser3.appendChild(doc.createTextNode("Aditya/shakti to respond"));//need to update
						headerElement.appendChild(browser3);
						Element creationDate = doc.createElement("BundleCreationDate");
						creationDate.appendChild(doc.createTextNode(currentDate));
						headerElement.appendChild(creationDate);
						//Element browser4 = doc.createElement("BundleID");
						String currentDate2=CommonUtil.getDateTime(new java.util.Date().getTime(), "YYYYMMdd HH:mm","EST");
						logWriter.info("currentDate1 : "+currentDate2);
						//browser4.appendChild(doc.createTextNode(currentDate2+".1"));//need to update
						//headerElement.appendChild(browser4);
						Element browser5 = doc.createElement("BundleSequenceNumber");
						browser5.appendChild(doc.createTextNode(String.valueOf(count)));//need to update
						headerElement.appendChild(browser5);
						Element browser6 = doc.createElement("UID");
						browser6.appendChild(doc.createTextNode(uuid.toString()));
						headerElement.appendChild(browser6);
						Element itemCount = doc.createElement("ItemCount");
						itemCount.appendChild(doc.createTextNode(""+echequelist.size()));//need to update
						headerElement.appendChild(itemCount);
						Element imageCount = doc.createElement("ImageCount");
						imageCount.appendChild(doc.createTextNode(""+(2*echequelist.size())));//need to update
						headerElement.appendChild(imageCount);
						
						/*Element totalItemAmount = doc.createElement("TotalItemAmount");
						totalItemAmount.appendChild(doc.createTextNode(""));//need to update
						
						headerElement.appendChild(totalItemAmount);*/

						Element headerMiscElement = doc.createElement("BundleHeaderMiscellaneousA");
						bundleElement.appendChild(headerMiscElement);
						Element bundle1 = doc.createElement("ClearingDate");
						// java.sql.Date date= new java.sql.Date();
						bundle1.appendChild(doc.createTextNode(currentDate));
						headerMiscElement.appendChild(bundle1);
						Element bundle2 = doc.createElement("BatchReference");
						//bundle2.appendChild(doc.createTextNode(currentDate+".01"+"."+String.valueOf(count)));
						bundle2.appendChild(doc.createTextNode(currentDate2+".01"));//need to check
						headerMiscElement.appendChild(bundle2);
						Element bundle3 = doc.createElement("BatchProfileName");
						bundle3.appendChild(doc.createTextNode(echequelist.get(0).getClearingZone()));
						//bundle3.appendChild(doc.createTextNode("Aditya/shakti to respond"));//need to check
						headerMiscElement.appendChild(bundle3);
						Element bundle4 = doc.createElement("Operator");
						bundle4.appendChild(doc.createTextNode((String) session.getAttribute("userid")));//need to check
						headerMiscElement.appendChild(bundle4);
						Element bundle5 = doc.createElement("Location");
						bundle5.appendChild(doc.createTextNode((String) session.getAttribute("physicalDeliveryOfficeName")));//need to check
						headerMiscElement.appendChild(bundle5);
						int chequeAmount=0;
						for (EchequeDepositBean ebean : echequelist) {
							//browser1.appendChild(doc.createTextNode(ebean.getTransitNo()+"-"+ebean.getInstitutionId()));
							//headerElement.appendChild(browser1);
							Element checkElement = doc.createElement("CheckDetailItem");
							bundleElement.appendChild(checkElement);
							Element checkDetail = doc.createElement("CheckDetail");
							checkElement.appendChild(checkDetail);
							Element auxElement = doc.createElement("AuxiliaryOnUs");
							logWriter.info("ebean.getChequeNumber()"+ebean.getChequeNumber());
							auxElement.appendChild(doc.createTextNode(ebean.getChequeNumber()));
							checkDetail.appendChild(auxElement);
							Element routingNo = doc.createElement("PayorBankRoutingNumber");
						    logWriter.info("ebean.getTransitNo+ebean.getInstitutionId()"+ebean.getTransitNo()+"-"+ebean.getInstitutionId());		
							routingNo.appendChild(doc.createTextNode(ebean.getTransitNo()+"-"+ebean.getInstitutionId()));
							checkDetail.appendChild(routingNo);
							Element OnUs = doc.createElement("OnUs");
							logWriter.info("ebean.getIssuerAccNo()"+ebean.getIssuerAccNo());
							OnUs.appendChild(doc.createTextNode(ebean.getIssuerAccNo()));
							checkDetail.appendChild(OnUs);
							Element amount = doc.createElement("Amount");
							logWriter.info("ebean.getChequeAmount()"+ebean.getChequeAmount());
							chequeAmount  =chequeAmount+Integer.parseInt(ebean.getChequeAmount().toString());
							DecimalFormat df = new DecimalFormat("0.00");
						    String angleFormated = df.format(ebean.getChequeAmount());
						    System.out.println(angleFormated);
							//String amt=CommonUtil.getImageSize(ebean.getChequeAmount().toString(),10);
							amount.appendChild(doc.createTextNode(angleFormated));
							checkDetail.appendChild(amount);
							Element seqNo = doc.createElement("ECEInstitutionItemSequenceNumber");
							//java.util.Date date1 = new java.util.Date();
							String currentDate1=CommonUtil.getDateTime(new java.util.Date().getTime(), "ddMMyy","EST");
							//String currentDate1= new SimpleDateFormat("ddMMyy").format(date1);
							String size=CommonUtil.getImageSize(String.valueOf(count),4);
							String size1=CommonUtil.getImageSize(String.valueOf(chequeId),5);
							seqNo.appendChild(doc.createTextNode(currentDate1+size+size1));//need to update
							checkDetail.appendChild(seqNo);
							Element bofInd = doc.createElement("BOFDIndicator");
							bofInd.appendChild(doc.createTextNode("1"));//need to check
							checkDetail.appendChild(bofInd);
							Element uid = doc.createElement("UID");
							UUID uuid1=UUID.randomUUID();
							uid.appendChild(doc.createTextNode(uuid1.toString()));
							checkDetail.appendChild(uid);

							Element checkMisc = doc.createElement("CheckDetailMiscellaneousA");
							checkElement.appendChild(checkMisc);
							Element benAcc = doc.createElement("BeneficiaryAccount");
							logWriter.info("ebean.getBeneficiaryAccount()"+ebean.getBeneficiaryAccount());
							benAcc.appendChild(doc.createTextNode(ebean.getBeneficiaryAccount()));
							checkMisc.appendChild(benAcc);
							Element chequeDate = doc.createElement("ChequeDate");
							logWriter.info("ebean.getChequeDate()"+ebean.getChequeDate());
							String echequeDate = new SimpleDateFormat("yyyyMMdd").format(ebean.getChequeDate());
							chequeDate.appendChild(doc.createTextNode(echequeDate));
							checkMisc.appendChild(chequeDate);
							Element reportCode = doc.createElement("ReportCode");
							//reportCode.appendChild(doc.createTextNode("Aditya/shakti to respond"));//need to update
							checkMisc.appendChild(reportCode);

							Element imagesElement = doc.createElement("Images");
							checkElement.appendChild(imagesElement);
							Element imageElement = doc.createElement("Image");
							imagesElement.appendChild(imageElement);
							Element imageView= doc.createElement("ImageViewDetail");
							imageElement.appendChild(imageView);
							Element imageInd = doc.createElement("ImageIndicator");
							imageInd.appendChild(doc.createTextNode("1"));
							imageView.appendChild(imageInd);
							Element imgRoutngNo = doc.createElement("ImageCreatorRoutingNumber");
							imgRoutngNo.appendChild(doc.createTextNode(ebean.getTransitNo()+"-"+ebean.getInstitutionId()));
							imageView.appendChild(imgRoutngNo);
							Element imageCreatorDate = doc.createElement("ImageCreatorDate");
							//String creatorDate = new SimpleDateFormat("yyyyMMdd").format(ebean.getSubmittedDate());
							imageCreatorDate.appendChild(doc.createTextNode(currentDate));
							imageView.appendChild(imageCreatorDate);
							Element imageViewFormatIndicator = doc.createElement("ImageViewFormatIndicator");
							imageViewFormatIndicator.appendChild(doc.createTextNode("00"));
							imageView.appendChild(imageViewFormatIndicator);
							Element imageViewId = doc.createElement("ImageViewCompressionAlgorithmIdentifier");
							imageViewId.appendChild(doc.createTextNode("00"));
							imageView.appendChild(imageViewId);
							Element viewSideIndicator = doc.createElement("ViewSideIndicator");
							viewSideIndicator.appendChild(doc.createTextNode("0"));
							imageView.appendChild(viewSideIndicator);
							Element viewDescriptor = doc.createElement("ViewDescriptor");
							viewDescriptor.appendChild(doc.createTextNode("00"));
							imageView.appendChild(viewDescriptor);

							Element imageViewData= doc.createElement("ImageViewData");
							imageElement.appendChild(imageViewData);
							Element itemReferenceKey= doc.createElement("ItemReferenceKey");
							imageViewData.appendChild(itemReferenceKey);
							Element itemReference = doc.createElement("itemReference");
							logWriter.info("ebean.getMemo()"+ebean.getMemo());
							itemReference.appendChild(doc.createTextNode(ebean.getMemo()));//need to check
							itemReferenceKey.appendChild(itemReference);
							Element eceInstRoutngNo = doc.createElement("ECEInstitutionRoutingNumber");
							eceInstRoutngNo.appendChild(doc.createTextNode(ebean.getTransitNo()+"-"+ebean.getInstitutionId()));//need to check
							itemReferenceKey.appendChild(eceInstRoutngNo);
							Element bundleBusinessDate = doc.createElement("BundleBusinessDate");
							bundleBusinessDate.appendChild(doc.createTextNode(currentDate));
							itemReferenceKey.appendChild(bundleBusinessDate);
							Element eceInstSeqNo = doc.createElement("ECEInstitutionItemSequenceNumber");
							eceInstSeqNo.appendChild(doc.createTextNode(currentDate1+size+size1));//need to update
							itemReferenceKey.appendChild(eceInstSeqNo);

							Element binaryDataInfo= doc.createElement("BinaryDataInfo");
							imageViewData.appendChild(binaryDataInfo);
							Element lengthOfImageData = doc.createElement("LengthOfImageData");
							logWriter.info("ebean.getFrontImageSize()"+ebean.getFrontImageSize());
							String imageSize=CommonUtil.getImageSize(ebean.getFrontImageSize(),7);
							lengthOfImageData.appendChild(doc.createTextNode(imageSize));
							binaryDataInfo.appendChild(lengthOfImageData);
							Element imageFileName = doc.createElement("ImageFileName");
							Path p1 = Paths.get(ebean.getFrontImagePath());
							String file1 = p1.getFileName().toString();
							imageFileName.appendChild(doc.createTextNode(file1));
							binaryDataInfo.appendChild(imageFileName);

							Element imageElement2 = doc.createElement("Image");
							imagesElement.appendChild(imageElement2);
							Element imageView2= doc.createElement("ImageViewDetail");
							imageElement2.appendChild(imageView2);
							Element imageInd2 = doc.createElement("ImageIndicator");
							imageInd2.appendChild(doc.createTextNode("1"));
							imageView2.appendChild(imageInd2);
							Element imgRoutngNo2 = doc.createElement("ImageCreatorRoutingNumber");
							imgRoutngNo2.appendChild(doc.createTextNode(ebean.getTransitNo()+"-"+ebean.getInstitutionId()));
							imageView2.appendChild(imgRoutngNo2);
							Element imageCreatorDate2 = doc.createElement("ImageCreatorDate");
							//String creatorDate = new SimpleDateFormat("MM/dd/yyyy").format(ebean.getSubmittedDate());
							imageCreatorDate2.appendChild(doc.createTextNode(currentDate));
							imageView2.appendChild(imageCreatorDate2);
							Element imageViewFormatIndicator2 = doc.createElement("ImageViewFormatIndicator");
							imageViewFormatIndicator2.appendChild(doc.createTextNode("00"));
							imageView2.appendChild(imageViewFormatIndicator2);
							Element imageViewId2 = doc.createElement("ImageViewCompressionAlgorithmIdentifier");
							imageViewId2.appendChild(doc.createTextNode("00"));
							imageView2.appendChild(imageViewId2);
							Element viewSideIndicator2 = doc.createElement("ViewSideIndicator");
							viewSideIndicator2.appendChild(doc.createTextNode("1"));
							imageView2.appendChild(viewSideIndicator2);
							Element viewDescriptor2 = doc.createElement("ViewDescriptor");
							viewDescriptor2.appendChild(doc.createTextNode("00"));
							imageView2.appendChild(viewDescriptor2);

							Element imageViewData2= doc.createElement("ImageViewData");
							imageElement2.appendChild(imageViewData2);
							Element itemReferenceKey2= doc.createElement("ItemReferenceKey");
							imageViewData2.appendChild(itemReferenceKey2);
							Element itemReference1 = doc.createElement("itemReference");
							itemReference1.appendChild(doc.createTextNode(ebean.getMemo()));//need to check
							itemReferenceKey2.appendChild(itemReference1);
							Element eceInstRoutngNo2 = doc.createElement("ECEInstitutionRoutingNumber");
							eceInstRoutngNo2.appendChild(doc.createTextNode(ebean.getTransitNo()+"-"+ebean.getInstitutionId()));//need to update
							itemReferenceKey2.appendChild(eceInstRoutngNo2);
							Element bundleBusinessDate2 = doc.createElement("BundleBusinessDate");
							bundleBusinessDate2.appendChild(doc.createTextNode(currentDate));
							itemReferenceKey2.appendChild(bundleBusinessDate2);
							Element eceInstSeqNo2 = doc.createElement("ECEInstitutionItemSequenceNumber");
							eceInstSeqNo2.appendChild(doc.createTextNode(currentDate1+size+size1));//need to update
							itemReferenceKey2.appendChild(eceInstSeqNo2);

							Element binaryDataInfo2= doc.createElement("BinaryDataInfo");
							imageViewData2.appendChild(binaryDataInfo2);
							Element lengthOfImageData2 = doc.createElement("LengthOfImageData");
							String imageSize1=CommonUtil.getImageSize(ebean.getBackImageSize(),7);
							lengthOfImageData2.appendChild(doc.createTextNode(imageSize1));
							binaryDataInfo2.appendChild(lengthOfImageData2);
							Element imageFileName2 = doc.createElement("ImageFileName");
							Path p = Paths.get(ebean.getBackImagePath());
							String file2 = p.getFileName().toString();
							imageFileName2.appendChild(doc.createTextNode(file2));
							binaryDataInfo2.appendChild(imageFileName2);
							/*TransformerFactory transformerFactory = TransformerFactory.newInstance();
							Transformer transformer = transformerFactory.newTransformer();
							DOMSource source = new DOMSource(doc);
							logWriter.info("uuid is: "+uuid);
							StreamResult result = new StreamResult(rootDir+File.separator+uuid+".xml");
							transformer.transform(source, result);
							logWriter.info("File saved!");*/
							chequeId++;
							File frontSourceFile = new File(ebean.getFrontImagePath());
							logWriter.info("frontSourceFile path is :"+frontSourceFile);
							File backSourceFile = new File(ebean.getBackImagePath());
							logWriter.info("backSourceFile path is :"+backSourceFile);
							try{
								FileUtils.copyFileToDirectory(frontSourceFile, rootDir);
								logWriter.info("front file copied");
								FileUtils.copyFileToDirectory(backSourceFile, rootDir);
								logWriter.info("back file copied");
								String status="Processed";
								ebean.setStatus(status);
								int echequeStatus=updateEchequeDetails(ebean);
								logWriter.info("echequeStatus has been updated for :"+echequeStatus);
							}catch(FileNotFoundException e){
								logWriter.error("FileNotFoundException"+e);
							}catch(Exception e){
								logWriter.error("Exception in copy :"+e);
							}
							logWriter.error("Status as Processed :");
							
						}
						logWriter.info("chequeAmount total : "+chequeAmount);
						Element totalItemAmount = doc.createElement("TotalItemAmount");
						totalItemAmount.appendChild(doc.createTextNode(chequeAmount+""));//need to update
						headerElement.appendChild(totalItemAmount);
						
						TransformerFactory transformerFactory = TransformerFactory.newInstance();
						Transformer transformer = transformerFactory.newTransformer();
						DOMSource source = new DOMSource(doc);
						logWriter.info("uuid is: "+uuid);
						StreamResult result = new StreamResult(rootDir+File.separator+uuid+".xml");
						transformer.transform(source, result);
						logWriter.info("File saved!");
						File xsdFile=new File(rootPath+File.separator+"files"+File.separator+"IACheck.ExternalImport.xsd");
						logWriter.info("xsdFile"+xsdFile);
						FileUtils.copyFileToDirectory(xsdFile, rootDir);
						request.setAttribute("uuid", uuid);
						logWriter.info("Report generated successfully at location "+rootDir);
						String path = request.getServletContext().getRealPath(File.separator+"generated_Files"+File.separator+uuid);
						logWriter.info("zip a file path :  "+rootDir);
						File directory = new File(path);
						String[] files1= directory.list();
						if (files1 != null && files1.length > 0) {
							byte[] zip = zipFiles(directory, files1);
							logWriter.info("files after Zip "+zip);
							ServletOutputStream sos = response.getOutputStream();
							response.setContentType("application/zip");
							response.addHeader("Content-Disposition","attachment;filename=\"" + uuid +".zip");  
							sos.write(zip);
						}
						//return true;
					}
					else{
						logWriter.info("directory doesnot exists");
						session.setAttribute("error_msg","directory doesnot exists");
						response.sendRedirect("authorFailure.jsp");
						//return false;
					}
				}
				else{
					logWriter.info("list is empty");
					session.setAttribute("error_msg","list is empty");
					response.sendRedirect("authorFailure.jsp");
					//return false;
				}
			}
			else{
				logWriter.info("Session Expired...");
				session.setAttribute("error_msg","Session Expired... Please Login Again");
				response.sendRedirect("Error.jsp");
			}
		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
			session.setAttribute("error_msg","ParserConfigurationException");
			response.sendRedirect("Error.jsp");
			logWriter.error("ParserConfigurationException :"+pce);
			//return false;
			//return new ModelAndView("error", responseData);
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
			session.setAttribute("error_msg","TransformerException");
			response.sendRedirect("Error.jsp");
			logWriter.error("TransformerException :"+tfe);
			//return false;
			// return new ModelAndView("error", responseData);
		}
		catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("error_msg","Exception while creating Report");
			response.sendRedirect("authorFailure.jsp");
			logWriter.error("Exception is :"+e);
        }
	}
	
	/// --------------------------------------------------------------------
	public void getEchequeDepositRequestPacketFull(HttpServletRequest request,HttpServletResponse response, List<List<EchequeDepositBean>> echequeFullList) throws Exception{
		logWriter.info("in getEchequeDepositRequestPacketFull ---------########################################" );
		//List<EchequeDepositBean> echequelist= UserActionDAO.generateRequestPacket(fromDate,toDate);
		UUID uuid=UUID.randomUUID();
		session = request.getSession();
		int count=1;
		try{
			if(session.getAttribute("userid") != null){
			if(echequeFullList!=null && echequeFullList.size()>0)
				{
					String rootPath1 = request.getServletContext().getRealPath("/");
					logWriter.info("rootPath1"+rootPath1);
					int chequeId=1;
					File rootDir=new File(rootPath1+File.separator+"generated_Files"+File.separator+uuid);
					logWriter.info("rootDir "+ rootDir);
					Boolean flag=rootDir.mkdir();
					logWriter.info("flag is"+flag);
					if (rootDir.exists()) {
						logWriter.info("Directory is created!");
						DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
						DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
						String rootPath = request.getServletContext().getRealPath("/");
						logWriter.info("rootPath"+rootPath);
						/*Document document = docBuilder.parse(new InputSource(new FileReader(
								rootPath+File.separator+"files"+File.separator+"IACheck.ExternalImport.xsd")));
						docFactory.setNamespaceAware(true); 
						docFactory.setAttribute("http://java.sun.com/xml/jaxp/properties/schemaLanguage","http://www.w3.org/2001/XMLSchema"); */
						Document doc = docBuilder.newDocument();
						Element importElement = doc.createElement("Import");
						doc.appendChild(importElement);
						Element bundlesElement = doc.createElement("ForwardPresentmentBundles");
						importElement.appendChild(bundlesElement);
						logWriter.info("echequeFullList size :: "+echequeFullList.size());
						for(int i=0;i<echequeFullList.size();i++)
						{
							List<EchequeDepositBean> echequelist=echequeFullList.get(i);
							
							Element bundleElement = doc.createElement("ForwardPresentmentBundle");
							bundlesElement.appendChild(bundleElement);
							Element headerElement= doc.createElement("BundleHeader");
							bundleElement.appendChild(headerElement);
							Element browser = doc.createElement("CollectionTypeIndicator");
							browser.appendChild(doc.createTextNode("01"));
							headerElement.appendChild(browser);
							for (EchequeDepositBean ebean : echequelist) {
								Element browser1 = doc.createElement("DestinationRoutingNumber");
								//browser1.appendChild(doc.createTextNode(destroutingno));
								browser1.appendChild(doc.createTextNode(ebean.getTransitNo()+"-"+ebean.getInstitutionId()));
								//browser1.appendChild(doc.createTextNode("DestinationRoutingNumber"));//need to update
								headerElement.appendChild(browser1);
								}
							
							//Element browser1 = doc.createElement("DestinationRoutingNumber");
							//browser1.appendChild(doc.createTextNode(ebean.getTransitNo()+"-"+ebean.getInstitutionId()));
							//browser1.appendChild(doc.createTextNode("DestinationRoutingNumber"));//need to update
						
							Element browser2 = doc.createElement("ECEInstitutionRoutingNumber");
							//browser2.appendChild(doc.createTextNode("Aditya/shakti to respond"));//need to update
							headerElement.appendChild(browser2);
							Element browser3 = doc.createElement("BundleBusinessDate");
							/*java.util.Date date = new java.util.Date();
							String currentDate= new SimpleDateFormat("yyyyMMdd").format(date);*/
							String currentDate=CommonUtil.getDateTime(new java.util.Date().getTime(), "YYYYMMdd HH:mm","EST");
							logWriter.info("currentDate1 : "+currentDate);
							logWriter.info("currentDate2 : "+CommonUtil.getDateTime(CommonUtil.getTimeZoneDateTime(), "YYYYMMdd HH:mm"));
							//browser3.appendChild(doc.createTextNode(currentDate));//need to update
							headerElement.appendChild(browser3);
							Element creationDate = doc.createElement("BundleCreationDate");
							creationDate.appendChild(doc.createTextNode(currentDate));
							headerElement.appendChild(creationDate);
							Element browser4 = doc.createElement("BundleID");
							browser4.appendChild(doc.createTextNode(currentDate+".1"));//need to update
							headerElement.appendChild(browser4);
							Element browser5 = doc.createElement("BundleSequenceNumber");
							browser5.appendChild(doc.createTextNode(String.valueOf(count)));//need to update
							headerElement.appendChild(browser5);
							Element browser6 = doc.createElement("UID");
							browser6.appendChild(doc.createTextNode(uuid.toString()));
							headerElement.appendChild(browser6);

							Element headerMiscElement = doc.createElement("BundleHeaderMiscellaneousA");
							bundleElement.appendChild(headerMiscElement);
							Element bundle1 = doc.createElement("ClearingDate");
							// java.sql.Date date= new java.sql.Date();
							bundle1.appendChild(doc.createTextNode(currentDate));
							headerMiscElement.appendChild(bundle1);
							Element bundle2 = doc.createElement("BatchReference");
							bundle2.appendChild(doc.createTextNode(currentDate+".01"+"."+String.valueOf(count)));//need to check
							headerMiscElement.appendChild(bundle2);
							Element bundle3 = doc.createElement("BatchProfileName");
							bundle3.appendChild(doc.createTextNode(echequelist.get(0).getClearingZone()));//need to check
							headerMiscElement.appendChild(bundle3);
							Element bundle4 = doc.createElement("Operator");
							bundle4.appendChild(doc.createTextNode((String) session.getAttribute("userid")));//need to check
							headerMiscElement.appendChild(bundle4);
							Element bundle5 = doc.createElement("Location");
							bundle5.appendChild(doc.createTextNode((String) session.getAttribute("physicalDeliveryOfficeName")));//need to check
							headerMiscElement.appendChild(bundle5);
							for (EchequeDepositBean ebean : echequelist)
							{
								//browser1.appendChild(doc.createTextNode(ebean.getTransitNo()+ "-"+ ebean.getInstitutionId()));
								//headerElement.appendChild(browser1);
								Element checkElement = doc.createElement("CheckDetailItem");
								bundleElement.appendChild(checkElement);
								Element checkDetail = doc.createElement("CheckDetail");
								checkElement.appendChild(checkDetail);
								Element auxElement = doc.createElement("AuxiliaryOnUs");
								auxElement.appendChild(doc.createTextNode(ebean.getChequeNumber()));
								checkDetail.appendChild(auxElement);
								Element routingNo = doc.createElement("PayorBankRoutingNumber");
								routingNo.appendChild(doc.createTextNode(ebean.getTransitNo()+ "-"+ ebean.getInstitutionId()));
								checkDetail.appendChild(routingNo);
								Element OnUs = doc.createElement("OnUs");
								OnUs.appendChild(doc.createTextNode(ebean.getIssuerAccNo()));
								checkDetail.appendChild(OnUs);
								Element amount = doc.createElement("Amount");
								String amt=CommonUtil.getImageSize(ebean.getChequeAmount().toString(),10);
								amount.appendChild(doc.createTextNode(amt));
								checkDetail.appendChild(amount);
								Element seqNo = doc.createElement("ECEInstitutionItemSequenceNumber");
								java.util.Date date1 = new java.util.Date();
								String currentDate1 = new SimpleDateFormat("ddMMyy").format(date1);
								String size = CommonUtil.getImageSize(String.valueOf(count), 4);
								String size1 = CommonUtil.getImageSize(String.valueOf(chequeId), 5);
								seqNo.appendChild(doc.createTextNode(currentDate1 + size+ size1));// need to update
								checkDetail.appendChild(seqNo);
								Element bofInd = doc.createElement("BOFDIndicator");
								// bofInd.appendChild(doc.createTextNode("Aditya/shakti to respond"));//need to check
								checkDetail.appendChild(bofInd);
								Element uid = doc.createElement("UID");
								UUID uuid1 = UUID.randomUUID();
								uid.appendChild(doc.createTextNode(uuid1.toString()));
								checkDetail.appendChild(uid);

								Element checkMisc = doc.createElement("CheckDetailMiscellaneousA");
								checkElement.appendChild(checkMisc);
								Element benAcc = doc.createElement("BeneficiaryAccount");
								benAcc.appendChild(doc.createTextNode(ebean.getBeneficiaryAccount()));
								checkMisc.appendChild(benAcc);
								Element chequeDate = doc.createElement("ChequeDate");
								String echequeDate = new SimpleDateFormat("yyyyMMdd").format(ebean.getChequeDate());
								chequeDate.appendChild(doc.createTextNode(echequeDate));
								checkMisc.appendChild(chequeDate);
								Element reportCode = doc.createElement("ReportCode");
								// reportCode.appendChild(doc.createTextNode("Aditya/shakti to respond"));//need to update
								checkMisc.appendChild(reportCode);

								Element imagesElement = doc.createElement("Images");
								checkElement.appendChild(imagesElement);
								Element imageElement = doc.createElement("Image");
								imagesElement.appendChild(imageElement);
								Element imageView = doc.createElement("ImageViewDetail");
								imageElement.appendChild(imageView);
								Element imageInd = doc.createElement("ImageIndicator");
								// imageInd.appendChild(doc.createTextNode("01"));
								imageView.appendChild(imageInd);
								Element imgRoutngNo = doc.createElement("ImageCreatorRoutingNumber");
								imgRoutngNo.appendChild(doc.createTextNode(ebean.getTransitNo()	+ "-"+ ebean.getInstitutionId()));
								imageView.appendChild(imgRoutngNo);
								Element imageCreatorDate = doc.createElement("ImageCreatorDate");
								//String creatorDate = new SimpleDateFormat("yyyyMMdd").format(ebean.getSubmittedDate());
								// imageCreatorDate.appendChild(doc.createTextNode(creatorDate));
								imageView.appendChild(imageCreatorDate);
								Element imageViewFormatIndicator = doc.createElement("ImageViewFormatIndicator");
								imageViewFormatIndicator.appendChild(doc.createTextNode("00"));
								imageView.appendChild(imageViewFormatIndicator);
								Element imageViewId = doc.createElement("ImageViewCompressionAlgorithmIdentifier");
								imageViewId.appendChild(doc.createTextNode("00"));
								imageView.appendChild(imageViewId);
								Element viewSideIndicator = doc.createElement("ViewSideIndicator");
								viewSideIndicator.appendChild(doc.createTextNode("0"));
								imageView.appendChild(viewSideIndicator);
								Element viewDescriptor = doc.createElement("ViewDescriptor");
								viewDescriptor.appendChild(doc.createTextNode("00"));
								imageView.appendChild(viewDescriptor);

								Element imageViewData = doc.createElement("ImageViewData");
								imageElement.appendChild(imageViewData);
								Element itemReferenceKey = doc.createElement("ItemReferenceKey");
								imageViewData.appendChild(itemReferenceKey);
								Element itemReference = doc.createElement("itemReference");
								itemReference.appendChild(doc.createTextNode(ebean.getMemo()));//need to check
								itemReferenceKey.appendChild(itemReference);
								Element eceInstRoutngNo = doc.createElement("ECEInstitutionRoutingNumber");
								eceInstRoutngNo.appendChild(doc.createTextNode(ebean.getTransitNo()	+ "-"+ ebean.getInstitutionId()));// need to check
								itemReferenceKey.appendChild(eceInstRoutngNo);
								Element bundleBusinessDate = doc.createElement("BundleBusinessDate");
								bundleBusinessDate.appendChild(doc.createTextNode(currentDate));
								itemReferenceKey.appendChild(bundleBusinessDate);
								Element eceInstSeqNo = doc.createElement("ECEInstitutionItemSequenceNumber");
								eceInstSeqNo.appendChild(doc.createTextNode(currentDate1 + size	+ size1));// need to update
								itemReferenceKey.appendChild(eceInstSeqNo);

								Element binaryDataInfo = doc.createElement("BinaryDataInfo");
								imageViewData.appendChild(binaryDataInfo);
								Element lengthOfImageData = doc.createElement("LengthOfImageData");
								String imageSize = CommonUtil.getImageSize(	ebean.getFrontImageSize(), 7);
								lengthOfImageData.appendChild(doc.createTextNode(imageSize));
								binaryDataInfo.appendChild(lengthOfImageData);
								Element imageFileName = doc.createElement("ImageFileName");
								Path p1 = Paths.get(ebean.getFrontImagePath());
								String file1 = p1.getFileName().toString();
								imageFileName.appendChild(doc.createTextNode(file1));
								binaryDataInfo.appendChild(imageFileName);

								Element imageElement2 = doc.createElement("Image");
								imagesElement.appendChild(imageElement2);
								Element imageView2 = doc.createElement("ImageViewDetail");
								imageElement2.appendChild(imageView2);
								Element imageInd2 = doc.createElement("ImageIndicator");
								// imageInd2.appendChild(doc.createTextNode("01"));
								imageView2.appendChild(imageInd2);
								Element imgRoutngNo2 = doc.createElement("ImageCreatorRoutingNumber");
								imgRoutngNo2.appendChild(doc.createTextNode(ebean.getTransitNo()+ "-"+ ebean.getInstitutionId()));
								imageView2.appendChild(imgRoutngNo2);
								Element imageCreatorDate2 = doc.createElement("ImageCreatorDate");
								// String creatorDate = new
								// SimpleDateFormat("MM/dd/yyyy").format(ebean.getSubmittedDate());
								// imageCreatorDate2.appendChild(doc.createTextNode(creatorDate));
								imageView2.appendChild(imageCreatorDate2);
								Element imageViewFormatIndicator2 = doc.createElement("ImageViewFormatIndicator");
								imageViewFormatIndicator2.appendChild(doc.createTextNode("00"));
								imageView2.appendChild(imageViewFormatIndicator2);
								Element imageViewId2 = doc.createElement("ImageViewCompressionAlgorithmIdentifier");
								imageViewId2.appendChild(doc.createTextNode("00"));
								imageView2.appendChild(imageViewId2);
								Element viewSideIndicator2 = doc.createElement("ViewSideIndicator");
								viewSideIndicator2.appendChild(doc.createTextNode("1"));
								imageView2.appendChild(viewSideIndicator2);
								Element viewDescriptor2 = doc.createElement("ViewDescriptor");
								viewDescriptor2.appendChild(doc.createTextNode("00"));
								imageView2.appendChild(viewDescriptor2);

								Element imageViewData2 = doc.createElement("ImageViewData");
								imageElement2.appendChild(imageViewData2);
								Element itemReferenceKey2 = doc.createElement("ItemReferenceKey");
								imageViewData2.appendChild(itemReferenceKey2);
								Element itemReference1 = doc.createElement("itemReference");
								itemReference1.appendChild(doc.createTextNode(ebean.getMemo()));//need to check
								itemReferenceKey2.appendChild(itemReference1);
								Element eceInstRoutngNo2 = doc.createElement("ECEInstitutionRoutingNumber");
								eceInstRoutngNo2.appendChild(doc.createTextNode(ebean.getTransitNo()+ "-"+ ebean.getInstitutionId()));// need to update
								itemReferenceKey2.appendChild(eceInstRoutngNo2);
								Element bundleBusinessDate2 = doc.createElement("BundleBusinessDate");
								bundleBusinessDate2.appendChild(doc.createTextNode(currentDate));
								itemReferenceKey2.appendChild(bundleBusinessDate2);
								Element eceInstSeqNo2 = doc.createElement("ECEInstitutionItemSequenceNumber");
								eceInstSeqNo2.appendChild(doc.createTextNode(currentDate1 + size+ size1));// need to update
								itemReferenceKey2.appendChild(eceInstSeqNo2);

								Element binaryDataInfo2 = doc.createElement("BinaryDataInfo");
								imageViewData2.appendChild(binaryDataInfo2);
								Element lengthOfImageData2 = doc.createElement("LengthOfImageData");
								String imageSize1 = CommonUtil.getImageSize(ebean.getBackImageSize(), 7);
								lengthOfImageData2.appendChild(doc.createTextNode(imageSize1));
								binaryDataInfo2.appendChild(lengthOfImageData2);
								Element imageFileName2 = doc.createElement("ImageFileName");
								Path p = Paths.get(ebean.getBackImagePath());
								String file2 = p.getFileName().toString();
								imageFileName2.appendChild(doc.createTextNode(file2));
								binaryDataInfo2.appendChild(imageFileName2);
								TransformerFactory transformerFactory = TransformerFactory.newInstance();
								Transformer transformer = transformerFactory.newTransformer();
								DOMSource source = new DOMSource(doc);
								logWriter.info("uuid is: " + uuid);
								StreamResult result = new StreamResult(rootDir+ File.separator + uuid + ".xml");
								transformer.transform(source, result);
								logWriter.info("File saved!");
								File frontSourceFile = new File(ebean.getFrontImagePath());
								logWriter.info("frontSourceFile path is :"	+ frontSourceFile);
								File backSourceFile = new File(	ebean.getBackImagePath());
								logWriter.info("backSourceFile path is :"+ backSourceFile);
								try {
									FileUtils.copyFileToDirectory(frontSourceFile, rootDir);
									logWriter.info("front file copied");
									FileUtils.copyFileToDirectory(backSourceFile, rootDir);
									logWriter.info("back file copied");
									File xsdFile = new File(rootPath+ File.separator + "files"+ File.separator+ "IACheck.ExternalImport.xsd");
									logWriter.info("xsdFile" + xsdFile);
									FileUtils.copyFileToDirectory(xsdFile,rootDir);
									String status = "Processed";
									ebean.setStatus(status);
									int echequeStatus = updateEchequeDetails(ebean);
									logWriter.info("echequeStatus has been updated for :"+ echequeStatus);
									chequeId++;
								} catch (FileNotFoundException e) {
									logWriter.error("FileNotFoundException" + e);
								} catch (Exception e) {
									logWriter.error("Exception in copy :" + e);
								}
								logWriter.error("Status as Processed :");

							}
						request.setAttribute("uuid", uuid);
						logWriter.info("Report generated successfully at location "+rootDir);
						String path = request.getServletContext().getRealPath(File.separator+"generated_Files"+File.separator+uuid);
						logWriter.info("zip a file path :  "+rootDir);
						File directory = new File(path);
						String[] files1= directory.list();
						if (files1 != null && files1.length > 0) {
							byte[] zip = zipFiles(directory, files1);
							logWriter.info("files after Zip "+zip);
							ServletOutputStream sos = response.getOutputStream();
							response.setContentType("application/zip");
							response.addHeader("Content-Disposition","attachment;filename=\"" + uuid +".zip");  
							sos.write(zip);
						}
						//return true;
					}//end of zone logic	
					}
					else{
						logWriter.info("directory doesnot exists");
						session.setAttribute("error_msg","directory doesnot exists");
						response.sendRedirect("authorFailure.jsp");
						//return false;
					}
				}
				else{
					logWriter.info("list is empty");
					session.setAttribute("error_msg","list is empty");
					response.sendRedirect("authorFailure.jsp");
					//return false;
				}
			}
			else{
				logWriter.info("Session Expired...");
				session.setAttribute("error_msg","Session Expired... Please Login Again");
				response.sendRedirect("Error.jsp");
			}
		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
			session.setAttribute("error_msg","ParserConfigurationException");
			response.sendRedirect("authorFailure.jsp");
			logWriter.error("ParserConfigurationException :"+pce);
			//return false;
			//return new ModelAndView("error", responseData);
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
			session.setAttribute("error_msg","TransformerException");
			response.sendRedirect("authorFailure.jsp");
			logWriter.error("TransformerException :"+tfe);
			//return false;
			// return new ModelAndView("error", responseData);
		}
		catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("error_msg","Exception while creating Report");
			response.sendRedirect("authorFailure.jsp");
			logWriter.error("Exception is :"+e);
        }
	}
	
	
	
	
	// -------------------------------------------------------------------------
	
	public static byte[] zipFiles(File directory, String[] files) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(baos);
        byte bytes[] = new byte[2048];

        for (String fileName : files) {
            FileInputStream fis = new FileInputStream(directory.getPath() + 
                ZipDownloadServlet.FILE_SEPARATOR + fileName);
            BufferedInputStream bis = new BufferedInputStream(fis);

            zos.putNextEntry(new ZipEntry(fileName));

            int bytesRead;
            while ((bytesRead = bis.read(bytes)) != -1) {
                zos.write(bytes, 0, bytesRead);
            }
            zos.closeEntry();
            bis.close();
            fis.close();
        }
        zos.flush();
        baos.flush();
        zos.close();
        baos.close();

        return baos.toByteArray();
    }
}
