package com.icicibank.iMobileCA.service;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icicibank.iMobileCA.dao.MenuMasterDAO;
import com.icicibank.iMobileCA.model.MenuItem;



@Service
public class MenuMasterService {

	@Autowired
	private MenuMasterDAO menuMasterDAO;
	ServletContext servletContext;
	
	private static final Logger logWriter = Logger
			.getLogger(MenuMasterService.class.getName());
	
	private HttpSession session;
	
	public void setMenuMasterDAO(MenuMasterDAO menuMasterDAO) {
		this.menuMasterDAO = menuMasterDAO;
	}
	
	public List<MenuItem> getMenuDetails() {
		logWriter.info("In MenuMaster Service Getting Fields Data List");
		return menuMasterDAO.getMenuDetails();
	}
	
	public List<MenuItem> getMenuDetailsForAuthoring(String userId) {
		logWriter.info("In MenuMaster Service Getting Fields Data List for authoring");
		return menuMasterDAO.getMenuDetailsForAuthoring(userId);
	}
	
	public int saveMenu(MenuItem a,String param){
		logWriter.info("In MenuMaster Service adding new menu param:"+a);
		return menuMasterDAO.addMenu(a,param);
	}
	
	public int authorMenu(MenuItem a){
		logWriter.info("In MenuMaster Service authoring menu param :"+a);
		return menuMasterDAO.authorMenu(a);
	}
	
	public int rejectMenu(MenuItem a){
		logWriter.info("In MenuMaster Service rejecting menu param :"+a);
		return menuMasterDAO.rejectMenu(a);
	}
	
	public List<MenuItem> searchMenu(MenuItem a){
		logWriter.info("In MenuMaster Service searching menu param :"+a);
		return menuMasterDAO.searchMenu(a);
	}
	
	public int updateMenu(MenuItem v){
		logWriter.info("In MenuMaster Service updating menu param : "+v);
		return menuMasterDAO.updateMenu(v);
	}
	
	public int deleteMenu(MenuItem v){
		logWriter.info("In MenuMaster Service deleting menu param : "+v);
		return menuMasterDAO.deleteMenu(v);
	}

	public MenuItem viewMenu(String menuId,String status) {
		logWriter.info("In MenuMaster Service view menu param : "+menuId+" "+status);
		return menuMasterDAO.viewMenu(menuId,status);
	}
	
}
