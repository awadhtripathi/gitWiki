package com.icicibank.iMobileCA.service;

import java.text.ParseException;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icicibank.iMobileCA.dao.UserMasterDAO;
import com.icicibank.iMobileCA.model.Users;

@Service
public class UserMasterService {

	@Autowired
	private UserMasterDAO userMasterDAO;
	ServletContext servletContext;
	private static final Logger logWriter = Logger
			.getLogger(UserMasterService.class.getName());

	public UserMasterDAO getUserMasterDAO() {
		return userMasterDAO;
	}

	public void setUserMasterDAO(UserMasterDAO userMasterDAO) {
		this.userMasterDAO = userMasterDAO;
	}

	public List<Users> getUserDetails() {
		logWriter.info("Getting Fields Data List");
		return userMasterDAO.getuserDetails();
	}

	public List<Users> getUserDetailsForAuthor(String userId) {
		logWriter.info("Getting Fields Data List for Author");
		return userMasterDAO.getuserDetailsForAuthorization(userId);
	}

	public int saveUser(Users user,String a) {
		logWriter.info("In UserAction Service saveAddFields");
		return userMasterDAO.addUser(user,a);
	}

	/*public int updateUser(Users user) {
		logWriter.info("In UserAction Service updateFields");

		return userMasterDAO.updateUser(user);
	}
*/
	public int deleteUser(Users user) {

		logWriter.info("IN UserAction Service deleteFields");
		return userMasterDAO.deleteUser(user);
	}
	public List<Users> searchUser(Users user){
		logWriter.info("In userAction Service seachField");
		
		return userMasterDAO.searchUser(user);
	}
	public Users viewUser(Users user) throws ParseException{
		logWriter.info("In updateAddFields param : "+user);
		return userMasterDAO.viewUser(user);
	
	}
	public Users viewUserForMaintenance(Users user){
		logWriter.info("In updateAddFields param : "+user);
		return userMasterDAO.viewUserForMaintenance(user);
	
	}
	public int rejectUser(Users user){
		logWriter.info("In rejectUser : "+user);
		return userMasterDAO.rejectUser(user);
	}
	public int authorUser(Users user){
		logWriter.info("In authorUser : "+user);
		
		return userMasterDAO.authorUser(user);
	}
	public List<Users> getUserDetailsForMaintenance(String userId) {
		logWriter.info("Getting Fields Data List");
		return userMasterDAO.getUserDetailsForMaintenance(userId);
	}
	public int updateForMaintenance(Users user) {
		logWriter.info("In UserAction Service updateMaintenance");

		return userMasterDAO.updateForMaintenance(user);
	}
}
