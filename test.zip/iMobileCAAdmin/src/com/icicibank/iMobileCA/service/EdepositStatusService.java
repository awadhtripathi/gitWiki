package com.icicibank.iMobileCA.service;

import java.sql.Timestamp;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icicibank.iMobileCA.dao.EdepositStatusDAO;
import com.icicibank.iMobileCA.model.Attempts;

@Service
public class EdepositStatusService {

	@Autowired
	private EdepositStatusDAO edepositStatusDAO;
	ServletContext servletContext;
	private static final Logger logWriter = Logger
			.getLogger(UserActionService.class.getName());
	private HttpSession session;
	public void setEdepositStatusDAO(EdepositStatusDAO edepositStatusDAO) {
		this.edepositStatusDAO = edepositStatusDAO;
	}
	public int updateStatus(Attempts v,String refNumberList){
		logWriter.info("In updateEchequeDetails param : "+v);
		return edepositStatusDAO.updateStatus(v,refNumberList);
	}
	public int bulkStatusUpdate(Attempts v,String zoneName, Timestamp timestamp,
			Timestamp timestamp2, String referenceNumber){
		logWriter.info("In updateEchequeDetails param : "+v);
		return edepositStatusDAO.bulkStatusUpdate(v,zoneName,timestamp,timestamp2,referenceNumber);
	}
	public int bulkStatusUpdateForDateRefNo(Attempts v,Timestamp timestamp,
			Timestamp timestamp2, String referenceNumber){
		logWriter.info("In updateEchequeDetails param : "+v);
		return edepositStatusDAO.bulkStatusUpdateForDateRefNo(v,timestamp,timestamp2,referenceNumber);
	}
	public int bulkStatusUpdateForDate(Attempts v,String zoneName, Timestamp timestamp,
			Timestamp timestamp2){
		logWriter.info("In updateEchequeDetails param : "+v);
		return edepositStatusDAO.bulkStatusUpdateForDate(v,zoneName,timestamp,timestamp2);
	}
	public int bulkStatusUpdateForRefNo(Attempts v,String zoneName, String referenceNumber){
		logWriter.info("In updateEchequeDetails param : "+v);
		return edepositStatusDAO.bulkStatusUpdateForRefNo(v,zoneName,referenceNumber);
	}
	public int authorStatus(List<Attempts> list){
		logWriter.info("In updateEchequeDetails param : "+list);
		return edepositStatusDAO.authorStatus(list);
	}
	public List<Attempts> getZoneDetails(String zoneName,Timestamp startTime,Timestamp endTime,String refNumber) {
		logWriter.info("Getting Fields Data List");
		return edepositStatusDAO.getZoneDetails(zoneName,startTime,endTime,refNumber);
	}
	public List<Attempts> getZoneDetailsForAuthor(String userId) {
		logWriter.info("Getting Fields Data List");
		return edepositStatusDAO.getZoneDetailsForAuthor(userId);
	}
	public List<Attempts> getZoneDetailsForAuthoring(String zoneName,Timestamp startTime,Timestamp endTime,String refNumber,String userId) {
		logWriter.info("Getting Fields Data List");
		return edepositStatusDAO.getZoneDetailsForAuthoring(zoneName,startTime,endTime,refNumber,userId);
	}
	public List<Attempts> getDetailswithDateRefNo(Timestamp startTime,Timestamp endTime,String refNumber) {
		logWriter.info("Getting Fields Data List");
		return edepositStatusDAO.getDetailswithDateRefNo(startTime,endTime,refNumber);
	}
	public List<Attempts> getDetailswithDateRefNoForAuthor(Timestamp startTime,Timestamp endTime,String refNumber,String userId) {
		logWriter.info("Getting Fields Data List");
		return edepositStatusDAO.getDetailswithDateRefNoForAuthor(startTime,endTime,refNumber,userId);
	}
	public List<Attempts> getDetailswithDate(String zoneName,Timestamp startTime,Timestamp endTime) {
		logWriter.info("Getting Fields Data List");
		return edepositStatusDAO.getDetailswithDate(startTime,endTime,zoneName);
	}
	public List<Attempts> getDetailswithDateForAuthor(String zoneName,Timestamp startTime,Timestamp endTime,String userId) {
		logWriter.info("Getting Fields Data List");
		return edepositStatusDAO.getDetailswithDateForAuthor(startTime,endTime,zoneName,userId);
	}
	public List<Attempts> getDetailswithSubDate(Timestamp startTime,Timestamp endTime) {
		logWriter.info("Getting Fields Data List");
		return edepositStatusDAO.getDetailswithSubDate(startTime,endTime);
	}
	public List<Attempts> getDetailswithSubDateForAuthor(Timestamp startTime,Timestamp endTime,String userId) {
		logWriter.info("Getting Fields Data List");
		return edepositStatusDAO.getDetailswithSubDateForAuthor(startTime,endTime,userId);
	}
	public List<Attempts> getDetailswithRef(String zoneName,String refNo) {
		logWriter.info("Getting Fields Data List");
		return edepositStatusDAO.getDetailswithRefNo(zoneName,refNo);
	}
	public List<Attempts> getDetailswithReference(String refNo) {
		logWriter.info("Getting Fields Data List");
		return edepositStatusDAO.getDetailswithReference(refNo);
	}
	public List<Attempts> getDetailswithReferenceForAuthor(String refNo,String userId) {
		logWriter.info("Getting Fields Data List");
		return edepositStatusDAO.getDetailswithReferenceForAuthor(refNo,userId);
	}
	public List<Attempts> getDetailswithRefForAuthor(String zoneName,String refNo,String userId) {
		logWriter.info("Getting Fields Data List");
		return edepositStatusDAO.getDetailswithRefNoForAuthor(zoneName,refNo,userId);
	}
	
}
