package com.icicibank.iMobileCA.service;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icicibank.iMobileCA.dao.CityMasterDAO;
import com.icicibank.iMobileCA.model.Cities;
import com.icicibank.iMobileCA.model.Limits;

@Service
public class CityMasterService {
	@Autowired
	private CityMasterDAO cityMasterDAO;
	ServletContext servletContext;
	private static final Logger logWriter = Logger
			.getLogger(CityMasterService.class.getName());
	private HttpSession session;

	public void setCityMasterDAO(CityMasterDAO cityMasterDAO) {
		this.cityMasterDAO = cityMasterDAO;
	}

	public List<Cities> getCityDetails() {
		logWriter.info("Getting Fields Data List");
		return cityMasterDAO.getCityDetails();
	}

	public List<Cities> getCityDetailsForAuthor(String userId) {
		logWriter.info("Getting Fields Data List");
		return cityMasterDAO.getCityDetailsForAuthoring(userId);
	}

	public int saveCity(Cities a, String param) {
		logWriter.info("In UserAction Service saveAddFields");
		return cityMasterDAO.addCity(a, param);
	}

	public Cities viewCity(String cityCode, String status) {
		logWriter.info("In updateAddFields param : " + cityCode + "" + status);
		return cityMasterDAO.viewCity(cityCode, status);
	}

	public int authorCity(Cities a) {
		logWriter.info("In UserAction Service saveAddFields");
		return cityMasterDAO.authorCity(a);
	}

	public List<Cities> searchCity(Cities a) {
		logWriter.info("In UserAction Service saveAddFields");
		return cityMasterDAO.searchCity(a);
	}

	public int updateCity(Cities v) {
		logWriter.info("In updateAddFields param : " + v);
		return cityMasterDAO.updateCity(v);
	}
	public int rejectCity(Cities v) {
		logWriter.info("In updateAddFields param : " + v);
		return cityMasterDAO.rejectCity(v);
	}

	public int deleteCity(Cities v) {
		logWriter.info("In updateAddFields param : " + v);
		return cityMasterDAO.deleteCity(v);
	}

	public List<Cities> getCitiesWithProvince(String provinceCode) {
		logWriter.info("In UserAction Service saveAddFields");
		return cityMasterDAO.getCitiesWithProvince(provinceCode);
	}
}
