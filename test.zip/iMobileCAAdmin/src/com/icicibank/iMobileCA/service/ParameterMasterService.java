package com.icicibank.iMobileCA.service;

import java.util.List;
import java.util.logging.Logger;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icicibank.iMobileCA.dao.ParameterMasterDAO;
import com.icicibank.iMobileCA.model.Parameters;

@Service
public class ParameterMasterService {

	@Autowired
	ParameterMasterDAO parameterMasterDAO;
	ServletContext servletContext;
	private static final Logger logWriter = Logger
			.getLogger(ParameterMasterService.class.getName());
	public ParameterMasterDAO getParameterMasterDAO() {
		return parameterMasterDAO;
	}

	public void setParameterMasterDAO(ParameterMasterDAO parameterMasterDAO) {
		this.parameterMasterDAO = parameterMasterDAO;
	}

	public List<Parameters> getParameterDetails() {
		logWriter.info("Getting Fields Data List");
		return parameterMasterDAO.getParamDetails();
	}
	
	public int updateParameters(Parameters v){
		logWriter.info("In updateAddFields param : "+v);
		return parameterMasterDAO.updateParameter(v);
	}

}
