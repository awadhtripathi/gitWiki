package com.icicibank.iMobileCA.service;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icicibank.iMobileCA.dao.SchemeMasterDAO;
import com.icicibank.iMobileCA.model.Scheme;

@Service
public class SchemeMasterService {

	@Autowired
	private SchemeMasterDAO schemeMasterDAO;

	ServletContext servletContext;

	private static final Logger logWriter = Logger
			.getLogger(SchemeMasterService.class.getName());

	private HttpSession session;

	public void setSchemeMasterDAO(SchemeMasterDAO schemeMasterDAO) {
		this.schemeMasterDAO = schemeMasterDAO;
	}

	public List<Scheme> getSchemeDetails() {
		logWriter.info("In SchemeMaster Service Getting Fields Data List");
		return schemeMasterDAO.getSchemeDetails();
	}

	public List<Scheme> getSchemeDetailsForAuthor(String userId) {
		logWriter
				.info("In SchemeMaster Service Getting Fields Data List for authoring");
		return schemeMasterDAO.getSchemeDetailsForAuthoring(userId);
	}

	public int saveScheme(Scheme a, String param) {
		logWriter.info("In SchemeMaster Service adding new Scheme param:" + a);
		return schemeMasterDAO.addScheme(a, param);
	}

	public int authorScheme(Scheme a) {
		logWriter.info("In SchemeMaster Service authoring Scheme param :" + a);
		return schemeMasterDAO.authorScheme(a);
	}

	public int rejectScheme(Scheme a) {
		logWriter.info("In SchemeMaster Service rejecting Scheme param :" + a);
		return schemeMasterDAO.rejectScheme(a);
	}

	public List<Scheme> searchScheme(Scheme a) {
		logWriter.info("In SchemeMaster Service searching Scheme param :" + a);
		return schemeMasterDAO.searchScheme(a);
	}

	public int updateScheme(Scheme v) {
		logWriter.info("In SchemeMaster Service updating Scheme param : " + v);
		return schemeMasterDAO.updateScheme(v);
	}

	public int deleteScheme(Scheme v) {
		logWriter.info("In SchemeMaster Service deleting Scheme param : " + v);
		return schemeMasterDAO.deleteScheme(v);
	}

	public Scheme viewScheme(String schemeCode, String status) {
		logWriter.info("In SchemeMaster Service view Scheme param : " + schemeCode
				+ " " + status);
		return schemeMasterDAO.viewScheme(schemeCode, status);
	}
}
