package com.icicibank.iMobileCA.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.icicibank.iMobileCA.model.Customer;
import com.icicibank.iMobileCA.model.CustomerDevice;
import com.icicibank.iMobileCA.model.ManageCustomer;
import com.icicibank.iMobileCA.service.CustomerService;
import com.icicibank.iMobileCA.service.MenuMasterService;
import com.icicibank.iMobileCA.util.SMSRequestService;

@Controller
public class CustomerController {

	private static final Logger logWriter = Logger
			.getLogger(MenuMasterController.class.getName());
	private HttpSession session;

	@Autowired
	private CustomerService customerService;

	public CustomerService getCustomerService() {
		return customerService;
	}

	@RequestMapping(value = "/customerRegistration.do")
	public ModelAndView getCustomerRegistrationPage(HttpServletRequest request) {
		logWriter.info("In /customerRegistration.do customerRegistration page");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			logWriter.info("success");
			return new ModelAndView("customerRegistration", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	
	@RequestMapping(value = "/viewCust.do")
	public ModelAndView getCustomerDetails(HttpServletRequest request,
			@RequestParam(required = false) String custMobileNo,
			@RequestParam(required = false) String custID,
			@RequestParam(required = false) String selected,
			@RequestParam String pageNo) {
		logWriter.info("In /viewCust.do viewCust Details");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));

			switch (pageNo) {
			case "1":
				responseData.put("viewCustomer",
						customerService.getCustomer(custMobileNo, custID,selected));
				logWriter.info("success");
				return new ModelAndView("viewCustomerRegistration",
						responseData);
			case "2":

				Customer customer = new Customer();
				customer = customerService.getCustomer(custMobileNo, custID,selected);
				responseData.put("viewCustomer", customer);
				List<CustomerDevice> customerDeviceList = new ArrayList<>();
				customerDeviceList = customerService.getCustomerDevice(customer
						.getBayUserId());
				responseData.put("customerDeviceList", customerDeviceList);
				logWriter.info("success");
				return new ModelAndView("viewCustomerProfile", responseData);
			default:
				return new ModelAndView("customerProfile", responseData);
			}

		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/searchCustomer.do")
	public ModelAndView searchCustomerDetails(HttpServletRequest request,
			@RequestParam(required = false) String mobileNo,
			@RequestParam(required = false) String custId) {
		logWriter.info("In /viewCust.do viewCust Details");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("customerManagement",
					customerService.searchCustomer(mobileNo, custId));
			logWriter.info("success");
			return new ModelAndView("customerManagement", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/custProfile.do")
	public ModelAndView getCustomerProfilePage(HttpServletRequest request) {
		logWriter.info("In /customerRegistration.do customerRegistration page");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			logWriter.info("success");
			return new ModelAndView("customerProfile", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/custManagement.do")
	public ModelAndView getcustomerManagementPage(HttpServletRequest request) {
		logWriter.info("In /custManagement.do custManagement page");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("customerManagement",
					customerService.getCustomerDetails());
			logWriter.info("success");
			return new ModelAndView("customerManagement", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/getCustomerDetailsForUpdate.do")
	public ModelAndView getCustomerDetailsForUpdate(HttpServletRequest request,
			@RequestParam String custId) {
		logWriter.info("In /getCustomerDetailsForUpdate.do get Details");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){

			Customer customer = new Customer();
			customer = customerService.getCustomerForUpdate(custId);

			List<CustomerDevice> customerDeviceList = new ArrayList<>();
			customerDeviceList = customerService.getCustomerDevice(customer
					.getBayUserId());

			responseData = new HashMap<String, Object>();
			responseData.put("viewCustomer", customer);
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("customerDeviceList", customerDeviceList);
			responseData.put("updateCustomerDetails", customer);
			logWriter.info("success");
			return new ModelAndView("updateCustomerDetails", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/blockCustomerDevice.do")
	public ModelAndView blockCustomerDevice(HttpServletRequest request,
			@RequestParam String wl_Device_Id, @RequestParam String custId,
			@RequestParam String bayUserId, @RequestParam String device_Os_Type,
			@RequestParam String device_Os_Version,
			@RequestParam String device_Model, @RequestParam String app_Version,
			@RequestParam String reason) {
		logWriter.info("In /blockCustomerDevice.do blockCustomerDevice");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			/* blocking device */
			CustomerDevice customerDevice = new CustomerDevice();
			customerDevice.setApp_Version(app_Version);
			customerDevice.setDevice_Model(device_Model);
			customerDevice.setDevice_Os_Version(device_Os_Version);
			customerDevice.setDevice_Os_Type(device_Os_Type);
			customerDevice.setWl_Device_Id(wl_Device_Id);
			customerDevice.setBay_User_Id(bayUserId);
			customerDevice.setDevice_Blocked_Reaon(reason);
			
			customerDevice.setDevice_Blocked_By((String) session
					.getAttribute("userid"));
			customerDevice.setDevice_Blocked_Dt(new java.sql.Timestamp(
					new Date().getTime()));
			
			Integer result = customerService.blockDevice(customerDevice);
			if (result == 0) {
				logWriter.info("No rows updated");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Device not blocked ");
				// session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			} else if (result == 1) {
				logWriter
						.info("device updated but no added to 'Blocked table'");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Device blocked but Not updated");
				// session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			} else {
				logWriter.info("device updated and added to 'Blocked table'");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Device blocked successfully");
				// session.setAttribute("message","No rows updated");
				// return new ModelAndView("success", responseData);
				// }

				Customer customer = new Customer();
				customer = customerService.getCustomerForUpdate(custId);
				List<CustomerDevice> customerDeviceList = new ArrayList<>();
				customerDeviceList = customerService
						.getCustomerDevice(bayUserId);

				responseData = new HashMap<String, Object>();
				responseData.put("viewCustomer", customer);
				// responseData.put("message", "Success");
				responseData.put("userName", session.getAttribute("user"));
				responseData.put("customerDeviceList", customerDeviceList);
				responseData.put("updateCustomerDetails", customer);
				logWriter.info("success");
				return new ModelAndView("updateCustomerDetails", responseData);
			}
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}
	
	@RequestMapping(value = "/sendURL.do", method = RequestMethod.GET)
	public ModelAndView semd(HttpServletRequest request,
			@RequestParam String moNumber,@RequestParam String type) {
		logWriter.info("In /sendURLForAndroid.do sendURLForAndroid");
		//Users user = new Users();
		Map<String, Object> responseData = null;
		HttpSession session = null;
		session = request.getSession(false);
		Boolean url= false;
	//	user.setUserIdentity(userIdentity);
		String result = customerService.getUrl(type);    
		if(session!=null && session.getAttribute("userid") != null){
		try {
			if(!result.equals(null)){
		           SMSRequestService smsRequestService = new SMSRequestService();
		           url = smsRequestService.sendSMS(moNumber, result);
		               }
			if (url == false) {
				logWriter.info("No URL Send");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No URL Selected");
				// session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			} else {
								
				logWriter.info("URL Send successfully");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "URL Send successfully");
				// session.setAttribute("message","branch added successfully");
				return new ModelAndView("success", responseData);
			}
		} catch (Exception e) {
			// logWriter.error("Error: "+e.getMessage()+" Cause: "+e.getCause());
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Exception while sending url");
			// session.setAttribute("error_msg","Something went wrong. Please try again later");
			return new ModelAndView("urlFailure", responseData);
		}}else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}
	
	/*
	 * @RequestMapping(value = "/customerActivityLog.do") public ModelAndView
	 * getCustomerActivityLog(HttpServletRequest request,
	 * 
	 * @RequestParam String bayUserId) {
	 * logWriter.info("In /customerActivityLog.do customerActivityLog page");
	 * HttpSession session = null; session = request.getSession(false);
	 * Map<String, Object> responseData = null; if
	 * (session.getAttribute("userid") != null) { responseData = new
	 * HashMap<String, Object>(); responseData.put("message", "Success");
	 * responseData.put("userName", session.getAttribute("user"));
	 * 
	 * responseData.put("activityLog",customerService.getCustomerActivityLog
	 * (bayUserId));
	 * 
	 * logWriter.info("success"); return new ModelAndView("activityLog",
	 * responseData); } else { logWriter.info("Session Expired...");
	 * responseData = new HashMap<String, Object>();
	 * session.setAttribute("error_msg",
	 * "Session Expired... Please Login Again"); responseData.put("error_msg",
	 * "Session Expired... Please Login Again"); return new
	 * ModelAndView("Error", responseData); } }
	 */
}
