package com.icicibank.iMobileCA.controller;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.icicibank.iMobileCA.model.AuditLog;
import com.icicibank.iMobileCA.model.MenuItem;
import com.icicibank.iMobileCA.service.MenuMasterService;
import com.icicibank.iMobileCA.service.UserActionService;
import com.icicibank.iMobileCA.util.CommonUtil;

@Controller
public class MenuMasterController {

	private static final Logger logWriter = Logger
			.getLogger(MenuMasterController.class.getName());
	private HttpSession session;

	@Autowired
	private MenuMasterService menuMasterService;
	@Autowired
	private UserActionService userActionService;

	public UserActionService getUserActionService() {
		return userActionService;
	}
	public MenuMasterService getMenuMasterService() {
		return menuMasterService;
	}
	CommonUtil commonUtil= new CommonUtil();
	@RequestMapping(value = "/getMenuDetails.do")
	public ModelAndView getMenuDetails(HttpServletRequest request) {
		logWriter.info("In /getMenuDetails.do getMenuDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("menuDetails", menuMasterService.getMenuDetails());
			logWriter.info("success");
			return new ModelAndView("menuDetails", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/viewMenuDetails.do")
	public ModelAndView viewMenuDetails(HttpServletRequest request,
			@RequestParam String menuId, @RequestParam String status) {
		logWriter.info("In /viewMenuDetails.do viewMenuDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("viewMenu",
					menuMasterService.viewMenu(menuId, status));
			logWriter.info("success");
			return new ModelAndView("viewMenu", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/getMenuDetailsForUpdate.do")
	public ModelAndView updateMenuDetails(HttpServletRequest request,
			@RequestParam String menuId, @RequestParam String status) {
		logWriter
				.info("In /getMenuDetailsForUpdate.do getMenuDetailsForUpdate");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("updateMenuDetails",
					menuMasterService.viewMenu(menuId, status));
			logWriter.info("success");
			return new ModelAndView("updateMenuDetails", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/getMenuDetailsForAuthor.do")
	public ModelAndView getMenuDetailsForAuthoring(HttpServletRequest request) {
		logWriter
				.info("In /getMenuDetailsForAuthor.do getMenuDetailsForAuthor");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			String userId = (String) session.getAttribute("userid");
			responseData.put("menuDetailsForAuthor",
					menuMasterService.getMenuDetailsForAuthoring(userId));
			logWriter.info("success");
			return new ModelAndView("menuDetailsForAuthor", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/addMenu.do", method = RequestMethod.POST)
	public ModelAndView addMenuDetails(HttpServletRequest request,
			@RequestParam String menuId, @RequestParam String menuName,
			@RequestParam String reason) {
		logWriter.info("In /addMenu.do addMenuDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		int result = 0;
		MenuItem menuItem = new MenuItem();
		menuItem.setMenuName(menuName);
		menuItem.setMenuId(menuId);
		menuItem.setStatus("New");
		menuItem.setMenuStatus("Inactive");
		menuItem.setReason(reason);
		menuItem.setMaker(userId);
		menuItem.setMakerDt(new java.sql.Timestamp(new Date().getTime()));
		try {
			result = menuMasterService.saveMenu(menuItem, "add");
			if (result == 0) {
				logWriter.info("No rows Added");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows Added");
				// session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			} else if (result == 2) {
				logWriter.info("No rows Added....Duplicate ID");
				responseData = new HashMap<String, Object>();
				responseData
						.put("message",
								"Menu with same Id already exists, duplicate cannot be created");
				// session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			} else if (result == 3) {
				logWriter.info("No rows Added....Duplicate Name");
				responseData = new HashMap<String, Object>();
				responseData
						.put("message",
								"Menu with same Name already exists, duplicate cannot be created");
				// session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			} else {
				logWriter.info("Menu added successfully");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Menu added successfully");
				// session.setAttribute("message","branch added successfully");
				return new ModelAndView("success", responseData);
			}
		} catch (Exception e) {
			logWriter.error("Error: " + e.getMessage() + " Cause: "
					+ e.getCause());
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Exception while adding Menu");
			// session.setAttribute("error_msg","Something went wrong. Please try again later");
			return new ModelAndView("error", responseData);
		}} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/authorOrRejectMenu.do", method = RequestMethod.GET)
	public ModelAndView authorMenuDetails(HttpServletRequest request,
			@RequestParam String menuId, @RequestParam String menuStatus,
			@RequestParam String menuName, @RequestParam String reason,
			@RequestParam String maker, @RequestParam Timestamp makerDt,
			@RequestParam String status, @RequestParam String flag) throws ParseException {

		HttpSession session = null;
		session = request.getSession(false);
		MenuItem menuItem = new MenuItem();
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		menuItem.setMenuId(menuId);
		menuItem.setMenuName(menuName);
		menuItem.setReason(reason);
		menuItem.setStatus(status);
		menuItem.setMenuStatus(menuStatus);
		menuItem.setMaker(maker);
		menuItem.setMakerDt(makerDt);
		menuItem.setChecker(userId);
		String currentDate=CommonUtil.getDateTime(new java.util.Date().getTime(), "yyyyMMdd HH:mm:ss","EST");
		logWriter.info("currentDate"+currentDate);
		SimpleDateFormat datetimeFormatter1 = new SimpleDateFormat(
                "yyyyMMdd HH:mm:ss");
        Date lFromDate1 = datetimeFormatter1.parse(currentDate);
        System.out.println("gpsdate :" + lFromDate1);
        Timestamp fromTS1 = new Timestamp(lFromDate1.getTime());
        menuItem.setCheckerDt(fromTS1);
		AuditLog auditLog= new AuditLog();
		auditLog.setTableName("IMCA_MENU_DETAILS");
		String obj=commonUtil.convertToJson(menuItem);
		auditLog.setRequest(obj);
		auditLog.setMakerCd(maker);
		auditLog.setMakerDt(makerDt);
		auditLog.setAuthorCd(userId);
		auditLog.setAuthorDt(fromTS1);
		
		if (flag.equals("1")) {
			logWriter.info("In /authorMenu.do authorMenu");
			int result = 0;
			try {
				result = menuMasterService.authorMenu(menuItem);
				auditLog.setOperation("menu authorized");
				userActionService.updateAuditLog(auditLog);
				if (result == 0) {
					logWriter.info("No rows Added");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "No rows Added");
					return new ModelAndView("success", responseData);
				} else {
					logWriter.info("Menu authored successfully");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "Menu authored successfully");
					return new ModelAndView("success", responseData);
				}
			} catch (Exception e) {
				logWriter.error("Error: " + e.getMessage() + " Cause: "
						+ e.getCause());
				responseData = new HashMap<String, Object>();
				responseData.put("message",
						"Exception while authoririzing Menu");
				return new ModelAndView("success", responseData);
			}
		} else if (flag.equals("2")) {

			int result = 0;
			try {
				//result = menuMasterService.saveMenu(menuItem, "Reject");
				result = menuMasterService.rejectMenu(menuItem);
				auditLog.setOperation("menu authorized");
				userActionService.updateAuditLog(auditLog);
				if (result == 0) {
					logWriter.info("No rows Added");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "No rows Added");
					return new ModelAndView("success", responseData);
				} else {
					logWriter.info("Menu rejected successfully");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "Menu rejected successfully");
					return new ModelAndView("success", responseData);
				}
			} catch (Exception e) {
				logWriter.error("Error: " + e.getMessage() + " Cause: "
						+ e.getCause());
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Exception while rejecting Menu");
				return new ModelAndView("success", responseData);
			}
		}
		responseData = new HashMap<String, Object>();
		responseData.put("message", "No rows Added");
		return new ModelAndView("success", responseData);
	} else {
		logWriter.info("Session Expired...");
		responseData = new HashMap<String, Object>();
		responseData.put("error_msg",
				"Session Expired... Please Login Again");
		return new ModelAndView("authorFailure", responseData);
	}
	}

	/*
	 * @RequestMapping(value = "/rejectMenu.do", method = RequestMethod.GET)
	 * public ModelAndView rejectMenuDetails(HttpServletRequest request,
	 * 
	 * @RequestParam String menuId, @RequestParam String menuStatus,
	 * 
	 * @RequestParam String menuName, @RequestParam String reason,
	 * 
	 * @RequestParam String maker, @RequestParam Timestamp makerDt,
	 * 
	 * @RequestParam String status) {
	 * 
	 * }
	 */

	@RequestMapping(value = "/updateMenu.do", method = RequestMethod.POST)
	public ModelAndView updateMenuDetails(HttpServletRequest request,
			@RequestParam String menuStatus, @RequestParam String reason,
			@RequestParam String menuId, @RequestParam String menuName,
			@RequestParam String status) {
		logWriter.info("In /updateMenu.do updateMenu");
		HttpSession session = null;
		session = request.getSession(false);
		MenuItem menuItem = new MenuItem();
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		int result = 0;
		menuItem.setMenuId(menuId);
		menuItem.setReason(reason);
		menuItem.setMenuName(menuName);
		menuItem.setMenuStatus(menuStatus);
		menuItem.setStatus(status);
		menuItem.setMaker(userId);
		menuItem.setMakerDt(new java.sql.Timestamp(new Date().getTime()));
		try {
			result = menuMasterService.saveMenu(menuItem, "Modified");
			if (result == 0) {
				logWriter.info("No rows updated");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows updated");
				// session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			} else {
				logWriter.info("Menu updated successfully");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Menu updated successfully");
				// session.setAttribute("message","branch added successfully");
				return new ModelAndView("success", responseData);
			}
		} catch (Exception e) {
			logWriter.error("Error: " + e.getMessage() + " Cause: "
					+ e.getCause());
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Exception while updating menu");
			// session.setAttribute("error_msg","Something went wrong. Please try again later");
			return new ModelAndView("error", responseData);
		}} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/deleteMenu.do", method = RequestMethod.GET)
	public ModelAndView deleteMenuDetails(HttpServletRequest request,
			@RequestParam String menuId, @RequestParam String menuName,
			@RequestParam String menuStatus, @RequestParam String status,
			@RequestParam String reason) {
		logWriter.info("In /deleteMenu.do deleteMenu");
		HttpSession session = null;
		session = request.getSession(false);
		MenuItem menuItem = new MenuItem();
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		int result = 0;
		menuItem.setMenuId(menuId);
		menuItem.setReason(reason);
		menuItem.setMenuName(menuName);
		menuItem.setMenuStatus(menuStatus);
		menuItem.setStatus(status);
		// menuItem.setStatus("Authorized");
		menuItem.setMaker(userId);
		menuItem.setMakerDt(new java.sql.Timestamp(new Date().getTime()));
		try {
			result = menuMasterService.saveMenu(menuItem, "delete");
			if (result == 0) {
				logWriter.info("No rows deleted");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows deleted");
				// session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			} else {
				logWriter.info("menu deleted successfully");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "menu deleted successfully");
				// session.setAttribute("message","branch added successfully");
				return new ModelAndView("success", responseData);
			}
		} catch (Exception e) {
			logWriter.error("Error: " + e.getMessage() + " Cause: "
					+ e.getCause());
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Exception while deleting menu");
			// session.setAttribute("error_msg","Something went wrong. Please try again later");
			return new ModelAndView("error", responseData);
		}} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/searchMenu.do", method = RequestMethod.GET)
	public ModelAndView searchMenuDetails(HttpServletRequest request,
			@RequestParam("menuId") String menuId,
			@RequestParam("menuName") String menuName,
			@RequestParam("status") String status) {
		logWriter.info("In /searchMenu.do searchMenu");
		HttpSession session = null;
		session = request.getSession(false);
		MenuItem menuItem = new MenuItem();
		Map<String, Object> responseData = null;
		menuItem.setMenuName(menuName);
		menuItem.setMenuId(menuId);
		menuItem.setStatus(status);
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("menuDetails",
					menuMasterService.searchMenu(menuItem));
			logWriter.info("success");
			return new ModelAndView("menuDetails", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/searchMenuForAuthor.do", method = RequestMethod.GET)
	public ModelAndView searchMenuDetailsForAuthor(HttpServletRequest request,
			@RequestParam("menuId") String menuId,
			@RequestParam("menuName") String menuName,
			@RequestParam("status") String status) {
		logWriter.info("In /searchMenuForAuthor.do searchMenuForAuthor");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if (session!=null && session.getAttribute("userid") != null) {
		String userId = (String) session.getAttribute("userid");
		MenuItem menuItem = new MenuItem();
		menuItem.setMenuName(menuName);
		menuItem.setMenuId(menuId);
		menuItem.setStatus(status);
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			List<MenuItem> list = menuMasterService.searchMenu(menuItem);
			List<MenuItem> list2 = new ArrayList<MenuItem>(list);
			for (MenuItem item : list2) {
				if (item.getMaker().equals(userId)
						|| item.getStatus().equals("Authorized")
						|| item.getStatus().equals("Deleted and Authorized"))
					list.remove(item);
			}
			responseData.put("menuDetailsForAuthor", list);
			logWriter.info("success");
			return new ModelAndView("menuDetailsForAuthor", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

}
