package com.icicibank.iMobileCA.controller;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.icicibank.iMobileCA.model.AuditLog;
import com.icicibank.iMobileCA.model.Cities;
import com.icicibank.iMobileCA.service.CityMasterService;
import com.icicibank.iMobileCA.service.ProvinceMasterService;
import com.icicibank.iMobileCA.service.UserActionService;
import com.icicibank.iMobileCA.util.CommonUtil;

@RestController
public class CityMasterController {
	private static final Logger logWriter = Logger
			.getLogger(CityMasterController.class.getName());
	private HttpSession session;

	@Autowired
	private CityMasterService cityMasterService;
	@Autowired
	private ProvinceMasterService provinceMasterService;
	@Autowired
	private UserActionService userActionService;

	public UserActionService getUserActionService() {
		return userActionService;
	}
	public ProvinceMasterService getProvinceMasterService() {
		return provinceMasterService;
	}

	public CityMasterService getCityMasterService() {
		return cityMasterService;
	}

	CommonUtil commonUtil= new CommonUtil();
	@RequestMapping(value = "/getCityDetails.do")
	public ModelAndView getCityDetails(HttpServletRequest request) {
		logWriter.info("In /getCityDetails.do getCityDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if (session != null && session.getAttribute("userid") != null) {
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("cityDetails", cityMasterService.getCityDetails());
			responseData.put("provinceList",
					provinceMasterService.getAuthorizedProvinceDetails());
			logWriter.info("success");
			return new ModelAndView("cityDetails", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/getCityDetailsForAuthor.do")
	public ModelAndView getCityDetailsForAuthoring(HttpServletRequest request) {
		logWriter
				.info("In /getCityDetailsForAuthor.do getCityDetailsForAuthor");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if (session != null && session.getAttribute("userid") != null) {
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			String userId = (String) session.getAttribute("userid");
			responseData.put("cityDetails",
					cityMasterService.getCityDetailsForAuthor(userId));
			logWriter.info("success");
			return new ModelAndView("cityDetailsForAuthor", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/addCity.do", method = RequestMethod.POST)
	public ModelAndView addCityDetails(HttpServletRequest request,
			@RequestParam String cityName, @RequestParam String cityCode,
			@RequestParam String provinceCode, @RequestParam String status)
			throws ParseException {

		logWriter.info("In /addCity.do addCityDetails");
		HttpSession session = null;
		session = request.getSession(false);
		List<AuditLog> auditlist = new ArrayList<AuditLog>();
		Map<String, Object> responseData = null;

		if (session != null && session.getAttribute("userid") != null) {
			logWriter.info("userId is: " + session.getAttribute("userid"));
			String userId = (String) session.getAttribute("userid");
			int result = 0;
			Cities city = new Cities();
			city.setCityName(cityName);
			city.setCityCode(cityCode);
			city.setProvinceCode(provinceCode);
			city.setStatus(status);
			city.setMaker(userId);
			city.setActive("N");
			String currentDate = CommonUtil.getDateTime(
					new java.util.Date().getTime(), "yyyyMMdd HH:mm:ss", "EST");
			logWriter.info("currentDate" + currentDate);
			SimpleDateFormat datetimeFormatter1 = new SimpleDateFormat(
					"yyyyMMdd HH:mm:ss");
			Date lFromDate1 = datetimeFormatter1.parse(currentDate);
			System.out.println("gpsdate :" + lFromDate1);
			Timestamp fromTS1 = new Timestamp(lFromDate1.getTime());
			city.setMakerDt(fromTS1);
			/*
			 * AuditLog auditLog= new AuditLog();
			 * auditLog.setTableName("IMCA_CITY_DETAILS_MST");
			 * auditLog.setColumnName("CITY_CODE");
			 * auditLog.setNewValue(cityCode);
			 * //auditLog.setOldValue(cityName1); auditLog.setUserId(userId);
			 * auditLog.setAuthStatus("ADDCITY");
			 * auditLog.setUserRole("Maker");//role
			 * auditLog.setUserDt(fromTS1);//userDt //auditlist.add(auditLog);
			 */try {
				result = cityMasterService.saveCity(city, "add");
				// userActionService.updateAuditLog(auditLog);
				if (result == 0) {
					logWriter.info("No rows Added");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "No rows Added");
					// session.setAttribute("message","No rows updated");
					return new ModelAndView("success", responseData);
				} else {
					logWriter.info("City added successfully");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "City added successfully");
					// session.setAttribute("message","City added successfully");
					return new ModelAndView("success", responseData);
				}
			} catch (Exception e) {
				logWriter.error("Error: " + e.getMessage() + " Cause: "
						+ e.getCause());
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Exception while adding city");
				// session.setAttribute("error_msg","Something went wrong. Please try again later");
				return new ModelAndView("Error", responseData);
			}
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/authorOrRejectCity.do")
	public ModelAndView authorCityDetails(HttpServletRequest request,
			@RequestParam String cityCode, @RequestParam String cityName,
			@RequestParam String provinceCode, @RequestParam String maker,
			@RequestParam Timestamp makerDt, @RequestParam String active,
			@RequestParam String status, @RequestParam String flag) throws JSONException, ParseException {
		logWriter.info("In /authorOrRejectCity.do authorOrRejectCity");
		HttpSession session = null;
		session = request.getSession(false);
		Cities city = new Cities();
		Map<String, Object> responseData = null;
		if (session != null && session.getAttribute("userid") != null) {
			logWriter.info("userId is: " + session.getAttribute("userid"));
			String userId = (String) session.getAttribute("userid");
			int result = 0;
			city.setCityName(cityName);
			city.setCityCode(cityCode);
			city.setProvinceCode(provinceCode);
			city.setStatus(status);
			city.setMaker(maker);
			city.setActive(active);
			city.setMakerDt(makerDt);
			city.setChecker(userId);
			String currentDate = CommonUtil.getDateTime(
					new java.util.Date().getTime(), "yyyyMMdd HH:mm:ss", "EST");
			logWriter.info("currentDate" + currentDate);
			SimpleDateFormat datetimeFormatter1 = new SimpleDateFormat(
					"yyyyMMdd HH:mm:ss");
			Date lFromDate1 = datetimeFormatter1.parse(currentDate);
			System.out.println("gpsdate :" + lFromDate1);
			Timestamp fromTS1 = new Timestamp(lFromDate1.getTime());
			city.setCheckerDt(fromTS1);
			AuditLog auditLog = new AuditLog();
			auditLog.setTableName("IMCA_CITY_DETAILS_MST");
			String obj=commonUtil.convertToJson(city);
			/*JSONObject obj = new JSONObject();
			obj.put("cityCode", cityCode);
			obj.put("cityName", cityName);
			obj.put("provinceCode", provinceCode);
			obj.put("status", status);*/
			auditLog.setRequest(obj);
			auditLog.setMakerCd(maker);
			auditLog.setMakerDt(makerDt);
			auditLog.setAuthorCd(userId);
			auditLog.setAuthorDt(fromTS1);
			// auditlist.add(auditLog);
			if (flag.equals("1")) {
				logWriter.info("In /authorcity.do authorcity");
				try {
					result = cityMasterService.authorCity(city);
					auditLog.setOperation("City authorized");
					userActionService.updateAuditLog(auditLog);
					if (result == 0) {
						logWriter.info("No rows Added");
						responseData = new HashMap<String, Object>();
						responseData.put("message", "No rows Added");
						// session.setAttribute("message","No rows updated");
						return new ModelAndView("success", responseData);
					} else {
						logWriter.info("City authored successfully");
						responseData = new HashMap<String, Object>();
						responseData.put("message",
								"City authored successfully");
						// session.setAttribute("message","City added successfully");
						return new ModelAndView("success", responseData);
					}
				} catch (Exception e) {
					logWriter.error("Error: " + e.getMessage() + " Cause: "
							+ e.getCause());
					responseData = new HashMap<String, Object>();
					responseData.put("message", "Exception while adding city");
					// session.setAttribute("error_msg","Something went wrong. Please try again later");
					return new ModelAndView("error", responseData);
				}
			} else if (flag.equals("2")) {
				logWriter.info("In /rejectcity.do rejectcity");
				try {
					// result = cityMasterService.saveCity(city, "Reject");
					result = cityMasterService.rejectCity(city);
					auditLog.setOperation("City Rejected");
					userActionService.updateAuditLog(auditLog);
					if (result == 0) {
						logWriter.info("No rows Added");
						responseData = new HashMap<String, Object>();
						responseData.put("message", "No rows Added");
						return new ModelAndView("success", responseData);
					} else {
						logWriter.info("City rejected successfully");
						responseData = new HashMap<String, Object>();
						responseData.put("message",
								"City rejected successfully");
						return new ModelAndView("success", responseData);
					}
				} catch (Exception e) {
					logWriter.error("Error: " + e.getMessage() + " Cause: "
							+ e.getCause());
					responseData = new HashMap<String, Object>();
					responseData.put("message",
							"Exception while rejecting Menu");
					return new ModelAndView("success", responseData);
				}
			}
			responseData = new HashMap<String, Object>();
			responseData.put("message", "No rows Added");
			return new ModelAndView("success", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}
	
	/*@RequestMapping(value = "/viewCity.do")
	public ModelAndView viewCityDetails(HttpServletRequest request,
			@RequestParam String cityCode, @RequestParam String status) {
		logWriter.info("In /viewCity.do viewCityDetails");
		HttpSession session = null;
		session = request.getSession(false);
		// Cities city=new Cities();
		Map<String, Object> responseData = null;
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		// city.setCityName(cityName);
		// city.setCityCode(cityCode);
		if (session != null && session.getAttribute("userid") != null) {
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			// responseData.put("userName",session.getAttribute("user"));
			responseData.put("inputData",
					cityMasterService.viewCity(cityCode, status));
			// responseData.put("provinceList",
			// provinceMasterService.getProvinceDetails());
			logWriter.info("success");
			return new ModelAndView("viewCity", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}
*/
	/*@RequestMapping(value = "/getCityDetailsForUpdate.do")

	public ModelAndView getCityDetailsForUpdate(HttpServletRequest request,
			@RequestParam String cityCode, @RequestParam String status) {
		logWriter
				.info("In /getCityDetailsForUpdate.do getCityDetailsForUpdate");
		HttpSession session = null;
		session = request.getSession(false);
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		Map<String, Object> responseData = null;
		if (session != null && session.getAttribute("userid") != null) {
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("inputData",
					cityMasterService.viewCity(cityCode, status));
			responseData.put("provinceList",
					provinceMasterService.getProvinceDetails());
			logWriter.info("success");
			return new ModelAndView("editCity", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}*/

	/*@RequestMapping(value = "/getCityDetailsForDelete.do")
	public ModelAndView getCityDetailsForDelete(HttpServletRequest request,
			@RequestParam String cityCode, @RequestParam String status) {
		logWriter
				.info("In /getCityDetailsForUpdate.do getCityDetailsForUpdate");
		HttpSession session = null;
		session = request.getSession(false);
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		Map<String, Object> responseData = null;
		if (session != null && session.getAttribute("userid") != null) {
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("inputData",
					cityMasterService.viewCity(cityCode, status));
			// responseData.put("provinceList",
			// provinceMasterService.getProvinceDetails());
			logWriter.info("success");
			return new ModelAndView("deleteCity", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}*/


	@RequestMapping(value = "/getProvinceDetailsForCity.do")
	public ModelAndView getProvinceDetailsForCity(HttpServletRequest request) {
		logWriter
				.info("In /getCityDetailsForUpdate.do getCityDetailsForUpdate");
		HttpSession session = null;
		session = request.getSession(false);
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		Map<String, Object> responseData = null;
		if (session != null && session.getAttribute("userid") != null) {
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("provinceList",
					provinceMasterService.getAuthorizedProvinceDetails());
			logWriter.info("success");
			return new ModelAndView("addCity", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/updateCity.do", method = RequestMethod.POST)
	public ModelAndView updateCityDetails(HttpServletRequest request,
			@RequestParam String cityName1, @RequestParam String cityName,
			@RequestParam String cityCode, @RequestParam String provinceCode,
			@RequestParam String status) throws ParseException {

		logWriter.info("In /updateCity.do updateCityDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if (session != null && session.getAttribute("userid") != null) {
			logWriter.info("userId is: " + session.getAttribute("userid"));
			String userId = (String) session.getAttribute("userid");
			int result = 0;
			String currentDate = CommonUtil.getDateTime(
					new java.util.Date().getTime(), "yyyyMMdd HH:mm:ss", "EST");
			logWriter.info("currentDate" + currentDate);
			SimpleDateFormat datetimeFormatter1 = new SimpleDateFormat(
					"yyyyMMdd HH:mm:ss");
			Date lFromDate1 = datetimeFormatter1.parse(currentDate);
			System.out.println("gpsdate :" + lFromDate1);
			Timestamp fromTS1 = new Timestamp(lFromDate1.getTime());
			Cities city = new Cities();
			city.setCityName(cityName);
			city.setCityCode(cityCode);
			city.setProvinceCode(provinceCode);
			// city.setStatus(status);
			city.setStatus(status);
			city.setMaker(userId);
			city.setMakerDt(fromTS1);
			/*
			 * AuditLog auditLog= new AuditLog();
			 * auditLog.setTableName("IMCA_CITY_DETAILS_MST");
			 * auditLog.setColumnName("CITY_NAME");
			 * auditLog.setNewValue(cityName); auditLog.setOldValue(cityName1);
			 * auditLog.setUserId(userId); auditLog.setAuthStatus("ADDCITY");
			 * auditLog.setUserRole("Maker");//role auditLog.setUserDt(fromTS1);
			 */
			try {
				// result=cityMasterService.updateCity(city);
				result = cityMasterService.saveCity(city, "Modified");
				// userActionService.updateAuditLog(auditLog);
				if (result == 0) {
					logWriter.info("No rows updated");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "No rows updated");
					// session.setAttribute("message","No rows updated");
					return new ModelAndView("success", responseData);
				} else {
					logWriter.info("City added successfully");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "City updated successfully");
					// session.setAttribute("message","City added successfully");
					return new ModelAndView("success", responseData);
				}
			} catch (Exception e) {
				logWriter.error("Error: " + e.getMessage() + " Cause: "
						+ e.getCause());
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Exception while updating city");
				// session.setAttribute("error_msg","Something went wrong. Please try again later");
				return new ModelAndView("error", responseData);
			}
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/deleteCity.do", method = RequestMethod.POST)
	public ModelAndView deleteCityDetails(HttpServletRequest request,
			@RequestParam("cityName") String cityName,
			@RequestParam String cityCode, @RequestParam String provinceCode,
			@RequestParam String status) {
		logWriter.info("In /deleteCity.do deleteCityDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Cities city = new Cities();
		Map<String, Object> responseData = null;
		if (session != null && session.getAttribute("userid") != null) {
			logWriter.info("userId is: " + session.getAttribute("userid"));
			String userId = (String) session.getAttribute("userid");
			int result = 0;
			city.setCityName(cityName);
			city.setCityCode(cityCode);
			city.setProvinceCode(provinceCode);
			city.setStatus(status);
			city.setMaker(userId);
			city.setMakerDt(new java.sql.Timestamp(new Date().getTime()));
			try {
				// result=cityMasterService.deleteCity(city);
				result = cityMasterService.saveCity(city, "delete");
				if (result == 0) {
					logWriter.info("No rows deleted");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "No rows deleted");
					// session.setAttribute("message","No rows updated");
					return new ModelAndView("success", responseData);
				} else {
					logWriter.info("City deleted successfully");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "City deleted successfully");
					// session.setAttribute("message","City added successfully");
					return new ModelAndView("success", responseData);
				}
			} catch (Exception e) {
				logWriter.error("Error: " + e.getMessage() + " Cause: "
						+ e.getCause());
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Exception while deleting city");
				// session.setAttribute("error_msg","Something went wrong. Please try again later");
				return new ModelAndView("error", responseData);
			}
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/searchCity.do", method = RequestMethod.GET)
	public ModelAndView searchCityDetails(HttpServletRequest request,
			@RequestParam("cityName") String cityName,
			@RequestParam("cityCode") String cityCode,
			@RequestParam("status") String status) {
		logWriter.info("In /searchCity.do searchCityDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Cities city = new Cities();
		Map<String, Object> responseData = null;
		// String userId=(String) session.getAttribute("userid");
		city.setCityName(cityName);
		city.setCityCode(cityCode);
		city.setStatus(status);
		if (session != null && session.getAttribute("userid") != null) {
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("cityDetails", cityMasterService.searchCity(city));
			logWriter.info("success");
			return new ModelAndView("cityDetails", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/searchCityForAuthor.do", method = RequestMethod.GET)
	public ModelAndView searchMenuDetailsForAuthor(HttpServletRequest request,
			@RequestParam("cityName") String cityName,
			@RequestParam("cityCode") String cityCode,
			@RequestParam("status") String status) {
		logWriter.info("In /searchCityForAuthor.do searchCityForAuthor");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if (session != null && session.getAttribute("userid") != null) {
			String userId = (String) session.getAttribute("userid");
			Cities city = new Cities();
			city.setCityName(cityName);
			city.setCityCode(cityCode);
			city.setStatus(status);
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			List<Cities> list = cityMasterService.searchCity(city);
			List<Cities> list2 = new ArrayList<Cities>(list);
			for (Cities item : list2) {
				if (item.getMaker().equals(userId)
						|| item.getStatus().equals("Authorized")
						|| item.getStatus().equals("Deleted and Authorized"))
					list.remove(item);
			}
			responseData.put("cityDetails", list);
			logWriter.info("success");
			return new ModelAndView("cityDetailsForAuthor", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}
}
