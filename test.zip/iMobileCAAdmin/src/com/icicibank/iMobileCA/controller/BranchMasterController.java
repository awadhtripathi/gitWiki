package com.icicibank.iMobileCA.controller;

import java.lang.reflect.InvocationTargetException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.icicibank.iMobileCA.model.AuditLog;
import com.icicibank.iMobileCA.model.Branches;
import com.icicibank.iMobileCA.model.Cities;
import com.icicibank.iMobileCA.model.CitiesListResponse;
import com.icicibank.iMobileCA.model.Province;
import com.icicibank.iMobileCA.service.BranchMasterService;
import com.icicibank.iMobileCA.service.CityMasterService;
import com.icicibank.iMobileCA.service.ProvinceMasterService;
import com.icicibank.iMobileCA.service.UserActionService;
import com.icicibank.iMobileCA.util.CommonUtil;

@Controller
public class BranchMasterController {
	private static final Logger logWriter = Logger
			.getLogger(BranchMasterController.class.getName());
	private HttpSession session;
	@Autowired
	private BranchMasterService branchMasterService;

	@Autowired
	private ProvinceMasterService provinceMasterService;

	@Autowired
	private CityMasterService cityMasterService;
	@Autowired
	private UserActionService userActionService;

	public UserActionService getUserActionService() {
		return userActionService;
	}

	public BranchMasterService getBranchMasterService() {
		return branchMasterService;
	}

	public CityMasterService getCityMasterService() {
		return cityMasterService;
	}

	public ProvinceMasterService getProvinceMasterService() {
		return provinceMasterService;
	}
	CommonUtil commonUtil= new CommonUtil();
	@RequestMapping(value = "/getBranchDetails.do")
	public ModelAndView getBranchDetails(HttpServletRequest request) {
		logWriter.info("In /getbranchDetails.do getbranchDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("branchDetails",
					branchMasterService.getBranchDetails());
			List<Province> provinceList = provinceMasterService
					.getAuthorizedProvinceDetails();
			responseData.put("provinceList",
					provinceMasterService.getAuthorizedProvinceDetails());
			for (int i = 0; i < provinceList.size(); i++) {
				responseData.put(provinceList.get(i).getProvinceCode() + "",
						cityMasterService.getCitiesWithProvince(provinceList
								.get(i).getProvinceCode()));
			}
			logWriter.info("success");
			return new ModelAndView("branchDetails", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/createBranch.do")
	public ModelAndView createNewBranch(HttpServletRequest request) {
		logWriter.info("In /createBranch.do createBranch");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("provinceList",
					provinceMasterService.getAuthorizedProvinceDetails());
			logWriter.info("success");
			return new ModelAndView("addBranch", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/getBranchDetailsForAuthor.do")
	public ModelAndView getCityDetailsForAuthoring(HttpServletRequest request) {
		logWriter.info("In /getCityDetails.do getCityDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			String userId = (String) session.getAttribute("userid");
			responseData.put("branchDetailsForAuthor",
					branchMasterService.getBranchDetailsForAuthor(userId));
			logWriter.info("success");
			return new ModelAndView("branchDetailsForAuthor", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/addBranch.do", method = RequestMethod.POST)
	public ModelAndView addBranchDetails(HttpServletRequest request,
			@RequestParam String branchName, @RequestParam String branchCode,
			@RequestParam String address, @RequestParam String cityCode,
			@RequestParam String provinceCode, @RequestParam String postalCode,
			@RequestParam String telephone, @RequestParam String status,
			@RequestParam String fax, @RequestParam String latitude,
			@RequestParam String longitude, @RequestParam String timings,
			@RequestParam String reason) {
		logWriter.info("In /addBranch.do addbranchDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Branches branch = new Branches();
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		int result = 0;
		branch.setBranchName(branchName);
		branch.setBranchCode(branchCode);
		branch.setAddress(address);
		branch.setCityCode(cityCode);
		branch.setProvinceCode(provinceCode);
		branch.setPostalCode(postalCode);
		branch.setTelephone(telephone);
		branch.setFax(fax);
		branch.setTimings(timings);
		branch.setLatitude(latitude);
		branch.setLongitude(longitude);
		branch.setStatus(status);
		branch.setReason(reason);
		branch.setMaker(userId);
		branch.setMakerDt(new java.sql.Timestamp(new Date().getTime()));
		try {
			result = branchMasterService.saveBranch(branch, "New");
			if (result == 0) {
				logWriter.info("No rows Added");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows Added");
				// session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			} else {
				logWriter.info("branch added successfully");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "branch added successfully");
				// session.setAttribute("message","branch added successfully");
				return new ModelAndView("success", responseData);
			}
		} catch (Exception e) {
			logWriter.error("Error: " + e.getMessage() + " Cause: "
					+ e.getCause());
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Exception while adding branch");
			// session.setAttribute("error_msg","Something went wrong. Please try again later");
			return new ModelAndView("error", responseData);
		}} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/updateBranch.do", method = RequestMethod.POST)
	public ModelAndView updateBranchDetails(HttpServletRequest request,
			@RequestParam String branchName, @RequestParam String branchCode,
			@RequestParam String address, @RequestParam String provinceCode,
			@RequestParam String active) {
		logWriter.info("In /updatebranch.do updatebranchDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Branches branch = new Branches();
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		int result = 0;
		branch.setBranchName(branchName);
		branch.setBranchCode(branchCode);
		branch.setAddress(address);
		branch.setActive(active);
		branch.setStatus("Authorized");
		// branch.setCityCode(city);
		branch.setProvinceCode(provinceCode);
		/*
		 * branch.setPostalCode(postalCode); branch.setTelephone(telephone);
		 * branch.setFax(fax); branch.setTimings(timings);
		 * branch.setLatitude(latitude); branch.setLongitude(longitude);
		 * branch.setStatus(status);
		 */
		branch.setMaker(userId);
		branch.setMakerDt(new java.sql.Timestamp(new Date().getTime()));
		try {
			result = branchMasterService.saveBranch(branch, "Modified");
			if (result == 0) {
				logWriter.info("No rows updated");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows updated");
				// session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			} else {
				logWriter.info("branch added successfully");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "branch updated successfully");
				// session.setAttribute("message","branch added successfully");
				return new ModelAndView("success", responseData);
			}
		} catch (Exception e) {
			logWriter.error("Error: " + e.getMessage() + " Cause: "
					+ e.getCause());
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Exception while updating branch");
			// session.setAttribute("error_msg","Something went wrong. Please try again later");
			return new ModelAndView("error", responseData);
		}} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/deleteBranch.do", method = RequestMethod.POST)
	public ModelAndView deleteBranchDetails(HttpServletRequest request,
			@RequestParam String branchName, @RequestParam String branchCode,
			@RequestParam String address, @RequestParam String provinceCode,
			@RequestParam String postalCode, @RequestParam String telephone,
			@RequestParam String status, @RequestParam String fax) {
		logWriter.info("In /deletebranch.do deletebranchDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Branches branch = new Branches();
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		int result = 0;
		branch.setBranchName(branchName);
		branch.setBranchCode(branchCode);
		branch.setAddress(address);
		branch.setProvinceCode(provinceCode);
		branch.setPostalCode(postalCode);
		branch.setTelephone(telephone);
		branch.setFax(fax);
		/*
		 * branch.setTimings(timings); branch.setLatitude(latitude);
		 * branch.setLongitude(longitude);
		 */
		branch.setStatus(status);
		branch.setMaker(userId);
		branch.setMakerDt(new java.sql.Timestamp(new Date().getTime()));
		try {
			result = branchMasterService.saveBranch(branch, "Delete");
			if (result == 0) {
				logWriter.info("No rows deleted");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows deleted");
				// session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			} else {
				logWriter.info("branch deleted successfully");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "branch deleted successfully");
				// session.setAttribute("message","branch added successfully");
				return new ModelAndView("success", responseData);
			}
		} catch (Exception e) {
			logWriter.error("Error: " + e.getMessage() + " Cause: "
					+ e.getCause());
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Exception while deleting branch");
			// session.setAttribute("error_msg","Something went wrong. Please try again later");
			return new ModelAndView("error", responseData);
		}} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/searchBranch.do", method = RequestMethod.GET)
	public ModelAndView searchBranchDetails(HttpServletRequest request,
			@RequestParam String branchName, @RequestParam String branchCode,
			@RequestParam String status) {
		logWriter.info("In /searchbranch.do searchbranchDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Branches branch = new Branches();
		Map<String, Object> responseData = null;
		// String userId=(String) session.getAttribute("userid");
		branch.setBranchName(branchName);
		branch.setBranchCode(branchCode);
		branch.setStatus(status);
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("branchDetails",
					branchMasterService.searchBranch(branch));
			logWriter.info("success");
			return new ModelAndView("branchDetails", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/searchBranchForAuthor.do", method = RequestMethod.GET)
	public ModelAndView searchBranchForAuthor(HttpServletRequest request,
			@RequestParam String branchName, @RequestParam String branchCode,
			@RequestParam String status) {
		logWriter.info("In /searchbranch.do searchbranchDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Branches branch = new Branches();
		Map<String, Object> responseData = null;
		// String userId=(String) session.getAttribute("userid");
		branch.setBranchName(branchName);
		branch.setBranchCode(branchCode);
		branch.setStatus(status);

		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			List<Branches> list = branchMasterService.searchBranch(branch);
			List<Branches> list1 = new ArrayList<Branches>(list);
			for (Branches branches : list1) {
				if (branches.getMaker().equals(session.getAttribute("userId"))
						|| branches.getStatus().equals("Rejected")
						|| branches.getStatus().equals("Authorized")
						|| branches.getStatus()
								.equals("Deleted and Authorized")) {
					list.remove(branches);
				}
			}
			responseData.put("branchDetailsForAuthor", list);
			logWriter.info("success");
			return new ModelAndView("branchDetailsForAuthor", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/authorOrRejectBranch.do", method = RequestMethod.POST)
	public ModelAndView authorBranchDetails(HttpServletRequest request,
			@RequestParam String flag, @RequestParam String branchName,
			@RequestParam String branchCode, @RequestParam String address,
			@RequestParam String cityCode, @RequestParam String provinceCode,
			@RequestParam String postalCode, @RequestParam String telephone,
			@RequestParam String status, @RequestParam String fax,
			@RequestParam String latitude, @RequestParam String longitude,
			@RequestParam String timings, @RequestParam String active,
			@RequestParam String maker,@RequestParam Timestamp makerDt) throws ParseException {

		HttpSession session = null;
		session = request.getSession(false);
		Branches branch = new Branches();
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		branch.setBranchName(branchName);
		branch.setActive(active);
		branch.setBranchCode(branchCode);
		branch.setAddress(address);
		branch.setCityCode(cityCode);
		branch.setProvinceCode(provinceCode);
		branch.setPostalCode(postalCode);
		branch.setTelephone(telephone);
		branch.setFax(fax);
		branch.setTimings(timings);
		branch.setLatitude(latitude);
		branch.setLongitude(longitude);
		branch.setStatus(status);
		branch.setChecker(userId);
		String currentDate=CommonUtil.getDateTime(new java.util.Date().getTime(), "yyyyMMdd HH:mm:ss","EST");
		logWriter.info("currentDate"+currentDate);
		SimpleDateFormat datetimeFormatter1 = new SimpleDateFormat(
                "yyyyMMdd HH:mm:ss");
        Date lFromDate1 = datetimeFormatter1.parse(currentDate);
        System.out.println("gpsdate :" + lFromDate1);
        Timestamp fromTS1 = new Timestamp(lFromDate1.getTime());
        branch.setCheckerDt(fromTS1);
		AuditLog auditLog= new AuditLog();
		auditLog.setTableName("IMCA_BRANCH_DETAILS_NEW");
		String obj=commonUtil.convertToJson(branch);
		auditLog.setRequest(obj);
		auditLog.setMakerCd(maker);
		auditLog.setMakerDt(makerDt);
		auditLog.setAuthorCd(userId);
		auditLog.setAuthorDt(fromTS1);
		if (flag.equals("1")) {
			logWriter.info("In /authorBranch.do ");
			logWriter.info("userId is: " + session.getAttribute("userid"));
			int result = 0;
			try {
				result = branchMasterService.authorBranch(branch);
				auditLog.setOperation("branch authorized");
				userActionService.updateAuditLog(auditLog);
				if (result == 0) {
					logWriter.info("No rows Added");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "No rows Added");
					// session.setAttribute("message","No rows updated");
					return new ModelAndView("success", responseData);
				} else {
					logWriter.info("branch authorized successfully");
					responseData = new HashMap<String, Object>();
					responseData.put("message",
							"branch authorized successfully");
					// session.setAttribute("message","branch added successfully");
					return new ModelAndView("success", responseData);
				}
			} catch (Exception e) {
				logWriter.error("Error: " + e.getMessage() + " Cause: "
						+ e.getCause());
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Exception while adding branch");
				// session.setAttribute("error_msg","Something went wrong. Please try again later");
				return new ModelAndView("error", responseData);
			}
		}

		else if (flag.equals("2")) {
			logWriter.info("In /rejectBranch.do rejectBranch");
			logWriter.info("userId is: " + session.getAttribute("userid"));
			int result = 0;
			try {
				//result = branchMasterService.saveBranch(branch, "Reject");
				result = branchMasterService.rejectBranch(branch);
				auditLog.setOperation("branch rejected");
				userActionService.updateAuditLog(auditLog);
				if (result == 0) {
					logWriter.info("No rows Added");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "No rows Added");
					// session.setAttribute("message","No rows updated");
					return new ModelAndView("success", responseData);
				} else {
					logWriter.info("branch authored successfully");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "branch Rejected successfully");
					// session.setAttribute("message","branch added successfully");
					return new ModelAndView("success", responseData);
				}
			} catch (Exception e) {
				logWriter.error("Error: " + e.getMessage() + " Cause: "
						+ e.getCause());
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Exception while rejecting branch");
				// session.setAttribute("error_msg","Something went wrong. Please try again later");
				return new ModelAndView("error", responseData);
			}

		}

		responseData = new HashMap<String, Object>();
		responseData.put("message", "No rows Added");
		return new ModelAndView("success", responseData);
	} else {
		logWriter.info("Session Expired...");
		responseData = new HashMap<String, Object>();
		responseData.put("error_msg",
				"Session Expired... Please Login Again");
		return new ModelAndView("authorFailure", responseData);
	}
	}

	@RequestMapping(value = "/getCitiesForProvince.do", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public CitiesListResponse getCitiesForProvince(HttpServletRequest request,
			@RequestBody HashMap<String, String> json)
			throws IllegalAccessException, InvocationTargetException {
		logWriter.info("In /getCitiesForProvince.do getCitiesForProvince");
		HttpSession session = null;
		CitiesListResponse citiesListResponse = new CitiesListResponse();
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if (session!=null && session.getAttribute("userid") != null) {
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		// int result = 0;
			// responseData = new HashMap<String, Object>();
			// responseData.put("message", "Success");
			// responseData.put("userName", session.getAttribute("user"));
			List<Cities> cities = cityMasterService.getCitiesWithProvince(json
					.get("provinceCode"));
			citiesListResponse.setCitiesList(cities);
			logWriter.info("success");
			return citiesListResponse;
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return citiesListResponse;
		}
	}
}
