package com.icicibank.iMobileCA.controller;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.icicibank.iMobileCA.model.AuditLog;
import com.icicibank.iMobileCA.model.MenuItem;
import com.icicibank.iMobileCA.model.Province;
import com.icicibank.iMobileCA.service.ProvinceMasterService;
import com.icicibank.iMobileCA.service.UserActionService;
import com.icicibank.iMobileCA.util.CommonUtil;

@Controller
public class ProvinceMasterController {
	private static final Logger logWriter = Logger
			.getLogger(ProvinceMasterController.class.getName());
	private HttpSession session;

	@Autowired
	private ProvinceMasterService provinceMasterService;
	@Autowired
	private UserActionService userActionService;

	
	public UserActionService getUserActionService() {
		return userActionService;
	}
	public ProvinceMasterService getProvinceMasterService() {
		return provinceMasterService;
	}
	CommonUtil commonUtil= new CommonUtil();
	@RequestMapping(value = "/getProvinceDetails.do")
	public ModelAndView getProvinceDetails(HttpServletRequest request) {
		logWriter.info("In /getProvinceDetails.do getProvinceDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("provinceDetails",
					provinceMasterService.getProvinceDetails());
			logWriter.info("success");
			return new ModelAndView("provinceDetails", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/viewProvinceDetails.do")
	public ModelAndView viewProvinceDetails(HttpServletRequest request,
			@RequestParam String provinceCode, @RequestParam String status) {
		logWriter.info("In /viewProvinceDetails.do viewProvinceDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("viewProvince",
					provinceMasterService.viewProvince(provinceCode, status));
			logWriter.info("success");
			return new ModelAndView("viewProvince", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/getProvinceDetailsForUpdate.do")
	public ModelAndView getProvinceDetailsForUpdate(HttpServletRequest request,
			@RequestParam String provinceCode, @RequestParam String status) {
		logWriter
				.info("In /getProvinceDetailsForUpdate.do getProvinceDetailsForUpdate");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			logWriter.info("userId is: " + session.getAttribute("userid"));
			String userId = (String) session.getAttribute("userid");
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("inputData",
					provinceMasterService.viewProvince(provinceCode, status));
			logWriter.info("success");
			return new ModelAndView("editProvince", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/getProvinceDetailsForDelete.do")
	public ModelAndView getProvinceDetailsForDelete(HttpServletRequest request,
			@RequestParam String provinceCode, @RequestParam String status) {
		logWriter
				.info("In /getProvinceDetailsForUpdate.do getProvinceDetailsForUpdate");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			logWriter.info("userId is: " + session.getAttribute("userid"));
			String userId = (String) session.getAttribute("userid");
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("inputData",
					provinceMasterService.viewProvince(provinceCode, status));
			// responseData.put("provinceList",
			// provinceMasterService.getProvinceDetails());
			logWriter.info("success");
			return new ModelAndView("deleteProvince", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/getProvinceDetailsForAuthor.do")
	public ModelAndView getProvinceDetailsForAuthoring(
			HttpServletRequest request) {
		logWriter.info("In /getProvinceDetails.do getProvinceDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			String userId = (String) session.getAttribute("userid");
			responseData.put("provinceDetails",
					provinceMasterService.getProvinceDetailsForAuthor(userId));
			logWriter.info("success");
			return new ModelAndView("provinceDetailsForAuthor", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/addProvince.do", method = RequestMethod.POST)
	public ModelAndView addProvinceDetails(HttpServletRequest request,
			@RequestParam String provinceName,
			@RequestParam String provinceCode, @RequestParam String status) {
		logWriter.info("In /addprovince.do addprovinceDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Province province = new Province();
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		int result = 0;
		province.setProvinceName(provinceName);
		province.setProvinceCode(provinceCode);
		province.setStatus(status);
		province.setMaker(userId);
		province.setActive("N");
		province.setMakerDt(new java.sql.Timestamp(new Date().getTime()));
		try {
			result = provinceMasterService.saveProvince(province, "add");
			if (result == 0) {
				logWriter.info("No rows Added");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows Added");
				// session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			} else {
				logWriter.info("province added successfully");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "province added successfully");
				// session.setAttribute("message","province added successfully");
				return new ModelAndView("success", responseData);
			}
		} catch (Exception e) {
			logWriter.error("Error: " + e.getMessage() + " Cause: "
					+ e.getCause());
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Exception while adding province");
			// session.setAttribute("error_msg","Something went wrong. Please try again later");
			return new ModelAndView("Error", responseData);
		}}else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/authorOrRejectProvince.do", method = RequestMethod.POST)
	public ModelAndView authorProvinceDetails(HttpServletRequest request,
			@RequestParam String provinceName,@RequestParam String maker, @RequestParam Timestamp makerDt,
			@RequestParam String provinceCode, @RequestParam String status,@RequestParam String flag) throws ParseException, JSONException {

		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		int result = 0;
		Province province=new Province();
		province.setProvinceName(provinceName);
		province.setProvinceCode(provinceCode);
		province.setMaker(maker);
		province.setMakerDt(makerDt);
		province.setStatus(status);
		province.setChecker(userId);
		String currentDate=CommonUtil.getDateTime(new java.util.Date().getTime(), "yyyyMMdd HH:mm:ss","EST");
		logWriter.info("currentDate"+currentDate);
		SimpleDateFormat datetimeFormatter1 = new SimpleDateFormat(
                "yyyyMMdd HH:mm:ss");
        Date lFromDate1 = datetimeFormatter1.parse(currentDate);
        System.out.println("gpsdate :" + lFromDate1);
        Timestamp fromTS1 = new Timestamp(lFromDate1.getTime());
		province.setCheckerDt(fromTS1);
		AuditLog auditLog= new AuditLog();
		auditLog.setTableName("IMCA_PROVINCE_DETAILS_NEW");
		String obj=commonUtil.convertToJson(province);
        auditLog.setRequest(obj);
		auditLog.setMakerCd(maker);
		auditLog.setMakerDt(makerDt);
		auditLog.setAuthorCd(userId);
		auditLog.setAuthorDt(fromTS1);
		if (flag.equals("1")) {
			logWriter.info("In /authorProvince.do authorProvincedetails");
			
			try {
				result = provinceMasterService.authorProvince(province);
				auditLog.setOperation("Province authorized");
				userActionService.updateAuditLog(auditLog);
				if (result == 0) {
					logWriter.info("No rows Added");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "No rows Added");
					// session.setAttribute("message","No rows updated");
					return new ModelAndView("success", responseData);
				} else {
					logWriter.info("province authored successfully");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "province authored successfully");
					// session.setAttribute("message","province added successfully");
					return new ModelAndView("success", responseData);
				}
			} catch (Exception e) {
				logWriter.error("Error: " + e.getMessage() + " Cause: "
						+ e.getCause());
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Exception while adding province");
				// session.setAttribute("error_msg","Something went wrong. Please try again later");
				return new ModelAndView("Error", responseData);
			}} else if (flag.equals("2")) {
			try {
				//result = provinceMasterService.saveProvince(province, "Reject");
				result = provinceMasterService.rejectProvince(province);
				auditLog.setOperation("Province rejected");
				userActionService.updateAuditLog(auditLog);
				if (result == 0) {
					logWriter.info("No rows Added");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "No rows Added");
					return new ModelAndView("success", responseData);
				} else {
					logWriter.info("province rejected successfully");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "province rejected successfully");
					return new ModelAndView("success", responseData);
				}
			} catch (Exception e) {
				logWriter.error("Error: " + e.getMessage() + " Cause: "
						+ e.getCause());
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Exception while rejecting province");
				return new ModelAndView("success", responseData);
			}
		}
		responseData = new HashMap<String, Object>();
		responseData.put("message", "No rows Added");
		return new ModelAndView("success", responseData);
		}else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/updateProvince.do", method = RequestMethod.POST)
	public ModelAndView updateProvinceDetails(HttpServletRequest request,
			@RequestParam String provinceName,
			@RequestParam String provinceCode, @RequestParam String status,  @RequestParam String active) {
		logWriter.info("In /updateprovince.do updateprovinceDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Province province = new Province();
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		int result = 0;
		province.setProvinceName(provinceName);
		province.setProvinceCode(provinceCode);
		province.setStatus(status);
		province.setMaker(userId);
		province.setActive(active);
		province.setMakerDt(new java.sql.Timestamp(new Date().getTime()));
		try {
			result=provinceMasterService.saveProvince(province,"Modified");
			if (result == 0) {
				logWriter.info("No rows updated");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows updated");
				// session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			} else {
				logWriter.info("province updated successfully");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "province updated successfully");
				// session.setAttribute("message","province added successfully");
				return new ModelAndView("success", responseData);
			}
		} catch (Exception e) {
			logWriter.error("Error: " + e.getMessage() + " Cause: "
					+ e.getCause());
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Exception while updating province");
			// session.setAttribute("error_msg","Something went wrong. Please try again later");
			return new ModelAndView("Error", responseData);
		}}else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/deleteProvince.do", method = RequestMethod.GET)
	public ModelAndView deleteProvinceDetails(HttpServletRequest request,
			@RequestParam String provinceName,
			@RequestParam String provinceCode, @RequestParam String status,@RequestParam String active) {
		logWriter.info("In /deleteprovince.do deleteprovinceDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Province province = new Province();
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		int result = 0;
		province.setProvinceName(provinceName);
		province.setProvinceCode(provinceCode);
		province.setStatus(status);
		province.setMaker(userId);
		province.setActive(active);
		province.setMakerDt(new java.sql.Timestamp(new Date().getTime()));
		try {
			result=provinceMasterService.saveProvince(province,"delete");
			if (result == 0) {
				logWriter.info("No rows deleted");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows deleted");
				// session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			} else {
				logWriter.info("province deleted successfully");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "province deleted successfully");
				// session.setAttribute("message","province added successfully");
				return new ModelAndView("success", responseData);
			}
		} catch (Exception e) {
			logWriter.error("Error: " + e.getMessage() + " Cause: "
					+ e.getCause());
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Exception while deleting province");
			// session.setAttribute("error_msg","Something went wrong. Please try again later");
			return new ModelAndView("Error", responseData);
		}}else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/searchProvince.do", method = RequestMethod.GET)
	public ModelAndView searchProvinceDetails(HttpServletRequest request,
			@RequestParam String provinceName,
			@RequestParam String provinceCode, @RequestParam String status) {
		logWriter.info("In /searchprovince.do searchprovinceDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Province province = new Province();
		Map<String, Object> responseData = null;
		// String userId=(String) session.getAttribute("userid");
		province.setProvinceName(provinceName);
		province.setStatus(status);
		province.setProvinceCode(provinceCode);
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("provinceDetails",
					provinceMasterService.searchProvince(province));
			logWriter.info("success");
			return new ModelAndView("provinceDetails", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/searchProvinceForAuthor.do", method = RequestMethod.GET)
	public ModelAndView searchProvinceDetailsForAuthor(
			HttpServletRequest request, @RequestParam String provinceName,
			@RequestParam String provinceCode, @RequestParam String status) {
		logWriter
				.info("In /searchProvinceForAuthor.do searchProvinceForAuthor");
		HttpSession session = null;
		session = request.getSession(false);
		Province province = new Province();
		Map<String, Object> responseData = null;
		province.setProvinceName(provinceName);
		province.setStatus(status);
		province.setProvinceCode(provinceCode);
		if(session!=null && session.getAttribute("userid") != null){
			String userId = (String) session.getAttribute("userid");
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			List<Province> list = provinceMasterService
					.searchProvince(province);
			List<Province> list2 = new ArrayList<Province>(list);
			for (Province item : list2) {
				if (item.getMaker().equals(userId)
						|| item.getStatus().equals("Authorized")
						|| item.getStatus().equals("Rejected"))
					list.remove(item);
			}
			responseData.put("provinceDetails", list);
			logWriter.info("success");
			return new ModelAndView("provinceDetailsForAuthor", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/rejectProvince.do", method = RequestMethod.GET)
	public ModelAndView rejectProvinceDetails(HttpServletRequest request,
			@RequestParam String provinceCode,
			@RequestParam String provinceName, @RequestParam String status,
			@RequestParam String maker, @RequestParam Timestamp makerDt) {
		logWriter.info("In /rejectProvince.do rejectProvince");
		HttpSession session = null;
		session = request.getSession(false);
		Province ProvinceItem = new Province();
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		int result = 0;
		ProvinceItem.setProvinceCode(provinceCode);
		ProvinceItem.setProvinceName(provinceName);
		// ProvinceItem.setReason(reason);
		ProvinceItem.setStatus(status);
		ProvinceItem.setMaker(maker);
		ProvinceItem.setMakerDt(makerDt);
		ProvinceItem.setChecker(userId);
		ProvinceItem.setCheckerDt(new java.sql.Timestamp(new Date().getTime()));
		try {
			result = provinceMasterService.saveProvince(ProvinceItem, "Reject");
			if (result == 0) {
				logWriter.info("No rows Added");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows Added");
				return new ModelAndView("success", responseData);
			} else {
				logWriter.info("Province rejected successfully");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Province rejected successfully");
				return new ModelAndView("success", responseData);
			}
		} catch (Exception e) {
			logWriter.error("Error: " + e.getMessage() + " Cause: "
					+ e.getCause());
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Exception while rejecting Province");
			return new ModelAndView("Error", responseData);
		}} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}
}
