package com.icicibank.iMobileCA.controller;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.icicibank.iMobileCA.model.AuditLog;
import com.icicibank.iMobileCA.model.Scheme;
import com.icicibank.iMobileCA.service.SchemeMasterService;
import com.icicibank.iMobileCA.service.UserActionService;
import com.icicibank.iMobileCA.util.CommonUtil;

@Controller
public class SchemeMasterController {

	private static final Logger logWriter = Logger
			.getLogger(SchemeMasterController.class.getName());
	private HttpSession session;

	@Autowired
	private SchemeMasterService schemeMasterService;
	@Autowired
	private UserActionService userActionService;

	public UserActionService getUserActionService() {
		return userActionService;
	}
	public SchemeMasterService getSchemeMasterService() {
		return schemeMasterService;
	}
	CommonUtil commonUtil= new CommonUtil();
	@RequestMapping(value = "/getSchemeDetails.do")
	public ModelAndView getSchemeDetails(HttpServletRequest request) {
		logWriter.info("In /getSchemeDetails.do getSchemeDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("schemeDetails",
					schemeMasterService.getSchemeDetails());
			logWriter.info("success");
			return new ModelAndView("schemeDetails", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/viewSchemeDetails.do")
	public ModelAndView viewSchemeDetails(HttpServletRequest request,
			@RequestParam String schemeCode, @RequestParam String status) {
		logWriter.info("In /viewSchemeDetails.do viewSchemeDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("viewScheme",
					schemeMasterService.viewScheme(schemeCode, status));
			logWriter.info("success");
			return new ModelAndView("viewScheme", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired..authorFailure Please Login Again");
			return new ModelAndView("Error", responseData);
		}
	}

	@RequestMapping(value = "/getSchemeDetailsForUpdate.do")
	public ModelAndView updateSchemeDetails(HttpServletRequest request,
			@RequestParam String schemeCode, @RequestParam String status) {
		logWriter
				.info("In /getSchemeDetailsForUpdate.do getSchemeDetailsForUpdate");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("updateSchemeDetails",
					schemeMasterService.viewScheme(schemeCode, status));
			logWriter.info("success");
			return new ModelAndView("updateSchemeDetails", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/getSchemeDetailsForAuthor.do")
	public ModelAndView getSchemeDetailsForAuthoring(HttpServletRequest request) {
		logWriter
				.info("In /getSchemeDetailsForAuthor.do getSchemeDetailsForAuthor");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			String userId = (String) session.getAttribute("userid");
			responseData.put("schemeDetailsForAuthor",
					schemeMasterService.getSchemeDetailsForAuthor(userId));
			logWriter.info("success");
			return new ModelAndView("schemeDetailsForAuthor", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/addScheme.do", method = RequestMethod.POST)
	public ModelAndView addMenuDetails(HttpServletRequest request,
			@RequestParam String schemeCode, @RequestParam String schemeName,
			@RequestParam String description, @RequestParam String accType,
			@RequestParam String schemeType) {
		logWriter.info("In /addScheme.do addSchemeDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		int result = 0;
		Scheme scheme = new Scheme();
		scheme.setAccType(accType);
		scheme.setDescription(description);
		scheme.setSchemeName(schemeName);
		scheme.setSchemeCode(schemeCode);
		scheme.setStatus("New");
		scheme.setActive("N");
		scheme.setSchemeType(schemeType);
		scheme.setMaker(userId.toUpperCase());
		scheme.setMakerDt(new java.sql.Timestamp(new Date().getTime()));
		try {
			result = schemeMasterService.saveScheme(scheme, "add");
			if (result == 0) {
				logWriter.info("No rows Added");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows Added");
				// session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			} else if (result == 2) {
				logWriter.info("No rows Added....Duplicate Code");
				responseData = new HashMap<String, Object>();
				responseData
						.put("message",
								"Scheme with same Code already exists, duplicate cannot be created");
				// session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			}/*
			 * else if (result == 3) {
			 * logWriter.info("No rows Added....Duplicate Name"); responseData =
			 * new HashMap<String, Object>(); responseData .put("message",
			 * "Scheme with same Name already exists, duplicate cannot be created"
			 * ); // session.setAttribute("message","No rows updated"); return
			 * new ModelAndView("success", responseData); }
			 */else {
				logWriter.info("Scheme added successfully");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Scheme added successfully");
				// session.setAttribute("message","branch added successfully");
				return new ModelAndView("success", responseData);
			}
		} catch (Exception e) {
			logWriter.error("Error: " + e.getMessage() + " Cause: "
					+ e.getCause());
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Exception while adding Scheme");
			// session.setAttribute("error_msg","Something went wrong. Please try again later");
			return new ModelAndView("Error", responseData);
		}} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/authorOrRejectScheme.do", method = RequestMethod.GET)
	public ModelAndView authorMenuDetails(HttpServletRequest request,
			@RequestParam String schemeCode, @RequestParam String schemeType,
			@RequestParam String schemeName, @RequestParam String maker,
			@RequestParam Timestamp makerDt, @RequestParam String status,
			@RequestParam String flag,@RequestParam String active,@RequestParam String description,@RequestParam String accType) throws ParseException{
		logWriter.info("In /authorScheme.do authorScheme");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		Scheme scheme = new Scheme();
		scheme.setSchemeName(schemeName);
		scheme.setSchemeCode(schemeCode);
		scheme.setStatus(status);
		scheme.setSchemeType(schemeType);
		scheme.setMaker(maker);
		scheme.setActive("Y");
		scheme.setMakerDt(makerDt);
		scheme.setChecker(userId);
		scheme.setDescription(description);
		scheme.setAccType(accType);
		
		String currentDate = CommonUtil.getDateTime(
				new java.util.Date().getTime(), "yyyyMMdd HH:mm:ss", "EST");
		logWriter.info("currentDate" + currentDate);
		SimpleDateFormat datetimeFormatter1 = new SimpleDateFormat(
				"yyyyMMdd HH:mm:ss");
		Date lFromDate1 = datetimeFormatter1.parse(currentDate);
		System.out.println("gpsdate :" + lFromDate1);
		Timestamp fromTS1 = new Timestamp(lFromDate1.getTime());
		scheme.setCheckerDt(fromTS1);
		AuditLog auditLog= new AuditLog();
		auditLog.setTableName("IMCA_SCHEME_DETAILS");
		String obj=commonUtil.convertToJson(scheme);
		auditLog.setRequest(obj);
		auditLog.setMakerCd(maker);
		auditLog.setMakerDt(makerDt);
		auditLog.setAuthorCd(userId);
		auditLog.setAuthorDt(fromTS1);
		if (flag.equals("1")) {
			int result = 0;
			try {
				result = schemeMasterService.authorScheme(scheme);
				auditLog.setOperation("scheme authorized");
				userActionService.updateAuditLog(auditLog);
				if (result == 0) {
					logWriter.info("No rows Added");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "No rows Added");
					return new ModelAndView("success", responseData);
				} else {
					logWriter.info("Scheme authored successfully");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "Scheme authored successfully");
					return new ModelAndView("success", responseData);
				}
			} catch (Exception e) {
				logWriter.error("Error: " + e.getMessage() + " Cause: "
						+ e.getCause());
				responseData = new HashMap<String, Object>();
				responseData.put("message",
						"Exception while authoririzing Scheme");
				return new ModelAndView("Error", responseData);
			}
		} else if (flag.equals("2")) {
			int result = 0;
			
			try {
				//result = schemeMasterService.saveScheme(scheme, "Reject");
				result = schemeMasterService.rejectScheme(scheme);
				auditLog.setOperation("scheme Rejected");
				userActionService.updateAuditLog(auditLog);
				if (result == 0) {
					logWriter.info("No rows Added");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "No rows Added");
					return new ModelAndView("success", responseData);
				} else {
					logWriter.info("Scheme rejected successfully");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "Scheme rejected successfully");
					return new ModelAndView("success", responseData);
				}
			} catch (Exception e) {
				logWriter.error("Error: " + e.getMessage() + " Cause: "
						+ e.getCause());
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Exception while rejecting Scheme");
				return new ModelAndView("error", responseData);
			}
		}
		responseData = new HashMap<String, Object>();
		responseData.put("message", "No rows Added");
		return new ModelAndView("success", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	/*
	 * @RequestMapping(value = "/rejectScheme.do", method = RequestMethod.GET)
	 * public ModelAndView rejectMenuDetails(HttpServletRequest request,
	 * 
	 * @RequestParam String schemeCode, @RequestParam String schemeType,
	 * 
	 * @RequestParam String schemeName, @RequestParam String maker,
	 * 
	 * @RequestParam Timestamp makerDt, @RequestParam String status) {
	 * 
	 * 
	 * }
	 */

	@RequestMapping(value = "/updateScheme.do", method = RequestMethod.POST)
	public ModelAndView updateMenuDetails(HttpServletRequest request,
			@RequestParam String schemeName, @RequestParam String schemeCode,
			@RequestParam String accType, @RequestParam String description,
			@RequestParam String schemeType, @RequestParam String status) {
		logWriter.info("In /updateScheme.do updateScheme");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		int result = 0;
		Scheme scheme = new Scheme();
		scheme.setAccType(accType);
		scheme.setDescription(description);
		scheme.setSchemeName(schemeName);
		scheme.setSchemeCode(schemeCode);
		scheme.setStatus(status);
		scheme.setActive("N");
		scheme.setSchemeType(schemeType);
		scheme.setMaker(userId);
		scheme.setMakerDt(new java.sql.Timestamp(new Date().getTime()));
		try {
			result = schemeMasterService.saveScheme(scheme, "Modified");
			if (result == 0) {
				logWriter.info("No rows updated");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows updated");
				// session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			} else {
				logWriter.info("Scheme updated successfully");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Scheme updated successfully");
				// session.setAttribute("message","branch added successfully");
				return new ModelAndView("success", responseData);
			}
		} catch (Exception e) {
			logWriter.error("Error: " + e.getMessage() + " Cause: "
					+ e.getCause());
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Exception while updating Scheme");
			// session.setAttribute("error_msg","Something went wrong. Please try again later");
			return new ModelAndView("Error", responseData);
		}} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/deleteScheme.do", method = RequestMethod.GET)
	public ModelAndView deleteMenuDetails(HttpServletRequest request,
			@RequestParam String schemeCode, @RequestParam String schemeName,
			@RequestParam String description, @RequestParam String accType,
			@RequestParam String schemeType, @RequestParam String status) {
		logWriter.info("In /deleteScheme.do deleteScheme");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		int result = 0;
		Scheme scheme = new Scheme();
		scheme.setAccType(accType);
		scheme.setDescription(description);
		scheme.setActive("N");
		scheme.setSchemeName(schemeName);
		scheme.setSchemeCode(schemeCode);
		scheme.setStatus(status);
		scheme.setSchemeType(schemeType);
		scheme.setMaker(userId);
		scheme.setMakerDt(new java.sql.Timestamp(new Date().getTime()));
		try {
			result = schemeMasterService.saveScheme(scheme, "delete");
			if (result == 0) {
				logWriter.info("No rows deleted");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows deleted");
				// session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			} else {
				logWriter.info("Scheme deleted successfully");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Scheme deleted successfully");
				// session.setAttribute("message","branch added successfully");
				return new ModelAndView("success", responseData);
			}
		} catch (Exception e) {
			logWriter.error("Error: " + e.getMessage() + " Cause: "
					+ e.getCause());
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Exception while deleting Scheme");
			// session.setAttribute("error_msg","Something went wrong. Please try again later");
			return new ModelAndView("Error", responseData);
		}} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/searchScheme.do", method = RequestMethod.GET)
	public ModelAndView searchMenuDetails(HttpServletRequest request,
			@RequestParam("schemeCode") String schemeCode,
			@RequestParam("schemeType") String schemeType,
			@RequestParam("status") String status) {
		logWriter.info("In /searchScheme.do searchScheme");
		HttpSession session = null;
		session = request.getSession(false);
		Scheme scheme = new Scheme();
		Map<String, Object> responseData = null;
		scheme.setSchemeType(schemeType);
		scheme.setSchemeCode(schemeCode);
		scheme.setStatus(status);
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("schemeDetails",
					schemeMasterService.searchScheme(scheme));
			logWriter.info("success");
			return new ModelAndView("schemeDetails", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/searchSchemeForAuthor.do", method = RequestMethod.GET)
	public ModelAndView searchMenuDetailsForAuthor(HttpServletRequest request,
			@RequestParam("schemeCode") String schemeCode,
			@RequestParam("schemeType") String schemeType,
			@RequestParam("status") String status) {
		logWriter.info("In /searchSchemeForAuthor.do searchSchemeForAuthor");
		HttpSession session = null;
		session = request.getSession(false);
		Scheme scheme = new Scheme();
		Map<String, Object> responseData = null;
		scheme.setSchemeType(schemeType);
		scheme.setSchemeCode(schemeCode);
		scheme.setStatus(status);
		if(session!=null && session.getAttribute("userid") != null){
		String userId = (String) session.getAttribute("userid");
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			List<Scheme> list = schemeMasterService.searchScheme(scheme);
			List<Scheme> list2 = new ArrayList<Scheme>(list);
			for (Scheme item : list2) {
				if (item.getMaker().equals(userId)
						|| item.getStatus().equals("Rejected")
						|| item.getStatus().equals("Authorized")
						|| item.getStatus().equals("Deleted and Authorized"))
					list.remove(item);
			}
			responseData.put("schemeDetailsForAuthor", list);
			logWriter.info("success");
			return new ModelAndView("schemeDetailsForAuthor", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

}
