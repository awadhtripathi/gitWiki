package com.icicibank.iMobileCA.controller;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.rmi.ServerException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.icicibank.iMobileCA.model.Attempts;
import com.icicibank.iMobileCA.model.AuditLog;
import com.icicibank.iMobileCA.model.EchequeDepositBean;
import com.icicibank.iMobileCA.model.ExchangeATMs;
import com.icicibank.iMobileCA.model.Limits;
import com.icicibank.iMobileCA.service.UserActionService;
import com.icicibank.iMobileCA.util.ADAuthentication;
import com.icicibank.iMobileCA.util.CSVUtils;
import com.icicibank.iMobileCA.util.CommonUtil;


@RestController
// @SuppressWarnings("all")
public class UserActionController {
	private static final Logger logWriter = Logger
			.getLogger(UserActionController.class.getName());
	private HttpSession session;
	
	@Autowired
	private UserActionService userActionService;

	
	public UserActionService getUserActionService() {
		return userActionService;
	}
	CommonUtil commonUtil= new CommonUtil();
	    @RequestMapping(value="/login.do") 
	    public ModelAndView executeLogin(HttpServletRequest request, @RequestParam String userId, @RequestParam String password) 
	    { 
	    	String response = "";
	        //boolean isValidUser = false; 
	        //Map<String,Object> modelMap = new HashMap<String,Object>(4);
	        session = request.getSession();
	        try{ 
	        	if(userId != null && !password.isEmpty()){
	                
	        		ADAuthentication auth = new ADAuthentication();
	        		Hashtable hashtable=auth .checkUserCredentials(userId+"",password, "ICICIBANKLTD");
					//isValidUser = auth .checkUserCredentials(userId+"",password, "ICICIBANKLTD");
	               //isValidUser = true; 
	        		logWriter.info("hashtable"+hashtable);
	        		logWriter.info("displayName :"+hashtable.get("givenName"));
	        		session.setAttribute("userName", hashtable.get("givenName"));
	        		session.setAttribute("physicalDeliveryOfficeName", hashtable.get("physicalDeliveryOfficeName"));
	        		session.setAttribute("userid", userId.toUpperCase());
	                if(!hashtable.isEmpty()) 
	                { 
	                	logWriter.info("User Login Successful with LDAP"); 
	                	try{
	             //   	String LastLogin=userActionService.getLastLogin(userId);     //2017-01-10 05:50:00.0
	                		//logWriter.info("User Login : "+userActionService.getLastLogin(userId)); 
	                		String login=userActionService.getLastLogin(userId.toUpperCase());
	                		logWriter.info("User Login : "+login); 
	                	//session.setAttribute("userid", userId);
	                	/*java.util.Date utilDate = new java.util.Date();
                		Calendar cal = Calendar.getInstance();
                		cal.setTime(utilDate);
                		cal.set(Calendar.MILLISECOND, 0);
                		Timestamp currentTime = new java.sql.Timestamp(utilDate.getTime());
                		logWriter.info("currentTime"+currentTime);*/
                		String currentDate=CommonUtil.getDateTime(new java.util.Date().getTime(), "yyyyMMdd HH:mm","EST");
                		logWriter.info("currentDate"+currentDate);
                		SimpleDateFormat datetimeFormatter1 = new SimpleDateFormat(
                                "yyyyMMdd HH:mm");
		                Date lFromDate1 = datetimeFormatter1.parse(currentDate);
		                System.out.println("gpsdate :" + lFromDate1);
		                Timestamp fromTS1 = new Timestamp(lFromDate1.getTime());
		                logWriter.info("fromTS1"+fromTS1);
                		//Timestamp ts = Timestamp.valueOf(currentDate);
                		//Timestamp currentTime = new java.sql.Timestamp(utilDate.getTime());
                		if(login!=null){
                			String LastLogin=CommonUtil.getDateTime(CommonUtil.getDateTime(userActionService.getLastLogin(userId.toUpperCase()), "yyyy-MM-dd HH:mm:ss.S"),"yyyyMMdd HH:mm");
	                		session.setAttribute("LastLogin", LastLogin);
	                		session.setAttribute("currentLogin", currentDate);
	                	} else{
	                		session.setAttribute("LastLogin",fromTS1);
	                		session.setAttribute("currentLogin", fromTS1);
	                	}
                		//userActionService.updateLastLogin(userId,password,currentTime);
	                	userActionService.updateLastLogin(userId.toUpperCase(),null,fromTS1);
	                	response = "dashboard";
                		}catch(EmptyResultDataAccessException e){
                			logWriter.error("Error Msg: "+e.getMessage()+" -- Cause : "+e.getCause()); 
                			session.setAttribute("error_msg","No records updated");
	                        response = "Error";
                		}catch(Exception e){
                			logWriter.error("Error Msg: "+e.getMessage()+" -- Cause : "+e.getCause()); 
            	            session.setAttribute("error_msg","LDAP Authentication Failure");
            	            response = "Error";
                		}
	                } 
	                else 
	                { 
	                	logWriter.error("error_msg LDAP Authentication Failure");
	                	session.setAttribute("error_msg","LDAP Authentication Failure");
	                    response = "Error";
	                } 
	          }else{
	        	  logWriter.error("UserID and password can not be empty");
	        	  session.setAttribute("error_msg","UserID and password can not be empty");
	              response = "Error";
	          }
	        }catch(Exception ie){ 
	            logWriter.error("Error Msg: "+ie.getMessage()+" -- Cause : "+ie.getCause()); 
	            session.setAttribute("error_msg","LDAP Authentication Failure");
	            response = "Error";
	        }
	        return new ModelAndView(response); 
	    }
	
	@RequestMapping(value = "/logout.do", method = RequestMethod.GET)
	public ModelAndView executeLogout(HttpServletRequest request) {
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = new HashMap<String, Object>();
		if(session!=null){
		session.invalidate();
		logWriter.info("Session Invalidated...");
		
		responseData.put("message", "User Successfully Loggedout...");
		return new ModelAndView("loginpage", responseData);}
		else{
			logWriter.info("Session Expired...");
			responseData.put("error_msg", "You have successfully logged out");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/getFieldsDetails.do")
	public ModelAndView getFieldsDetails(HttpServletRequest request) {
		logWriter.info("In /AddFieldsDetails.do getFieldsDetails");
		HttpSession session = null;
		session = request.getSession(false);
		logWriter.info("session"+session);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName",session.getAttribute("user"));
			responseData.put("AddFieldsData", userActionService.getFieldsData());
			logWriter.info("success");
			return new ModelAndView("addField", responseData);
		}else{
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			//session.setAttribute("error_msg","Session Expired... Please Login Again");
			responseData.put("error_msg", "Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}
	/*--------Not using as of now getting static zone values------------*/
	/*@RequestMapping(value = "/getZoneDetails.do")
	public ModelAndView getZoneDetails(HttpServletRequest request) {
		logWriter.info("In /getZoneDetails.do getZoneDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName",session.getAttribute("user"));
			responseData.put("zoneData", userActionService.getZoneData());
			logWriter.info("success");
			return new ModelAndView("showZones", responseData);
		}else{
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			//session.setAttribute("error_msg","Session Expired... Please Login Again");
			responseData.put("error_msg", "Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}*/
	/*--------Not using as of now getting static zone values------------*/
	@RequestMapping(value = "/getZoneDetailsForSearch.do")
	public ModelAndView getZoneDetailsForSearch(HttpServletRequest request) {
		logWriter.info("In /getZoneDetails.do getZoneDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName",session.getAttribute("user"));
			responseData.put("zoneData", userActionService.getZoneData());
			logWriter.info("success");
			return new ModelAndView("searchZones", responseData);
		}else{
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			//session.setAttribute("error_msg","Session Expired... Please Login Again");
			responseData.put("error_msg", "Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}
	@RequestMapping(value = "/getFieldsDetailsForAuthor.do")
	public ModelAndView getFieldsDetailsForAuthor(HttpServletRequest request) {
		logWriter.info("In /AddFieldsDetails.do getFieldsDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		responseData = new HashMap<String, Object>();
		if(session!=null && session.getAttribute("userid") != null){
			String userId=(String) session.getAttribute("userid");
			List<Limits> details=userActionService.getAuthoringField(userId);
			
			if(!details.isEmpty()){
				logWriter.info("Success");
				responseData.put("message", "Success");
				responseData.put("AddFieldsData", details);
				logWriter.info("success");
				return new ModelAndView("authorFields", responseData);
			}
			else{
				logWriter.error("No fields to author");
				responseData.put("message", "No fields to author");
				//session.setAttribute("error_msg","No fields to author");
				logWriter.info("success");
				return new ModelAndView("success", responseData);
			}
		}
		else{
			logWriter.error("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg", "Session Expired... Please Login Again");
			//session.setAttribute("error_msg","Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}
	
	@RequestMapping(value = "/addLimit.do",method = RequestMethod.POST)
	public ModelAndView addLimits(HttpServletRequest request,@RequestBody HashMap<String,String> detailsObj) throws IllegalAccessException, InvocationTargetException, ParseException {
		logWriter.info("In /addLimit.do addLimits");
		logWriter.info("detailsObj size is"+detailsObj.size());
		HttpSession session = null;
		session = request.getSession(false);
		List<Limits> list=new ArrayList<Limits>();
		List<AuditLog> auditlist=new ArrayList<AuditLog>();
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: "+session.getAttribute("userid"));
		String userId=(String) session.getAttribute("userid");
		String currentDate=CommonUtil.getDateTime(new java.util.Date().getTime(), "yyyyMMdd HH:mm:ss","EST");
		logWriter.info("currentDate"+currentDate);
		SimpleDateFormat datetimeFormatter1 = new SimpleDateFormat(
                "yyyyMMdd HH:mm:ss");
        Date lFromDate1 = datetimeFormatter1.parse(currentDate);
        System.out.println("gpsdate :" + lFromDate1);
        Timestamp fromTS1 = new Timestamp(lFromDate1.getTime());
		int result=0;
		for (Map.Entry<String, String> entry : detailsObj.entrySet()) {
			Limits limits = new Limits();
			limits.setLimitType(entry.getKey());
			limits.setChangedValue(entry.getValue());
			limits.setMaker(userId);
			limits.setAuthoringStatus("N");
			limits.setMakerDt(fromTS1);
			logWriter.info(entry.getKey() + "/" + entry.getValue());
			list.add(limits);
		}
		try {
			if(!list.isEmpty()){
				result=userActionService.updateFields(list);
			 //  userActionService.updateAuditLog(auditlist);
			if(result==0){
				logWriter.info("No rows to update");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows to update");
				session.setAttribute("message","No rows to update");
				return new ModelAndView("success", responseData);
			}
			else {
				logWriter.info("Limits added successfully");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Limits added successfully");
				session.setAttribute("message","Limits added successfully");
				return new ModelAndView("success", responseData);
			}
			} else {
				logWriter.info("No rows to update");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows to update");
				session.setAttribute("message","No rows to update");
				return new ModelAndView("success", responseData);
			}
		}
		catch (Exception e) {
			logWriter.error("Error: "+e.getMessage()+" Cause: "+e.getCause());
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Something went wrong. Please try again later");
			responseData.put("status", "failure");
			//session.setAttribute("error_msg","Something went wrong. Please try again later");
			return new ModelAndView("error", responseData);
		}}
		else{
			logWriter.error("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg", "Session Expired... Please Login Again");
			//session.setAttribute("error_msg","Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}
	
	@RequestMapping(value = "/authorFields.do",method = RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ModelAndView authorFieldDetails(HttpServletRequest request,@RequestBody HashMap<String,String> detailsSelectObj) throws IllegalAccessException, InvocationTargetException, ParseException {
		logWriter.info("In /addFields.do addFieldDetails");
		HttpSession session = null;
		session = request.getSession(false);
		int result=0;
		List<Limits> list=new ArrayList<Limits>();
		List<AuditLog> auditlist=new ArrayList<AuditLog>();
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: "+session.getAttribute("userid"));
		String userId=(String) session.getAttribute("userid");
		String currentDate=CommonUtil.getDateTime(new java.util.Date().getTime(), "yyyyMMdd HH:mm:ss","EST");
		logWriter.info("currentDate"+currentDate);
		SimpleDateFormat datetimeFormatter1 = new SimpleDateFormat(
                "yyyyMMdd HH:mm:ss");
        Date lFromDate1 = datetimeFormatter1.parse(currentDate);
        System.out.println("gpsdate :" + lFromDate1);
        Timestamp fromTS1 = new Timestamp(lFromDate1.getTime());
		for (Map.Entry<String, String> entry : detailsSelectObj.entrySet()) {
			String fullValue=entry.getValue();
			String changedVal = fullValue.split("#")[1];
			String value = fullValue.split("#")[0];
			if(value.equals("Y")){
			Limits limits = new Limits();
			limits.setLimitType(entry.getKey());
			limits.setAuthoringStatus(value);
			limits.setChangedValue(changedVal);
			limits.setChecker(userId);
			limits.setCheckerDt(fromTS1);
			logWriter.info(entry.getKey() + "/" + entry.getValue());
			list.add(limits);
			/*AuditLog auditLog= new AuditLog();
			auditLog.setTableName("IMCA_TRANSATION_RANGE");
			auditLog.setColumnName(entry.getKey());
			auditLog.setNewValue(entry.getValue());
			auditLog.setUserId(userId);
			auditLog.setUserDt(fromTS1);
			auditLog.setAuthStatus("ADDLIMIT");
			auditlist.add(auditLog);*/
			}
			AuditLog auditLog= new AuditLog();
			auditLog.setTableName("IMCA_TRANSATION_RANGE");
			String obj=commonUtil.convertToJson(detailsSelectObj);
			auditLog.setRequest(obj);
			//auditLog.setMakerCd(maker);
			//auditLog.setMakerDt(makerDt);
			auditLog.setAuthorCd(userId);
			auditLog.setAuthorDt(fromTS1);
		}
		try {
			if(!list.isEmpty()){
				result=userActionService.authorFields(list);
				userActionService.authorLimits(list);
				//userActionService.updateAuditLog(auditlist);
			/*for(int i=0;i<list.size();i++){
				result=userActionService.authorFields(list.get(i));
				userActionService.authorFields1(list.get(i));
				 userActionService.updateAuditLog(auditlist);
				}*/
				if(result==0){
					logWriter.info("No rows to update");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "No rows to update");
					session.setAttribute("message","No rows to update");
					return new ModelAndView("success", responseData);
				}
				else {
					logWriter.info("Limits authorized successfully");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "Limits authorized successfully");
					session.setAttribute("message","Limits authorized successfully");
					return new ModelAndView("success", responseData);
				}
				} else {
					logWriter.info("No rows to update");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "No rows to update");
					session.setAttribute("message","No rows to update");
					return new ModelAndView("success", responseData);
				}
			}
		catch (Exception e) {
			logWriter.error("Error: "+e.getMessage()+" Cause: "+e.getCause());
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Something went wrong. Please try again later");
			session.setAttribute("error_msg","Something went wrong. Please try again later");
			return new ModelAndView("error", responseData);
		}}else{
			logWriter.error("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg", "Session Expired... Please Login Again");
			//session.setAttribute("error_msg","Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}
	/*--------------------------CI Report Generation for all zones------------------------------*/
	@RequestMapping(value = "/generateReport.do")
	public void generateReport(HttpServletRequest request,HttpServletResponse response) throws Exception{
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		try {
			logWriter.info("in getEchequeDeposit ---------" );
			Date end=null;Date start=null;
			List<List<EchequeDepositBean>> echequelist=null;	
			String cutOffTime=userActionService.getCuttOffTime();
			if(!cutOffTime.isEmpty()){
				String hour = cutOffTime.split(":")[0];
				String min = cutOffTime.split(":")[1];
				TimeZone tz = TimeZone.getTimeZone("EST");
				Calendar calendar = Calendar.getInstance(tz);
				calendar.setTimeZone(TimeZone.getTimeZone("EST"));
				calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hour));
				calendar.set(Calendar.MINUTE, Integer.parseInt(min));
				calendar.set(Calendar.SECOND,0);
				calendar.set(Calendar.MILLISECOND,0);
				 end = calendar.getTime();
				System.out.println("date is: "+end);
				 start = DateUtils.addDays(end, -1);
				 System.out.println("date in EST : "+CommonUtil.getDateTime(CommonUtil.getTimeZoneDateTime(),"dd/MM/yyyy HH:mm:ss"));
				 System.out.println("date in EST : "+CommonUtil.getDateTime(end.getTime(),"dd/MM/yyyy HH:mm:ss"));
				
			} else{
				 end = DateUtils.truncate(new Date(), Calendar.DAY_OF_MONTH);
				 start = DateUtils.addDays(end, -1);
			}
			//echequelist= userActionService.generateRequestPacket(new java.sql.Timestamp(start.getTime()),new java.sql.Timestamp(end.getTime()));
			echequelist= userActionService.generateRequestPacket(new java.sql.Timestamp(end.getTime()));
			logWriter.info("echequelist is"+echequelist.toArray());
			if(!echequelist.isEmpty()){
				try{
			//		userActionService.getEchequeDepositRequestPacket(request,response,echequelist);
					userActionService.getEchequeDepositRequestPacketFull(request,response,echequelist);
					logWriter.info("Report generated successfully");
					responseData = new HashMap<String, Object>();
					request.setAttribute("message", "Report generated successfully");
					session.setAttribute("message","Report generated successfully");
				}catch(Exception e){
					logWriter.error("exception is:"+e);
					logWriter.error("Error creating Report: "+e);
					request.setAttribute("message", "Error creating Report");
					session.setAttribute("error_msg","Error creating Report");
					response.sendRedirect("authorFailure.jsp");
					throw new ServerException("Error generating direct verification response", e);
				}
			}
			else{
				logWriter.info("There are no cheques to generate Report");
				request.setAttribute("message", "There are no cheques to generate Report");
				session.setAttribute("message","There are no cheques to generate Report");
				response.sendRedirect("success.jsp");
			}
		} catch (ParserConfigurationException pce) {
			logWriter.error("ParserConfigurationException creating Report");
			pce.printStackTrace();
			session.setAttribute("error_msg","ParserConfigurationException creating Report");
			response.sendRedirect("authorFailure.jsp");
		} catch (TransformerException tfe) {
			logWriter.error("TransformerException creating Report");
			tfe.printStackTrace();
			session.setAttribute("error_msg","TransformerException creating Report");
			response.sendRedirect("authorFailure.jsp");
		}}else{
			logWriter.error("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg", "Session Expired... Please Login Again");
			//session.setAttribute("error_msg","Session Expired... Please Login Again");
			response.sendRedirect("authorFailure.jsp");
		}
	}
	private static String dequote(String quoted) {
        assert quoted.startsWith("\"");
        assert quoted.endsWith("\"");
        return quoted.substring(1, quoted.length() - 1).replace("\"\"", "\"");
    }
	//ReadCSVWithScanner
	@RequestMapping(value = "/ReadCSVWithScanner.do")
	public ModelAndView ReadCSVWithScanner(HttpServletRequest request) throws IOException {
		int result=0;
		Map<String, Object> responseData = null;
		try{
		
		BufferedReader reader = new BufferedReader(new FileReader(
				"C:\\Users\\ban76778\\Desktop\\EXCHANGE ATMs.csv"));
		// read file line by line
		String line = null;
		Scanner scanner = null;
		int index = 0;
		List<ExchangeATMs> empList = new ArrayList<>();
		//java.util.regex reg=new  java.util.regex
		while ((line = reader.readLine()) != null) {
			ExchangeATMs emp = new ExchangeATMs();
			scanner = new Scanner(line);
			//scanner.useDelimiter(",");
			scanner.useDelimiter(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
			while (scanner.hasNext()) {
				String data = scanner.next();
				String updated=null;
				if (index == 0)
					emp.setLONGITUDE(data);
					//emp.setId(Integer.parseInt(data));
				else if (index == 1)
					emp.setLATITUDE(data);
				else if (index == 2){
					updated=dequote(data);
					emp.setBRANCH_NAME(updated);}
				else if (index == 3){
					updated=dequote(data);
					emp.setADDRESS(updated);}
				else
					System.out.println("invalid data::" + data);
				index++;
			}
			index = 0;
			empList.add(emp);
		}
		
		//close reader
		reader.close();
		try {
			if(!empList.isEmpty()){
				System.out.println(empList);
			for(int i=0;i<empList.size();i++){
				result=userActionService.ABMDataUpload(empList.get(i));
			}
			if(result==0){
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows to update");
				session.setAttribute("message","No rows to update");
				return new ModelAndView("success", responseData);
			}
			else {
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Limits added successfully");
				session.setAttribute("message","Limits added successfully");
				return new ModelAndView("success", responseData);
			}
			} else {
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows to update");
				session.setAttribute("message","No rows to update");
				return new ModelAndView("success", responseData);
			}
		}
		catch (Exception e) {
			logWriter.info("Error: "+e.getMessage()+" Cause: "+e.getCause());
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Something went wrong. Please try again later");
			responseData.put("status", "failure");
			session.setAttribute("error_msg","Something went wrong. Please try again later");
			return new ModelAndView("error", responseData);
		}
		} catch(FileNotFoundException fe){
			System.out.println("FileNotFoundException"+fe);
			session.setAttribute("error_msg","FileNotFoundException");
			return new ModelAndView("error", responseData);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Exception"+e);
			session.setAttribute("error_msg","Exception"+e);
			return new ModelAndView("error", responseData);
		}
		
	}
	@RequestMapping(value = "/geteClearingDetails.do")
	public ModelAndView geteClearingDetails(HttpServletRequest request,@RequestParam String fromDate,@RequestParam String toDate,@RequestParam String status,@RequestParam String mobileNo) throws ParseException {
		logWriter.info("in /WriteCSVWithAttempts");
		List<Attempts> attempts=null;
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date frmDate = formater.parse(fromDate);
		java.util.Date todate = formater.parse(toDate);
		if(!mobileNo.isEmpty()){
			if(status.equals("Failed")){
				attempts=userActionService.getCustomerFailureReport(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo);
			} else if(status.equals("Processed")){
				attempts=userActionService.getCustomerSuccessReport(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo,status);
			} else if(status.equals("Pending")){
				attempts=userActionService.getPendingEchequeAttemptswithMobile(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo);
			}else if(status.equals("All")){
				//attempts=userActionService.getCustomerFailureReport(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo);
				attempts=userActionService.getReportForCustomerActivities(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo);
			} 
		}else {
			if(status.equals("Failed")){
				attempts=userActionService.getFailureEchequeAttempts(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()));
			} else if(status.equals("Processed")){
				attempts=userActionService.getEchequeAttempts(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),status);
			} else if(status.equals("Pending")){
				attempts=userActionService.getPendingEchequeAttempts(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),status);
			} else if(status.equals("All")){
				//attempts=userActionService.getCustomerFailureReport(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo);
				attempts=userActionService.getReportForCustomerActivitiesWithStatus(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()));
			} 

		}

		/*logWriter.info("In /AddFieldsDetails.do getFieldsDetails");
		HttpSession session = null;
		//session = request.getSession(false);
		session = request.getSession();
		Map<String, Object> responseData = null;
		List<Attempts> attempts=null;
		if(session!=null && session.getAttribute("userid") != null){
		SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date frmDate = formater.parse(fromDate);
		java.util.Date todate = formater.parse(toDate);
		if(status.equals("All")){
			attempts=userActionService.getReportForCustomerActivities(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo);
		} else if(status.equals("Processed")){
			attempts=userActionService.getCustomerSuccessReport(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo);
		} else if(status.equals("Failed")){
			attempts=userActionService.getCustomerFailureReport(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo);
		}*/ if(!attempts.isEmpty()){
			responseData = new HashMap<String, Object>();
			//responseData.put("message", "Success");
			responseData.put("userName",session.getAttribute("user"));
			responseData.put("fromDate", fromDate);
			responseData.put("toDate", toDate);
			responseData.put("status", status);
			responseData.put("mobileNo",mobileNo);
			responseData.put("eClearingDetails",attempts);
			logWriter.info("success");
			return new ModelAndView("reportGeneration", responseData);
		}else{
			logWriter.info("There are no records to generate Report");
			responseData = new HashMap<String, Object>();
			responseData.put("userName",session.getAttribute("user"));
			responseData.put("fromDate", fromDate);
			responseData.put("toDate", toDate);
			responseData.put("status", status);
			responseData.put("mobileNo",mobileNo);
			responseData.put("eclearingMessage", "There are no records to generate Report"); 
			return new ModelAndView("reportGeneration", responseData);
		}}else{
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg", "Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}
	@RequestMapping(value = "/WriteCSVWithAttempts.do")
	public void WriteCSVWithAttempts(HttpServletRequest request,HttpServletResponse response,@RequestParam String fromDate,@RequestParam String toDate,@RequestParam String status,@RequestParam String mobileNo) throws IOException, ParseException {
		logWriter.info("in /WriteCSVWithAttempts");
		List<Attempts> attempts=null;
		HttpSession session = null;
		session = request.getSession(false);
		if(session!=null && session.getAttribute("userid") != null){
		SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date frmDate = formater.parse(fromDate);
		java.util.Date todate = formater.parse(toDate);
		if(!mobileNo.isEmpty()){
			if(status.equals("Failed")){
				attempts=userActionService.getCustomerFailureReport(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo);
			} else if(status.equals("Processed")){
				attempts=userActionService.getCustomerSuccessReport(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo,status);
			} else if(status.equals("Pending")){
				attempts=userActionService.getPendingEchequeAttemptswithMobile(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo);
			}else if(status.equals("All")){
				//attempts=userActionService.getCustomerFailureReport(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo);
				attempts=userActionService.getReportForCustomerActivities(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo);
			} 
		}else {
			if(status.equals("Failed")){
				attempts=userActionService.getFailureEchequeAttempts(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()));
			} else if(status.equals("Processed")){
				attempts=userActionService.getEchequeAttempts(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),status);
			} else if(status.equals("Pending")){
				attempts=userActionService.getPendingEchequeAttempts(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),status);
			} else if(status.equals("All")){
				//attempts=userActionService.getCustomerFailureReport(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo);
				attempts=userActionService.getReportForCustomerActivitiesWithStatus(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()));
			} 

		}
		
		if(!attempts.isEmpty()){
	        String csvFile = "e-Report.csv";
	        FileWriter writer = new FileWriter(csvFile);
	        //for header
	        CSVUtils.writeLine(writer, Arrays.asList("CIFNumber", "MOBILENO", "BENEFICIARY_ACCOUNT","CHEQUE_DATE","CHEQUE_NUMBER","CHEQUE_AMOUNT","TRANSIT_NUMBER","INSTITUTION_ID","ISSUER_ACC_NO","MEMO","SUBMITTED_DATE","STATUS","REASON"));

	        for (Attempts att : attempts) {
	            List<String> list = new ArrayList<>();
	            if(att.getCIFNumber()!=null){
	            	list.add(att.getCIFNumber());
	            }else{
	            	list.add("");
	            }
	            if(att.getMobileNo()!=null){
	            	list.add(att.getMobileNo());
	            }else{
	            	list.add("");
	            }
	            if(att.getBeneficiaryAccount()!=null){
	            	list.add(att.getBeneficiaryAccount().toString());
	            }else{
	            	list.add("");
	            }
	            if(att.getChequeDate()!=null){
	            	list.add(att.getChequeDate().toString());
	            }else{
	            	list.add("");
	            }
	            if(att.getChequeNumber()!=null){
	            	 list.add(att.getChequeNumber());
	            }else{
	            	list.add("");
	            }
	            if(att.getChequeAmount()!=null){
	            	 list.add(att.getChequeAmount().toString());
	            }else{
	            	list.add("");
	            }
	            if(att.getTransitNumber()!=null){
	            	list.add(att.getTransitNumber());
	            }else{
	            	list.add("");
	            }
	            if(att.getInstitutionId()!=null){
	            	list.add(att.getInstitutionId());
	            }else{
	            	list.add("");
	            }
	            if(att.getIssuerAccNo()!=null){
	            	list.add(att.getIssuerAccNo());
	            }else{
	            	list.add("");
	            }
	            if(att.getMemo()!=null){
	            	list.add(att.getMemo());
	            }else{
	            	list.add("");
	            }
	            if(att.getSubmittedDate()!=null){
	            	list.add(att.getSubmittedDate().toString());
	            }else{
	            	list.add("");
	            }
	            if(att.getStatus()!=null){
	            	list.add(att.getStatus());
	            } else{
	            	list.add("Pending");
	            	//list.add("");
	            }
	            if(att.getReason()!=null){
	            	list.add(att.getReason());
	            }else{
	            	list.add("");
	            }
	            CSVUtils.writeLine(writer, list);
	        }
	        writer.flush();
	        writer.close();
	        try {
	            FileInputStream inputStream = new FileInputStream(csvFile);
	            String disposition = "attachment; fileName=e-Report.csv";
	            response.setContentType("text/csv");
	            response.setHeader("Content-Disposition", disposition);
	            response.setHeader("content-Length", String.valueOf(stream(inputStream, response.getOutputStream())));

	        } catch (IOException e) {
	            logWriter.error("Error occurred while downloading file {}",e);
	            request.setAttribute("message", "Error occurred while downloading file ");
				session.setAttribute("error_msg","Error occurred while downloading file ");
				response.sendRedirect("authorFailure.jsp");
				throw new ServerException("Error occurred while downloading file ", e);
	        }
	        catch(Exception e){
				logWriter.error("exception is:"+e);
				logWriter.error("Error creating Report: "+e);
				request.setAttribute("message", "Error creating Report");
				session.setAttribute("error_msg","Error creating Report");
				response.sendRedirect("authorFailure.jsp");
				throw new ServerException("Error generating direct verification response", e);
			}} else{
				logWriter.info("There are no cheques to generate Report");
				request.setAttribute("message", "There are no cheques to generate Report");
				session.setAttribute("message","There are no cheques to generate Report");
				response.sendRedirect("success.jsp");
			}}else{
				logWriter.error("Session Expired...");
				//session.setAttribute("error_msg","Session Expired... Please Login Again");
				response.sendRedirect("authorFailure.jsp");
			}
	}
	@RequestMapping(value = "/ReportForCustomerActivities.do")
	//public void ReportForCustomerActivities(HttpServletRequest request,HttpServletResponse response,@RequestParam String fromDate,@RequestParam String toDate,@RequestParam String status,@RequestParam String mobileNo) throws IOException, ParseException {
	public void ReportForCustomerActivities(HttpServletRequest request,HttpServletResponse response,@RequestParam("fromDate") String fromDate,@RequestParam("toDate") String toDate,@RequestParam("status") String status,@RequestParam("mobileNo") String mobileNo) throws IOException, ParseException {	
	logWriter.info("in /ReportForCustomerActivities");
		List<Attempts> attempts=null;
		HttpSession session = null;
		session = request.getSession(false);
		if(session!=null && session.getAttribute("userId")!=null){
		SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date frmDate = formater.parse(fromDate);
		java.util.Date todate = formater.parse(toDate);
		if(status.equals("All")){
			attempts=userActionService.getReportForCustomerActivities(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo);
		} else if(status.equals("Processed")){
			attempts=userActionService.getCustomerSuccessReport(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo,status);
		} else if(status.equals("Failed")){
			attempts=userActionService.getCustomerFailureReport(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo);
		}
		if(!attempts.isEmpty()){
	        String csvFile = "e-Report.csv";
	        FileWriter writer = new FileWriter(csvFile);
	        //for header
	        CSVUtils.writeLine(writer, Arrays.asList("CIFNumber", "MOBILENO", "BENEFICIARY_ACCOUNT","CHEQUE_DATE","CHEQUE_NUMBER","CHEQUE_AMOUNT","TRANSIT_NUMBER","INSTITUTION_ID","ISSUER_ACC_NO","MEMO","SUBMITTED_DATE","STATUS","REASON"));
	        //CSVUtils.writeLine(writer, Arrays.asList("MOBILENO", "BENEFICIARY_ACCOUNT","CHEQUE_AMOUNT","MICR_band","REASON","STATUS"));
	        for (Attempts att : attempts) {
	        	 
	            List<String> list = new ArrayList<>();
	            if(att.getCIFNumber()!=null){
	            	list.add(att.getCIFNumber());
	            }else{
	            	list.add("");
	            }
	            if(att.getMobileNo()!=null){
	            	list.add(att.getMobileNo());
	            }else{
	            	list.add("");
	            }
	            if(att.getBeneficiaryAccount()!=null){
	            	list.add(att.getBeneficiaryAccount().toString());
	            }else{
	            	list.add("");
	            }
	            if(att.getChequeDate()!=null){
	            	list.add(att.getChequeDate().toString());
	            }else{
	            	list.add("");
	            }
	            if(att.getChequeNumber()!=null){
	            	 list.add(att.getChequeNumber());
	            }else{
	            	list.add("");
	            }
	            if(att.getChequeAmount()!=null){
	            	 list.add(att.getChequeAmount().toString());
	            }else{
	            	list.add("");
	            }
	            if(att.getTransitNumber()!=null){
	            	list.add(att.getTransitNumber());
	            }else{
	            	list.add("");
	            }
	            if(att.getInstitutionId()!=null){
	            	list.add(att.getInstitutionId());
	            }else{
	            	list.add("");
	            }
	            if(att.getIssuerAccNo()!=null){
	            	list.add(att.getIssuerAccNo());
	            }else{
	            	list.add("");
	            }
	            if(att.getMemo()!=null){
	            	list.add(att.getMemo());
	            }else{
	            	list.add("");
	            }
	            if(att.getSubmittedDate()!=null){
	            	list.add(att.getSubmittedDate().toString());
	            }else{
	            	list.add("");
	            }
	           /* list.add(status);*/
	            if(att.getStatus()!=null){
	            	list.add(att.getStatus());
	            } else{
	            	list.add("Pending");
	            	//list.add("");
	            }
	            if(att.getReason()!=null){
	            	list.add(att.getReason());
	            }else{
	            	list.add("");
	            }
	            CSVUtils.writeLine(writer, list);
	        }
	        writer.flush();
	        writer.close();
	        try {
	            FileInputStream inputStream = new FileInputStream(csvFile);
	            String disposition = "attachment; fileName=e-Report.csv";
	            response.setContentType("text/csv");
	            response.setHeader("Content-Disposition", disposition);
	            response.setHeader("content-Length", String.valueOf(stream(inputStream, response.getOutputStream())));

	        } catch (IOException e) {
	            logWriter.error("Error occurred while downloading file {}",e);
	            request.setAttribute("message", "Error occurred while downloading file ");
				session.setAttribute("error_msg","Error occurred while downloading file ");
				response.sendRedirect("authorFailure.jsp");
				throw new ServerException("Error occurred while downloading file ", e);
	        }
	        catch(Exception e){
				logWriter.error("exception is:"+e);
				logWriter.error("Error creating Report: "+e);
				request.setAttribute("message", "Error creating Report");
				session.setAttribute("error_msg","Error creating Report");
				response.sendRedirect("authorFailure.jsp");
				throw new ServerException("Error generating direct verification response", e);
			}} else{
				logWriter.info("There are no records to generate Report");
				request.setAttribute("message", "There are no records to generate Report");
				session.setAttribute("message","There are no records to generate Report");
				response.sendRedirect("success.jsp");
			}}else{
				logWriter.error("Session Expired...");
				response.sendRedirect("authorFailure.jsp");
			}
	}
	
	@RequestMapping(value = "/getCustomerActivities.do")
	public ModelAndView getCustomerActivities(HttpServletRequest request,@RequestParam String fromDate,@RequestParam String toDate,@RequestParam String status,@RequestParam String mobileNo) throws ParseException {
		logWriter.info("In /AddFieldsDetails.do getFieldsDetails");
		HttpSession session = null;
		//session = request.getSession(false);
		session = request.getSession();
		Map<String, Object> responseData = null;
		List<Attempts> attempts=null;
		if(session!=null && session.getAttribute("userid") != null){
		SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date frmDate = formater.parse(fromDate);
		java.util.Date todate = formater.parse(toDate);
		if(status.equals("All")){
			attempts=userActionService.getReportForCustomerActivities(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo);
		} else if(status.equals("Processed")){
			attempts=userActionService.getCustomerSuccessReport(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo,status);
		} else if(status.equals("Failed")){
			attempts=userActionService.getCustomerFailureReport(new java.sql.Date(frmDate.getTime()),new java.sql.Date(todate.getTime()),mobileNo);
		} if(!attempts.isEmpty()){
			responseData = new HashMap<String, Object>();
			//responseData.put("message", "Success");
			responseData.put("userName",session.getAttribute("user"));
			responseData.put("fromDate", fromDate);
			responseData.put("toDate", toDate);
			responseData.put("status", status);
			responseData.put("mobileNo",mobileNo);
			responseData.put("Attempts",attempts);
			logWriter.info("success");
			return new ModelAndView("customerReport", responseData);
		}else{
			logWriter.info("There are no records to generate Report");
			responseData = new HashMap<String, Object>();
			responseData.put("fromDate", fromDate);
			responseData.put("toDate", toDate);
			responseData.put("status", status);
			responseData.put("mobileNo",mobileNo);
			responseData.put("reportMessage", "There are no records to generate Report"); 
			return new ModelAndView("customerReport", responseData);
		}}else{
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg", "Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}
	private long stream(InputStream input, OutputStream output) throws IOException {

	    try (ReadableByteChannel inputChannel = Channels.newChannel(input); WritableByteChannel outputChannel = Channels.newChannel(output)) {
	        ByteBuffer buffer = ByteBuffer.allocate(10240);
	        long size = 0;

	        while (inputChannel.read(buffer) != -1) {
	            buffer.flip();
	            size += outputChannel.write(buffer);
	            buffer.clear();
	        }
	        return size;
	    }
	}

	@RequestMapping(value = "/generateReportForZone.do")
	public void generateReportForZone(HttpServletRequest request,HttpServletResponse response,@RequestParam String zoneName) throws Exception{
		session = request.getSession();
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		try {
			logWriter.info("in getEchequeDeposit ---------" );
			Date end=null;Date start=null;
			String cutOffTime=userActionService.getCuttOffTime();
			if(!cutOffTime.isEmpty()){
				String hour = cutOffTime.split(":")[0];
				String min = cutOffTime.split(":")[1];
				TimeZone tz = TimeZone.getTimeZone("EST");
				Calendar calendar = GregorianCalendar.getInstance(tz);
				calendar.clear();
				calendar.setTimeZone(tz);
				calendar.setTime(new Date());
				calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hour));
				calendar.set(Calendar.MINUTE, Integer.parseInt(min));
				calendar.set(Calendar.SECOND,0);
				calendar.set(Calendar.MILLISECOND,000);
				System.out.println(calendar.getTimeInMillis());
				System.out.println(calendar.getTimeZone());
				 end = calendar.getTime();
				System.out.println("date is: "+end);
				 start = DateUtils.addDays(end, -1);
				 System.out.println("date in EST : "+CommonUtil.getDateTime(CommonUtil.getTimeZoneDateTime(),"dd/MM/yyyy HH:mm:ss"));
				 System.out.println("date in EST : "+CommonUtil.getDateTime(end.getTime(),"dd/MM/yyyy HH:mm:ss z"));
				
			} else{
				 end = DateUtils.truncate(new Date(), Calendar.DAY_OF_MONTH);
				 start = DateUtils.addDays(end, -1);
			}
			//String status=null;
			/*List<EchequeDepositBean> echequelist= userActionService.generateRequestPacket(new java.sql.Date(start.getTime()),new java.sql.Date(end.getTime()));*/
			/*Date end = DateUtils.truncate(new Date(), Calendar.DAY_OF_MONTH);
			Date start = DateUtils.addDays(end, -1);*/
			//String status=null;
			//List<EchequeDepositBean> echequelist= userActionService.generateRequestPacketForZone(new java.sql.Date(start.getTime()),new java.sql.Date(end.getTime()),zoneName);
			List<EchequeDepositBean> echequelist= userActionService.generateRequestPacketForZone(new java.sql.Timestamp(end.getTime()),zoneName);
			logWriter.info("echequelist is"+echequelist.toArray());
			if(!echequelist.isEmpty()){
				try{
					userActionService.getEchequeDepositRequestPacket(request,response,echequelist);
					logWriter.info("Report generated successfully");
					responseData = new HashMap<String, Object>();
					request.setAttribute("message", "Report generated successfully");
					session.setAttribute("message","Report generated successfully");
				}catch(Exception e){
					logWriter.error("exception is:"+e);
					logWriter.error("Error creating Report: "+e);
					request.setAttribute("message", "Error creating Report");
					session.setAttribute("error_msg","Error creating Report");
					response.sendRedirect("authorFailure.jsp");
					throw new ServerException("Error generating direct verification response", e);
				}
			}
			else{
				logWriter.info("There are no cheques to generate Report");
				request.setAttribute("message", "There are no cheques to generate Report");
				session.setAttribute("message","There are no cheques to generate Report");
				response.sendRedirect("success.jsp");
			}
		} catch (ParserConfigurationException pce) {
			logWriter.error("ParserConfigurationException creating Report");
			pce.printStackTrace();
			session.setAttribute("error_msg","ParserConfigurationException creating Report");
			response.sendRedirect("Error.jsp");
		} catch (TransformerException tfe) {
			logWriter.error("TransformerException creating Report");
			tfe.printStackTrace();
			session.setAttribute("error_msg","TransformerException creating Report");
			response.sendRedirect("Error.jsp");
		}}
		else{
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg", "Session Expired... Please Login Again");
			response.sendRedirect("authorFailure.jsp");
		}
	}
	
}