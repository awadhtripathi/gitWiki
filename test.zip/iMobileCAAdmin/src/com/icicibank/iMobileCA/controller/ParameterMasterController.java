package com.icicibank.iMobileCA.controller;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.icicibank.iMobileCA.model.Parameters;
import com.icicibank.iMobileCA.service.ParameterMasterService;
import com.icicibank.iMobileCA.service.UserActionService;

@RestController
public class ParameterMasterController {

	private static final Logger logWriter = Logger
			.getLogger(ParameterMasterController.class.getName());

	@Autowired
	private ParameterMasterService parameterMasterSerive;

	public ParameterMasterService getParameterMasterService() {
		return parameterMasterSerive;
	}
	@Autowired
	private UserActionService userActionService;

	public UserActionService getUserActionService() {
		return userActionService;
	}
	@RequestMapping(value = "/getParameterDetails.do")
	public ModelAndView getParameterDetails(HttpServletRequest request) {
		logWriter.info("In /getParameterDetails.do getParameterDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("paramDetails",
					parameterMasterSerive.getParameterDetails());
			logWriter.info("success");
			return new ModelAndView("paramDetails", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/getParametersForUpdate.do")
	public ModelAndView getParametersForUpdate(HttpServletRequest request) {
		logWriter.info("In /getParameterDetails.do getParameterDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("updateParamDetails",
					parameterMasterSerive.getParameterDetails());
			logWriter.info("success");
			return new ModelAndView("updateParamDetails", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	@RequestMapping(value = "/addParams.do", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ModelAndView addDetails(HttpServletRequest request,
			@RequestBody HashMap<String, String> detailsObj)
			throws IllegalAccessException, InvocationTargetException {

		logWriter.info("In /addParams.do addFieldDetails");
		System.out.print("+++"+detailsObj.get(detailsObj));
		logWriter.info("detailsObj size is" + detailsObj.size());
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: " + session.getAttribute("userid"));
		String userId = (String) session.getAttribute("userid");
		int result = 0;
		List<Parameters> list = new ArrayList<Parameters>();
		for (Map.Entry<String, String> entry : detailsObj.entrySet()) {
			Parameters parameters = new Parameters();
			parameters.setParam(entry.getKey());
			parameters.setParamValue(entry.getValue());
			System.out.println(entry.getKey());
			System.out.println(entry.getValue());
			parameters.setMaker(userId);
			parameters.setMakerDt(new java.sql.Timestamp(new Date().getTime()));
			logWriter.info(entry.getKey() + "/" + entry.getValue());
			list.add(parameters);
		}
		try {
			if (!list.isEmpty()) {
				for (int i = 0; i < list.size(); i++) {
					result = parameterMasterSerive
							.updateParameters(list.get(i));
					// userActionService.updateFields(list.get(i));//list.getChangedValue(),list.getAuthoringStatus(),list.getMaker(),list.getMakerDt(),list.getLimitType()
					// userActionService.authorFields(list);
					// userActionService.updateAuditLog("IMCA_TRANSATION_RANGE",
					// "LAST_LOGIN_DATE", LastLogin,currentTime,"IMBCA");
				}
				if (result == 0) {
					responseData = new HashMap<String, Object>();
					responseData.put("message", "No rows to update");
					session.setAttribute("message", "No rows to update");
					return new ModelAndView("success", responseData);
				} else {
					responseData = new HashMap<String, Object>();
					responseData.put("message", "Param Updated successfully");
					session.setAttribute("message", "Param added successfully");
					return new ModelAndView("success", responseData);
				}
			} else {
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows to update");
				session.setAttribute("message", "No rows to update");
				return new ModelAndView("success", responseData);
			}
		}
		/*
		 * if(result==0){ responseData = new HashMap<String, Object>();
		 * responseData.put("message", "Record Added successfully");
		 * responseData.put("userName",session.getAttribute("user")); return new
		 * ModelAndView("success", responseData);
		 * 
		 * }else { responseData = new HashMap<String, Object>();
		 * responseData.put("message","records updated successfully");
		 * responseData.put("userName",session.getAttribute("user"));
		 * responseData.put("status", "success"); return new
		 * ModelAndView("success", responseData); }
		 * 
		 * //count++; int isExist = userActionService.checkFields(list.get(i));
		 * logWriter.info("isExist---count------"+isExist); if (isExist == 0) {
		 * userActionService.saveFields(list.get(i));
		 * //userActionService.saveFields(listMap); responseData = new
		 * HashMap<String, Object>(); responseData.put("message",
		 * "Record Added successfully");
		 * //responseData.put("userName",session.getAttribute("user"));
		 * //responseData.put("AddFieldsData",
		 * userActionService.getAddFieldsData()); //return new
		 * ModelAndView("adminHomePage", responseData); } else{
		 * userActionService.updateFields(list.get(i));
		 * logWriter.info("field already exists"); }
		 * 
		 * responseData = new HashMap<String, Object>();
		 * responseData.put("message", "Record Added successfully");
		 * responseData.put("userName",session.getAttribute("user")); //return
		 * new ModelAndView("success", responseData); //return "Success";
		 * //responseData.put("AddFieldsData",
		 * userActionService.getFieldsData());
		 * //addPayeeRequest.setPayerUserID(AESDecrypt
		 * .generateEncryptedString(map, addPayeeRequest.getPayerUserID())); }
		 */
		catch (Exception e) {
			logWriter.info("Error: " + e.getMessage() + " Cause: "
					+ e.getCause());
			responseData = new HashMap<String, Object>();
			responseData.put("message",
					"Something went wrong. Please try again later");
			responseData.put("status", "failure");
			session.setAttribute("error_msg",
					"Something went wrong. Please try again later");
			return new ModelAndView("error", responseData);
		}
		// return responseData;
	} else {
		logWriter.info("Session Expired...");
		responseData = new HashMap<String, Object>();
		responseData.put("error_msg",
				"Session Expired... Please Login Again");
		return new ModelAndView("authorFailure", responseData);
	}
	}
}
