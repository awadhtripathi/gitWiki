package com.icicibank.iMobileCA.controller;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.icicibank.iMobileCA.model.Attempts;
import com.icicibank.iMobileCA.model.AuditLog;
import com.icicibank.iMobileCA.service.EdepositStatusService;
import com.icicibank.iMobileCA.service.UserActionService;
import com.icicibank.iMobileCA.util.CommonUtil;

@RestController
public class EdepositStatusController {

	private static final Logger logWriter = Logger
			.getLogger(UserActionController.class.getName());
	private HttpSession session;
	
	@Autowired
	private EdepositStatusService edepositStatusService;

	
	public EdepositStatusService getEdepositStatusService() {
		return edepositStatusService;
	}
	@Autowired
	private UserActionService userActionService;

	
	public UserActionService getUserActionService() {
		return userActionService;
	}
	CommonUtil commonUtil= new CommonUtil();
	@RequestMapping(value = "/searchZoneDetails.do")
	public ModelAndView searchZoneDetails(HttpServletRequest request,HttpServletResponse response,@RequestParam String zoneName,@RequestParam String selectedDate,@RequestParam String refNumber) throws Exception{
		logWriter.info("In /getZoneDetails.do getZoneDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		if(!zoneName.isEmpty()&&!selectedDate.isEmpty()&& !refNumber.isEmpty()){
			Date end=null;Date start=null;
			String cutOffTime=userActionService.getCuttOffTime();
			if(!cutOffTime.isEmpty()){
				SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date frmDate = formater.parse(selectedDate);
				end=CommonUtil.getESTDateWithCutoff(frmDate, cutOffTime);
				System.out.println("date is: "+end);
				start = DateUtils.addDays(end, -1);
			} else{
				 end = DateUtils.truncate(new Date(), Calendar.DAY_OF_MONTH);
				 start = DateUtils.addDays(end, -1);
			}
			List<Attempts> attempts=edepositStatusService.getZoneDetails(zoneName,new java.sql.Timestamp(start.getTime()),new java.sql.Timestamp(end.getTime()),refNumber);
			/*SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date frmDate = formater.parse(selectedDate);
			Date startTime=CommonUtil.beginOfDay(frmDate);
			Date endTime=CommonUtil.endOfDay(frmDate);
			responseData = new HashMap<String, Object>();
			//responseData.put("message", "Success");
			responseData.put("userName",session.getAttribute("user"));
			List<Attempts> attempts=edepositStatusService.getZoneDetails(zoneName,new java.sql.Timestamp(startTime.getTime()),new java.sql.Timestamp(endTime.getTime()),refNumber);*/
			if(!attempts.isEmpty()){
				responseData = new HashMap<String, Object>();
				responseData.put("zoneName",zoneName);
				responseData.put("selectedDate",selectedDate);
				responseData.put("refNumber",refNumber);
				responseData.put("zoneData", attempts);
				logWriter.info("success");
				return new ModelAndView("searchZones", responseData);
			} else{
				logWriter.info("There are no records for your selection");
				responseData = new HashMap<String, Object>();
				responseData.put("zoneMessage", "There are no records for selected zone,date and reference");
				return new ModelAndView("searchZones", responseData);
			}
			/*responseData.put("zoneData", edepositStatusService.getZoneDetails(zoneName,new java.sql.Date(frmDate.getTime())));
			logWriter.info("success");
			return new ModelAndView("zoneDetails", responseData);*/
		}else if(!selectedDate.isEmpty()&& !refNumber.isEmpty()&&zoneName.isEmpty()){
			Date end=null;Date start=null;
			String cutOffTime=userActionService.getCuttOffTime();
			if(!cutOffTime.isEmpty()){
				SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date frmDate = formater.parse(selectedDate);
				end=CommonUtil.getESTDateWithCutoff(frmDate, cutOffTime);
				System.out.println("date is: "+end);
				start = DateUtils.addDays(end, -1);
			} else{
				 end = DateUtils.truncate(new Date(), Calendar.DAY_OF_MONTH);
				 start = DateUtils.addDays(end, -1);
			}
			List<Attempts> attempts=edepositStatusService.getDetailswithDateRefNo(new java.sql.Timestamp(start.getTime()),new java.sql.Timestamp(end.getTime()),refNumber);//need to change
			if(!attempts.isEmpty()){
				responseData = new HashMap<String, Object>();
				responseData.put("zoneName",zoneName);
				responseData.put("selectedDate",selectedDate);
				responseData.put("refNumber",refNumber);
				responseData.put("zoneData", attempts);
				logWriter.info("success");
				return new ModelAndView("searchZones", responseData);
			} else{
				logWriter.info("There are no records for your selection");
				responseData = new HashMap<String, Object>();
				responseData.put("zoneMessage", "There are no records for selected date and reference");
				return new ModelAndView("searchZones", responseData);
			}
			
		}else if(!selectedDate.isEmpty()&& !zoneName.isEmpty()&&refNumber.isEmpty()){
			Date end=null;Date start=null;
			String cutOffTime=userActionService.getCuttOffTime();
			if(!cutOffTime.isEmpty()){
				SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date frmDate = formater.parse(selectedDate);
				end=CommonUtil.getESTDateWithCutoff(frmDate, cutOffTime);
				System.out.println("date is: "+end);
				start = DateUtils.addDays(end, -1);
			} else{
				 end = DateUtils.truncate(new Date(), Calendar.DAY_OF_MONTH);
				 start = DateUtils.addDays(end, -1);
			}
			List<Attempts> attempts=edepositStatusService.getDetailswithDate(zoneName,new java.sql.Timestamp(start.getTime()),new java.sql.Timestamp(end.getTime()));
			if(!attempts.isEmpty()){
				responseData = new HashMap<String, Object>();
				responseData.put("zoneName",zoneName);
				responseData.put("selectedDate",selectedDate);
				responseData.put("refNumber",refNumber);
				responseData.put("zoneData", attempts);
				logWriter.info("success");
				return new ModelAndView("searchZones", responseData);
			} else{
				logWriter.info("There are no records for your selection");
				responseData = new HashMap<String, Object>();
				responseData.put("zoneMessage", "There are no records for selected zone and date");
				return new ModelAndView("searchZones", responseData);
			}
		}
		else if(!refNumber.isEmpty()&&!zoneName.isEmpty()&&selectedDate.isEmpty()){
			responseData = new HashMap<String, Object>();
			//responseData.put("message", "Success");
			responseData.put("userName",session.getAttribute("user"));
			List<Attempts> attempts=edepositStatusService.getDetailswithRef(zoneName,refNumber);
			if(!attempts.isEmpty()){
				responseData.put("zoneName",zoneName);
				responseData.put("selectedDate",selectedDate);
				responseData.put("refNumber", refNumber);
				responseData.put("zoneData", attempts);
				logWriter.info("success");
				return new ModelAndView("searchZones", responseData);
			} else{
				logWriter.info("There are no records for your selection");
				responseData = new HashMap<String, Object>();
				responseData.put("zoneMessage", "There are no records for selected zone and reference");
				return new ModelAndView("searchZones", responseData);
			}
		}
		/*if(!zoneName.isEmpty()&&!selectedDate.isEmpty()&&refNumber.isEmpty()){
			SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date frmDate = formater.parse(selectedDate);
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName",session.getAttribute("user"));
			responseData.put("zoneData", edepositStatusService.getZoneDetails(zoneName,new java.sql.Date(frmDate.getTime())));
			logWriter.info("success");
			return new ModelAndView("zoneDetails", responseData);
		}else if(!zoneName.isEmpty()){
			SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date frmDate = formater.parse(selectedDate);
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName",session.getAttribute("user"));
			responseData.put("zoneData", edepositStatusService.getDetailswithZone(zoneName));
			logWriter.info("success");
			return new ModelAndView("zoneDetails", responseData);
		}*/else if(!selectedDate.isEmpty()&&zoneName.isEmpty()&&refNumber.isEmpty()){
			Date end=null;Date start=null;
			String cutOffTime=userActionService.getCuttOffTime();
			if(!cutOffTime.isEmpty()){
				SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date frmDate = formater.parse(selectedDate);
				end=CommonUtil.getESTDateWithCutoff(frmDate, cutOffTime);
				System.out.println("date is: "+end);
				start = DateUtils.addDays(end, -1);
			} else{
				 end = DateUtils.truncate(new Date(), Calendar.DAY_OF_MONTH);
				 start = DateUtils.addDays(end, -1);
			}
			List<Attempts> attempts=edepositStatusService.getDetailswithSubDate(new java.sql.Timestamp(start.getTime()),new java.sql.Timestamp(end.getTime()));
			if(!attempts.isEmpty()){
				responseData = new HashMap<String, Object>();
				responseData.put("zoneName",zoneName);
				responseData.put("selectedDate",selectedDate);
				responseData.put("refNumber", refNumber);
				responseData.put("zoneData", attempts);
				logWriter.info("success");
				return new ModelAndView("searchZones", responseData);
			} else{
				logWriter.info("There are no records for your selection");
				responseData = new HashMap<String, Object>();
				responseData.put("zoneMessage", "There are no records for selected zone and reference");
				return new ModelAndView("searchZones", responseData);
			}
		}
		else if(!refNumber.isEmpty()&&selectedDate.isEmpty()&&zoneName.isEmpty()){
			List<Attempts> attempts= edepositStatusService.getDetailswithReference(refNumber);
			if(!attempts.isEmpty()){
				responseData = new HashMap<String, Object>();
				responseData.put("zoneName",zoneName);
				responseData.put("selectedDate",selectedDate);
				responseData.put("refNumber", refNumber);
				responseData.put("zoneData", attempts);
				logWriter.info("success");
				return new ModelAndView("searchZones", responseData);
			} else{
				logWriter.info("There are no records for your selection");
				responseData = new HashMap<String, Object>();
				responseData.put("zoneMessage", "There are no records for selected zone and reference");
				return new ModelAndView("searchZones", responseData);
			}
		}
		else{
			logWriter.info("There are no records for your selection");
			responseData = new HashMap<String, Object>();
			responseData.put("zoneName",zoneName);
			responseData.put("selectedDate",selectedDate);
			responseData.put("refNumber",refNumber);
			//session.setAttribute("message","There are no records for your selection");
			responseData.put("zoneMessage", "There are no records for your selection");
			return new ModelAndView("searchZones", responseData);
		}}else{
			logWriter.error("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg", "Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}
	@RequestMapping(value = "/updateStatus.do",method = RequestMethod.POST)
	public ModelAndView updateStatus(HttpServletRequest request,@RequestParam String checkedValues,@RequestParam String bulkstatus) {
		//public ModelAndView updateStatus(HttpServletRequest request,@RequestParam String cityName,@RequestParam String cityCode,@RequestParam String provinceCode,@RequestParam String status) {
		logWriter.info("In /updateStatus.do updateStatus");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: "+session.getAttribute("userid"));
		String userId=(String) session.getAttribute("userid");
		//String userId="ban99984";
		int result=0;
		Attempts attempts=new Attempts();
		//attempts.setReferenceNumber(refNumber);
		attempts.setStatus(bulkstatus);
		/*city.setCityName(cityName);
		city.setCityCode(cityCode);
		city.setProvinceCode(provinceCode);
		city.setStatus(status);*/
		attempts.setAuthStatus("N");
		attempts.setMaker(userId);
		try {
			System.out.println(CommonUtil.getCurrentDateTime()); 
			System.out.println(CommonUtil.getDateTime(CommonUtil.getTimeZoneDateTime(),"dd/MM/yyyy HH:mm:ss"));
			attempts.setMakerDt(new java.sql.Timestamp(new Date().getTime()));
			result=edepositStatusService.updateStatus(attempts,checkedValues);
			if(result==0){
				logWriter.info("No rows Added");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows Added");
				//session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			}
			else {
				logWriter.info("Status updated successfully");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Status updated successfully");
				return new ModelAndView("success", responseData);
			}
		} catch (Exception e) {
			logWriter.error("Error: "+e.getMessage()+" Cause: "+e.getCause());
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Exception while updating Status ");
			//session.setAttribute("error_msg","Something went wrong. Please try again later");
			return new ModelAndView("error", responseData);
		}}else{
			logWriter.error("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg", "Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}
	
	@RequestMapping(value = "/zoneDetailsForAuthor.do")
	public ModelAndView getzoneDetailsForAuthor(HttpServletRequest request) {
		logWriter.info("In /AddFieldsDetails.do getFieldsDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
			responseData = new HashMap<String, Object>();
			String userId=(String) session.getAttribute("userid");
			List<Attempts> details=edepositStatusService.getZoneDetailsForAuthor(userId);
			
			if(!details.isEmpty()){
			/*for (Limits limits : details) {
				maker=limits.getMaker();
				logWriter.info("limits are:"+limits.getLimit()+""+limits.getLimitType()+""+limits.getMaker());
			}*/
				logWriter.info("Success");
				responseData.put("message", "Success");
				responseData.put("getZonesData", details);
				logWriter.info("success");
				return new ModelAndView("authorZones", responseData);
			}
			else{
				logWriter.error("No fields to authorize");
				responseData.put("zoneMessage", "No fields to authorize");
				//session.setAttribute("error_msg","No fields to author");
				logWriter.info("success");
				return new ModelAndView("authorZones", responseData);
			}
		}
		else{
			logWriter.error("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg", "Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}
	@RequestMapping(value = "/zoneDetailsForAuthoring.do")
	public ModelAndView zoneDetailsForAuthoring(HttpServletRequest request,HttpServletResponse response,@RequestParam String zoneName,@RequestParam String selectedDate,@RequestParam String refNumber) throws Exception{
		logWriter.info("In /getZoneDetails.do getZoneDetails");
		HttpSession session = null;
		session = request.getSession(false);
		session = request.getSession();
		Map<String, Object> responseData = null;
		if(session!=null && session.getAttribute("userid") != null){
		logWriter.info("userId is: "+session.getAttribute("userid"));
		String userId=(String) session.getAttribute("userid");
		if(!zoneName.isEmpty()&&!selectedDate.isEmpty()&& !refNumber.isEmpty()){
			Date end=null;Date start=null;
			String cutOffTime=userActionService.getCuttOffTime();
			if(!cutOffTime.isEmpty()){
				SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date frmDate = formater.parse(selectedDate);
				end=CommonUtil.getESTDateWithCutoff(frmDate, cutOffTime);
				System.out.println("date is: "+end);
				start = DateUtils.addDays(end, -1);
			} else{
				 end = DateUtils.truncate(new Date(), Calendar.DAY_OF_MONTH);
				 start = DateUtils.addDays(end, -1);
			}
			//List<Attempts> attempts=edepositStatusService.getZoneDetails(zoneName,new java.sql.Timestamp(start.getTime()),new java.sql.Timestamp(end.getTime()),refNumber);
			/*
			SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date frmDate = formater.parse(selectedDate);
			//java.util.Date utilDate = new java.util.Date();
			java.sql.Timestamp sq = new java.sql.Timestamp(frmDate.getTime());  

			SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
			System.out.println(sdf.format(sq));
			Date startTime=CommonUtil.beginOfDay(frmDate);
			Date endTime=CommonUtil.endOfDay(frmDate);
			responseData = new HashMap<String, Object>();
			//responseData.put("message", "Success");
			responseData.put("userName",session.getAttribute("user"));*/
			List<Attempts> attempts=edepositStatusService.getZoneDetailsForAuthoring(zoneName,new java.sql.Timestamp(start.getTime()),new java.sql.Timestamp(end.getTime()),refNumber,userId);
			if(!attempts.isEmpty()){
				responseData = new HashMap<String, Object>();
				responseData.put("zoneName",zoneName);
				responseData.put("selectedDate",selectedDate);
				responseData.put("refNumber", refNumber);
				responseData.put("getZonesData", attempts);
				logWriter.info("success");
				return new ModelAndView("authorZones", responseData);
			} else{
				logWriter.info("There are no records for your selection");
				responseData = new HashMap<String, Object>();
				responseData.put("zoneMessage", "There are no records for selected zone,date and reference");
				return new ModelAndView("authorZones", responseData);
			}
			/*responseData.put("zoneData", edepositStatusService.getZoneDetails(zoneName,new java.sql.Date(frmDate.getTime())));
			logWriter.info("success");
			return new ModelAndView("zoneDetails", responseData);*/
		}else if(!selectedDate.isEmpty()&& !refNumber.isEmpty()&&zoneName.isEmpty()){
			/*SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date frmDate = formater.parse(selectedDate);
			Date startTime=CommonUtil.beginOfDay(frmDate);
			Date endTime=CommonUtil.endOfDay(frmDate);*/
			Date end=null;Date start=null;
			String cutOffTime=userActionService.getCuttOffTime();
			if(!cutOffTime.isEmpty()){
				SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date frmDate = formater.parse(selectedDate);
				end=CommonUtil.getESTDateWithCutoff(frmDate, cutOffTime);
				System.out.println("date is: "+end);
				start = DateUtils.addDays(end, -1);
			} else{
				 end = DateUtils.truncate(new Date(), Calendar.DAY_OF_MONTH);
				 start = DateUtils.addDays(end, -1);
			}
			responseData = new HashMap<String, Object>();
			//responseData.put("message", "Success");
			responseData.put("userName",session.getAttribute("user"));
			List<Attempts> attempts=edepositStatusService.getDetailswithDateRefNoForAuthor(new java.sql.Timestamp(start.getTime()),new java.sql.Timestamp(end.getTime()),refNumber,userId);//need to change
			if(!attempts.isEmpty()){
				responseData.put("zoneName",zoneName);
				responseData.put("selectedDate",selectedDate);
				responseData.put("refNumber", refNumber);
				responseData.put("getZonesData", attempts);
				logWriter.info("success");
				return new ModelAndView("authorZones", responseData);
			} else{
				logWriter.info("There are no records for your selection");
				responseData = new HashMap<String, Object>();
				responseData.put("zoneMessage", "There are no records for selected date and reference");
				return new ModelAndView("authorZones", responseData);
			}
			
		}else if(!selectedDate.isEmpty()&& !zoneName.isEmpty()&&refNumber.isEmpty()){
			/*SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date frmDate = formater.parse(selectedDate);
			Date startTime=CommonUtil.beginOfDay(frmDate);
			Date endTime=CommonUtil.endOfDay(frmDate);*/
			Date end=null;Date start=null;
			String cutOffTime=userActionService.getCuttOffTime();
			if(!cutOffTime.isEmpty()){
				SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date frmDate = formater.parse(selectedDate);
				end=CommonUtil.getESTDateWithCutoff(frmDate, cutOffTime);
				System.out.println("date is: "+end);
				start = DateUtils.addDays(end, -1);
			} else{
				 end = DateUtils.truncate(new Date(), Calendar.DAY_OF_MONTH);
				 start = DateUtils.addDays(end, -1);
			}
			responseData = new HashMap<String, Object>();
			//responseData.put("message", "Success");
			responseData.put("userName",session.getAttribute("user"));
			List<Attempts> attempts=edepositStatusService.getDetailswithDateForAuthor(zoneName,new java.sql.Timestamp(start.getTime()),new java.sql.Timestamp(end.getTime()),userId);
			if(!attempts.isEmpty()){
				responseData.put("zoneName",zoneName);
				responseData.put("selectedDate",selectedDate);
				responseData.put("refNumber", refNumber);
				responseData.put("getZonesData", attempts);
				logWriter.info("success");
				return new ModelAndView("authorZones", responseData);
			} else{
				logWriter.info("There are no records for your selection");
				responseData = new HashMap<String, Object>();
				responseData.put("zoneMessage", "There are no records for selected zone and date");
				return new ModelAndView("authorZones", responseData);
			}
		}
		else if(!refNumber.isEmpty()&&!zoneName.isEmpty()&&selectedDate.isEmpty()){
			
			responseData = new HashMap<String, Object>();
			//responseData.put("message", "Success");
			responseData.put("userName",session.getAttribute("user"));
			List<Attempts> attempts=edepositStatusService.getDetailswithRefForAuthor(zoneName,refNumber,userId);
			if(!attempts.isEmpty()){
				responseData.put("zoneName",zoneName);
				responseData.put("selectedDate",selectedDate);
				responseData.put("refNumber", refNumber);
				responseData.put("getZonesData", attempts);
				logWriter.info("success");
				return new ModelAndView("authorZones", responseData);
			} else{
				logWriter.info("There are no records for your selection");
				responseData = new HashMap<String, Object>();
				responseData.put("zoneMessage", "There are no records for selected zone and reference");
				return new ModelAndView("authorZones", responseData);
			}
		} else if(!selectedDate.isEmpty()&&zoneName.isEmpty()&&refNumber.isEmpty()){
			Date end=null;Date start=null;
			String cutOffTime=userActionService.getCuttOffTime();
			if(!cutOffTime.isEmpty()){
				SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date frmDate = formater.parse(selectedDate);
				end=CommonUtil.getESTDateWithCutoff(frmDate, cutOffTime);
				System.out.println("date is: "+end);
				start = DateUtils.addDays(end, -1);
			} else{
				 end = DateUtils.truncate(new Date(), Calendar.DAY_OF_MONTH);
				 start = DateUtils.addDays(end, -1);
			}
			List<Attempts> attempts=edepositStatusService.getDetailswithSubDateForAuthor(new java.sql.Timestamp(start.getTime()),new java.sql.Timestamp(end.getTime()),userId);
			if(!attempts.isEmpty()){
				responseData = new HashMap<String, Object>();
				responseData.put("zoneName",zoneName);
				responseData.put("selectedDate",selectedDate);
				responseData.put("refNumber", refNumber);
				responseData.put("getZonesData", attempts);
				logWriter.info("success");
				return new ModelAndView("authorZones", responseData);
			} else{
				logWriter.info("There are no records for your selection");
				responseData = new HashMap<String, Object>();
				responseData.put("zoneMessage", "There are no records for selected zone and reference");
				return new ModelAndView("authorZones", responseData);
			}
		}
		else if(!refNumber.isEmpty()&&selectedDate.isEmpty()&&zoneName.isEmpty()){
			List<Attempts> attempts= edepositStatusService.getDetailswithReference(refNumber);
			if(!attempts.isEmpty()){
				responseData = new HashMap<String, Object>();
				responseData.put("zoneName",zoneName);
				responseData.put("selectedDate",selectedDate);
				responseData.put("refNumber", refNumber);
				responseData.put("getZonesData", attempts);
				logWriter.info("success");
				return new ModelAndView("authorZones", responseData);
			} else{
				logWriter.info("There are no records for your selection");
				responseData = new HashMap<String, Object>();
				responseData.put("zoneMessage", "There are no records for selected zone and reference");
				return new ModelAndView("authorZones", responseData);
			}
		}
		else{
			logWriter.info("There are no records for your selection");
			responseData = new HashMap<String, Object>();
			//session.setAttribute("message","There are no records for your selection");
			responseData.put("zoneMessage", "There are no records for your selection");
			return new ModelAndView("authorZones", responseData);
		}}else{
			logWriter.error("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg", "Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}
	@RequestMapping(value = "/authorStatus.do",method = RequestMethod.POST)
	public ModelAndView authorStatus(HttpServletRequest request,@RequestParam String checkedValues) throws ParseException {
		//public ModelAndView updateStatus(HttpServletRequest request,@RequestParam String cityName,@RequestParam String cityCode,@RequestParam String provinceCode,@RequestParam String status) {
		logWriter.info("In /authorStatus.do authorStatus");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		session=request.getSession();
		if(session!=null && session.getAttribute("userid") != null){
			List<Attempts> list=new ArrayList<Attempts>();
			logWriter.info("userId is: "+session.getAttribute("userid"));
			String userId=(String) session.getAttribute("userid");
			int result=0;
			String currentDate = CommonUtil.getDateTime(
					new java.util.Date().getTime(), "yyyyMMdd HH:mm:ss", "EST");
			logWriter.info("currentDate" + currentDate);
			SimpleDateFormat datetimeFormatter1 = new SimpleDateFormat(
					"yyyyMMdd HH:mm:ss");
			Date lFromDate1 = datetimeFormatter1.parse(currentDate);
			System.out.println("gpsdate :" + lFromDate1);
			Timestamp fromTS1 = new Timestamp(lFromDate1.getTime());
			for(int i=0;i<checkedValues.split(",").length;i++){
				Attempts attempts=new Attempts();
				System.out.println(checkedValues.split(",")[i]);
				String fullValue= checkedValues.split(",")[i];
				String refNo = fullValue.split("#")[0];
				String status = fullValue.split("#")[1];
				attempts.setReferenceNumber(refNo);
				attempts.setStatus(status);
				attempts.setAuthStatus("Y");
				attempts.setChecker(userId);
				attempts.setCheckerDt(fromTS1);
				list.add(attempts);
				//List<String> request=new ArrayList<String>();request.add(checkedValues.split(",")[i]);
			}
			AuditLog auditLog = new AuditLog();
			auditLog.setTableName("IMCA_CITY_DETAILS_MST");
			//String obj=commonUtil.convertToJson(attempts);
			//auditLog.setRequest(obj);
			/*auditLog.setMakerCd(maker);
			auditLog.setMakerDt(makerDt);*/
			auditLog.setAuthorCd(userId);
			auditLog.setAuthorDt(fromTS1);
			try {
				result=edepositStatusService.authorStatus(list);
				auditLog.setOperation("menu authorized");
				userActionService.updateAuditLog(auditLog);
				if(result==0){
				logWriter.info("No rows Added");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "No rows Added");
				//session.setAttribute("message","No rows updated");
				return new ModelAndView("success", responseData);
			}
			else {
				logWriter.info("Status Authored successfully");
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Status Authored successfully");
				return new ModelAndView("success", responseData);
				}
			} catch (Exception e) {
				logWriter.error("Error: "+e.getMessage()+" Cause: "+e.getCause());
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Exception while Authoring Status ");
				//session.setAttribute("error_msg","Something went wrong. Please try again later");
				return new ModelAndView("error", responseData);
			}}else{
			logWriter.error("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg", "Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}
}
