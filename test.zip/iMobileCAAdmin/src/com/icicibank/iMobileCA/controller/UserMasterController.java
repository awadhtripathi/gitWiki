package com.icicibank.iMobileCA.controller;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.icicibank.iMobileCA.model.AuditLog;
import com.icicibank.iMobileCA.model.MenuItem;
import com.icicibank.iMobileCA.model.Users;
import com.icicibank.iMobileCA.service.UserActionService;
import com.icicibank.iMobileCA.service.UserMasterService;
import com.icicibank.iMobileCA.util.CommonUtil;

@Controller
public class UserMasterController {
	private static final Logger logWriter = Logger
			.getLogger(UserMasterController.class.getName());
	@Autowired
	private UserMasterService userMasterService;

	public UserMasterService getUserMasterService() {
		return userMasterService;
	}

	@Autowired
	private UserActionService userActionService;

	public UserActionService getUserActionService() {
		return userActionService;
	}

	CommonUtil commonUtil = new CommonUtil();

	/*
	 * Author : Awadh B Tripathi ID :Ban105354 Date : December 2016 Description:
	 * iMobile Canada Admin Desktop and tablet application
	 */

	/*
	 * Description : Display all user details on user Maker Home.
	 */
	@RequestMapping(value = "/getUserDetails.do")
	public ModelAndView getUserDetails(HttpServletRequest request) {
		logWriter.info("In /getUserDetails.do getUserDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		if (session != null && session.getAttribute("userid") != null) {
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("userDetails", userMasterService.getUserDetails());

			logWriter.info("success");
			return new ModelAndView("userDetails", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	/*
	 * Description : This will display all user details on user Author Home.
	 */
	@RequestMapping(value = "/getUserDetailsForAurthor.do")
	public ModelAndView getUserDetailsForAurthor(HttpServletRequest request) {
		logWriter.info("In /getUserDetails.do getUserDetailsForAurthor");
		HttpSession session = null;
		session = request.getSession(false);
		Map<String, Object> responseData = null;
		String userId = (String) session.getAttribute("userid");
		if (session != null && session.getAttribute("userid") != null) {
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("userDetailsForAuthor",
					userMasterService.getUserDetailsForAuthor(userId));
			logWriter.info("success");
			return new ModelAndView("userDetailsForAuthor", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	/*
	 * Description : For adding new User.
	 */
	@RequestMapping(value = "/addUser.do", method = RequestMethod.POST)
	public ModelAndView addUserDetails(HttpServletRequest request,
			@RequestParam String userIdentity, @RequestParam String userName,
			@RequestParam String employeeNo, @RequestParam String activeStatus,
			@RequestParam String validUpto, @RequestParam String userRole,
			@RequestParam String isAdmin, @RequestParam String disableFlage)
			throws java.text.ParseException {
		logWriter.info("In /addUser.do addUserDetails");

		HttpSession session = null;
		session = request.getSession(false);
		Users user = new Users();
		Map<String, Object> responseData = null;
		int result = 0;
		if (session != null && session.getAttribute("userid") != null) {
			String userId = (String) session.getAttribute("userid");
			user.setUserIdentity(userIdentity);
			user.setUserName(userName);
			user.setEmployeeNo(employeeNo);
			user.setUserRole(userRole);
			user.setStatus("New");
			user.setActiveStatus(activeStatus);
			user.setValidUpto((validUpto));

			user.setIsAdmin(isAdmin);
			user.setDisableFlage(disableFlage);

			user.setMaker(userId);
			user.setMakerDt(new java.sql.Timestamp(new Date().getTime()));
			// user.setReason(reason);

			try {
				result = userMasterService.saveUser(user, "add");
				if (result == 0) {
					logWriter.info("No rows Added");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "No rows Added");
					// session.setAttribute("message","No rows updated");
					return new ModelAndView("success", responseData);
				} else if (result == 2) {
					logWriter.info("No rows Added....Duplicate ID");
					responseData = new HashMap<String, Object>();
					responseData
							.put("message",
									"User with same Id already exists, duplicate cannot be created");
					// session.setAttribute("message","No rows updated");
					return new ModelAndView("success", responseData);
				} else if (result == 3) {
					logWriter.info("No rows Added....Duplicate Name");
					responseData = new HashMap<String, Object>();
					responseData
							.put("message",
									"User with same Name already exists, duplicate cannot be created");
					// session.setAttribute("message","No rows updated");
					return new ModelAndView("success", responseData);
				} else {
					logWriter.info("User added successfully");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "User added successfully");
					// session.setAttribute("message","branch added successfully");
					return new ModelAndView("success", responseData);
				}
			} catch (Exception e) {
				/*
				 * logWriter.error("Error: " + e.getMessage() + " Cause: " +
				 * e.getCause());
				 */
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Exception while adding User");
				// session.setAttribute("error_msg","Something went wrong. Please try again later");
				return new ModelAndView("error", responseData);
			}
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	/*
	 * Description : For Updating the user Details.
	 */
	@RequestMapping(value = "/updateUser.do", method = RequestMethod.POST)
	public ModelAndView updateUserDetails(HttpServletRequest request,
			@RequestParam String userIdentity, @RequestParam String userName,
			@RequestParam String employeeNo, @RequestParam String userRole,
			@RequestParam String status, @RequestParam String activeStatus,
			@RequestParam String validUpto, @RequestParam String isAdmin,
			@RequestParam String disableFlage) throws java.text.ParseException {
		logWriter.info("In /updateUser.do updateUserDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Users user = new Users();
		Map<String, Object> responseData = null;
		if (session != null && session.getAttribute("userid") != null) {
			logWriter.info("userId is: " + session.getAttribute("userid"));
			String userId = (String) session.getAttribute("userid");
			int result = 0;
			user.setUserIdentity(userIdentity);
			user.setUserName(userName);
			user.setStatus(status);
			user.setEmployeeNo(employeeNo);
			user.setUserRole(userRole);
			user.setActiveStatus(activeStatus);
			user.setValidUpto(validUpto);
			user.setIsAdmin(isAdmin);
			user.setDisableFlage(disableFlage);
			user.setMaker(userId);
			user.setMakerDt(new java.sql.Timestamp(new Date().getTime()));
			try {
				result = userMasterService.saveUser(user, "Modified");
				if (result == 0) {
					logWriter.info("No rows updated");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "No rows updated");
					// session.setAttribute("message","No rows updated");
					return new ModelAndView("success", responseData);
				} else {
					logWriter.info("user updated successfully");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "user updated successfully");
					// session.setAttribute("message","user added successfully");
					return new ModelAndView("success", responseData);
				}
			} catch (Exception e) {
				// logWriter.error("Error: "+e.getMessage()+" Cause: "+e.getCause());
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Exception while updating user");
				// session.setAttribute("error_msg","Something went wrong. Please try again later");
				return new ModelAndView("error", responseData);
			}
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	/*
	 * Description : For deleting the user.
	 */
	@RequestMapping(value = "/deleteUser.do", method = RequestMethod.GET)
	public ModelAndView deleteUserDetails(HttpServletRequest request,
			@RequestParam String userName, @RequestParam String userIdentity,
			@RequestParam String employeeNo, @RequestParam String status,
			@RequestParam String activeStatus, @RequestParam String validUpto,
			@RequestParam String userRole, @RequestParam String isAdmin,
			@RequestParam String disableFlage) throws java.text.ParseException {
		logWriter.info("In /deleteuser.do deleteuserDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Users user = new Users();
		Map<String, Object> responseData = null;
		int result = 0;
		if (session != null && session.getAttribute("userid") != null) {
			String userId = (String) session.getAttribute("userid");
			user.setUserIdentity(userIdentity);
			user.setUserName(userName);
			user.setEmployeeNo(employeeNo);
			user.setUserRole(userRole);
			user.setActiveStatus(activeStatus);
			user.setValidUpto(validUpto);
			user.setStatus(status);
			user.setIsAdmin(isAdmin);
			user.setDisableFlage(disableFlage);
			user.setMaker(userId);
			user.setMakerDt(new java.sql.Timestamp(new Date().getTime()));

			try {
				result = userMasterService.saveUser(user, "delete");
				if (result == 0) {
					logWriter.info("No rows deleted");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "No rows deleted");
					// session.setAttribute("message","No rows updated");
					return new ModelAndView("success", responseData);
				} else {
					logWriter.info("user deleted successfully");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "user deleted successfully");
					// session.setAttribute("message","user added successfully");
					return new ModelAndView("success", responseData);
				}
			} catch (Exception e) {
				// logWriter.error("Error: "+e.getMessage()+" Cause: "+e.getCause());
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Exception while deleting user");
				// session.setAttribute("error_msg","Something went wrong. Please try again later");
				return new ModelAndView("error", responseData);
			}
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	/*
	 * Description : Search users for Maker.
	 */
	@RequestMapping(value = "/searchUser.do", method = RequestMethod.GET)
	public ModelAndView searchUserDetails(HttpServletRequest request,
			@RequestParam String userIdentity, @RequestParam String userName,
			@RequestParam String status) {
		logWriter.info("In /searchuser.do searchUserDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Users user = new Users();
		Map<String, Object> responseData = null;
		user.setUserIdentity(userIdentity);
		user.setUserName(userName);
		user.setStatus(status);

		if (session != null && session.getAttribute("userid") != null) {
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("userDetails", userMasterService.searchUser(user));
			logWriter.info("success");
			return new ModelAndView("userDetails", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	/*
	 * Description : Search users for Author Home.
	 */
	@RequestMapping(value = "/searchForAuthor.do", method = RequestMethod.GET)
	public ModelAndView searchForAuthor(HttpServletRequest request,
			@RequestParam String userIdentity, @RequestParam String userName,
			@RequestParam String status) {
		logWriter.info("In /searchuser.do searchUserDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Users user = new Users();
		Map<String, Object> responseData = null;
		user.setUserIdentity(userIdentity);
		user.setUserName(userName);
		user.setStatus(status);

		if (session != null && session.getAttribute("userid") != null) {
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			List<Users> list = userMasterService.searchUser(user);
			List<Users> list1 = new ArrayList<Users>(list);
			for (Users users : list1) {
				if (users.getMaker().equals(session.getAttribute("userid"))
						|| users.getStatus().equals("Rejected")
						|| users.getStatus().equals("Authorized")
						|| users.getStatus().equals("Deleted and Authorized"))
					list.remove(users);
			}

			responseData.put("userDetailsForAuthor", list);
			logWriter.info("success");
			return new ModelAndView("userDetailsForAuthor", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	/*
	 * Description : Search users for Maintenance.
	 */
	@RequestMapping(value = "/searchForMaintenance.do", method = RequestMethod.GET)
	public ModelAndView searchForMaintenance(HttpServletRequest request,
			@RequestParam String userIdentity, @RequestParam String userName,
			@RequestParam String status) {
		logWriter.info("In /searchuser.do searchUserDetails");
		HttpSession session = null;
		session = request.getSession(false);
		Users user = new Users();
		Map<String, Object> responseData = null;
		user.setUserIdentity(userIdentity);
		user.setUserName(userName);
		user.setStatus(status);

		if (session != null && session.getAttribute("userid") != null) {
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			List<Users> list = userMasterService.searchUser(user);
			List<Users> list1 = new ArrayList<Users>(list);
			for (Users users : list1) {
				if (users.getMaker().equals(session.getAttribute("userid"))
						|| users.getStatus().equals("Rejected")
						|| users.getStatus().equals("Deleted and Authorized"))
					list.remove(users);
			}

			responseData.put("userDetails", list);
			logWriter.info("success");
			return new ModelAndView("userDetailsForMaintenance", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	/*
	 * @RequestMapping(value = "/viewUser.do", method = RequestMethod.GET)
	 * public ModelAndView viewUserDeatils(HttpServletRequest request,
	 * 
	 * @RequestParam String userIdentity, @RequestParam String status) throws
	 * ParseException { logWriter.info("In /viewUser.do viewUserDetails");
	 * HttpSession session = null; session = request.getSession(false); Users
	 * user = new Users(); Map<String, Object> responseData = null;
	 * logWriter.info("userId is: " + session.getAttribute("userid"));
	 * user.setUserIdentity(userIdentity); user.setStatus(status); if
	 * (session.getAttribute("userid") != null) { responseData = new
	 * HashMap<String, Object>(); responseData.put("message", "Success");
	 * responseData.put("userName", session.getAttribute("user"));
	 * responseData.put("viewUser", userMasterService.viewUser(user)); //
	 * responseData.put("provinceList", //
	 * provinceMasterService.getProvinceDetails()); logWriter.info("success");
	 * return new ModelAndView("viewUser", responseData); } else {
	 * logWriter.info("Session Expired..."); responseData = new HashMap<String,
	 * Object>(); session.setAttribute("error_msg",
	 * "Session Expired... Please Login Again"); responseData.put("error_msg",
	 * "Session Expired... Please Login Again"); return new
	 * ModelAndView("Error", responseData); } }
	 */

	/*
	 * @RequestMapping(value = "/viewUserDetailsForUpdate.do", method =
	 * RequestMethod.GET) public ModelAndView
	 * viewUserDeatilsForUpdate(HttpServletRequest request,
	 * 
	 * @RequestParam String userIdentity, @RequestParam String status) throws
	 * ParseException { logWriter.info("In /viewUser.do viewUserDetails");
	 * HttpSession session = null; session = request.getSession(false); Users
	 * user = new Users(); Map<String, Object> responseData = null;
	 * logWriter.info("userId is: " + session.getAttribute("userid"));
	 * user.setUserIdentity(userIdentity); user.setStatus(status); if
	 * (session.getAttribute("userid") != null) { responseData = new
	 * HashMap<String, Object>(); responseData.put("message", "Success");
	 * responseData.put("userName", session.getAttribute("user"));
	 * responseData.put("editUser", userMasterService.viewUser(user));
	 * logWriter.info("success"); return new ModelAndView("editUser",
	 * responseData); } else { logWriter.info("Session Expired...");
	 * responseData = new HashMap<String, Object>();
	 * session.setAttribute("error_msg",
	 * "Session Expired... Please Login Again"); responseData.put("error_msg",
	 * "Session Expired... Please Login Again"); return new
	 * ModelAndView("Error", responseData); } }
	 */

	/*
	 * Description : Authorize or Reject user by Author.
	 */
	@RequestMapping(value = "/authorOrRejectUser.do", method = RequestMethod.GET)
	public ModelAndView authorOrRejectUser(HttpServletRequest request,
			@RequestParam String userIdentity, @RequestParam String userName,
			@RequestParam String employeeNo, @RequestParam String userRole,
			@RequestParam String activeStatus, @RequestParam String validUpto,
			@RequestParam String isAdmin, @RequestParam String disableFlage,
			String status, @RequestParam String maker,
			@RequestParam String flag, @RequestParam Timestamp makerDt)
			throws ParseException {

		HttpSession session = null;
		session = request.getSession(false);
		Users user = new Users();
		Map<String, Object> responseData = null;
		if (session != null && session.getAttribute("userid") != null) {
			logWriter.info("userId is: " + session.getAttribute("userid"));
			String userId = (String) session.getAttribute("userid");
			user.setUserIdentity(userIdentity);
			user.setUserName(userName);
			user.setEmployeeNo(employeeNo);
			user.setUserRole(userRole);
			user.setActiveStatus(activeStatus);
			user.setValidUpto(validUpto);
			user.setStatus(status);
			user.setIsAdmin(isAdmin);
			user.setMaker(maker);
			user.setMakerDt(makerDt);
			user.setDisableFlage(disableFlage);
			user.setChecker(userId);
			// user.setCheckerDt(new java.sql.Timestamp(new Date().getTime()));
			String currentDate = CommonUtil.getDateTime(
					new java.util.Date().getTime(), "yyyyMMdd HH:mm:ss", "EST");
			logWriter.info("currentDate" + currentDate);
			SimpleDateFormat datetimeFormatter1 = new SimpleDateFormat(
					"yyyyMMdd HH:mm:ss");
			Date lFromDate1 = datetimeFormatter1.parse(currentDate);
			System.out.println("gpsdate :" + lFromDate1);
			Timestamp fromTS1 = new Timestamp(lFromDate1.getTime());
			user.setCheckerDt(fromTS1);
			AuditLog auditLog = new AuditLog();
			auditLog.setTableName("IMCA_USER_DETAILS");
			String obj = commonUtil.convertToJson(user);
			auditLog.setRequest(obj);
			auditLog.setMakerCd(maker);
			auditLog.setMakerDt(makerDt);
			auditLog.setAuthorCd(userId);
			auditLog.setAuthorDt(fromTS1);
			/*
			 * user.setMaker(userId); user.setMakerDt(new java.sql.Timestamp(new
			 * Date().getTime()));
			 */
			if (flag.equals("1")) {
				logWriter.info("In /authorMenu.do authorMenu");
				logWriter.info("In /authorUser.do authorUser");
				int result = 0;

				try {
					result = userMasterService.authorUser(user);
					auditLog.setOperation("user authorized");
					userActionService.updateAuditLog(auditLog);
					if (result == 0) {
						logWriter.info("No rows updated");
						responseData = new HashMap<String, Object>();
						responseData.put("message", "No rows updated ");
						return new ModelAndView("success", responseData);
					} else {
						logWriter.info("user authorise successfully");
						responseData = new HashMap<String, Object>();
						responseData.put("message",
								"user authorise successfully");
						// session.setAttribute("message","user added successfully");
						return new ModelAndView("success", responseData);
					}
				} catch (Exception e) {
					// logWriter.error("Error: "+e.getMessage()+" Cause: "+e.getCause());
					responseData = new HashMap<String, Object>();
					responseData.put("message",
							"Exception while athorising user");
					// session.setAttribute("error_msg","Something went wrong. Please try again later");
					return new ModelAndView("error", responseData);
				}

			} else if (flag.equals("2")) {
				logWriter.info("In /rejectUser.do rejectUser");
				int result = 0;
				/*
				 * user.setUserIdentity(userIdentity);
				 * user.setUserName(userName); user.setEmployeeNo(employeeNo);
				 * user.setUserRole(userRole);
				 * user.setActiveStatus(activeStatus);
				 * user.setValidUpto(validUpto); user.setStatus(status);
				 * user.setIsAdmin(isAdmin); user.setMaker(maker);
				 * user.setMakerDt(makerDt); user.setDisableFlage(disableFlage);
				 * user.setChecker(userId); user.setCheckerDt(new
				 * java.sql.Timestamp(new Date().getTime()));
				 */
				try {
					result = userMasterService.saveUser(user, "Reject");
					auditLog.setOperation("user rejected");
					userActionService.updateAuditLog(auditLog);
					if (result == 0) {
						logWriter.info("No rows updated");
						responseData = new HashMap<String, Object>();
						responseData.put("message", "No rows updated");
						// session.setAttribute("message","No rows updated");
						return new ModelAndView("success", responseData);
					} else {
						logWriter.info("user rejected successfully");
						responseData = new HashMap<String, Object>();
						responseData.put("message",
								"user Rejected successfully");
						// session.setAttribute("message","user added successfully");
						return new ModelAndView("success", responseData);
					}
				} catch (Exception e) {
					// logWriter.error("Error: "+e.getMessage()+" Cause: "+e.getCause());
					responseData = new HashMap<String, Object>();
					responseData.put("message",
							"Exception while rejecting user");
					// session.setAttribute("error_msg","Something went wrong. Please try again later");
					return new ModelAndView("error", responseData);
				}
			}
			responseData = new HashMap<String, Object>();
			responseData.put("message", "No rows Added");
			return new ModelAndView("success", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	/*
	 * @RequestMapping(value = "/viewUserForAuthor.do", method =
	 * RequestMethod.GET) public ModelAndView
	 * viewUserForAuthor(HttpServletRequest request,
	 * 
	 * @RequestParam String userIdentity, @RequestParam String status) throws
	 * ParseException {
	 * logWriter.info("In /viewUserForAuthor.do viewUserDetails"); HttpSession
	 * session = null; session = request.getSession(false); Users user = new
	 * Users();
	 * 
	 * Map<String, Object> responseData = null; logWriter.info("userId is: " +
	 * session.getAttribute("userid")); user.setUserIdentity(userIdentity);
	 * user.setStatus(status); if(session!=null &&
	 * session.getAttribute("userid") != null){ responseData = new
	 * HashMap<String, Object>(); responseData.put("message", "Success");
	 * responseData.put("userName", session.getAttribute("user"));
	 * responseData.put("viewUserForAuthor", userMasterService.viewUser(user));
	 * // responseData.put("provinceList", //
	 * provinceMasterService.getProvinceDetails()); logWriter.info("success");
	 * return new ModelAndView("viewUserForAuthor", responseData); } else {
	 * logWriter.info("Session Expired..."); responseData = new HashMap<String,
	 * Object>(); session.setAttribute("error_msg",
	 * "Session Expired... Please Login Again"); responseData.put("error_msg",
	 * "Session Expired... Please Login Again"); return new
	 * ModelAndView("Error", responseData); } }
	 */
	/*
	 * Description : Loads users for Maintenance Home.
	 */
	@RequestMapping(value = "/getUserDetailsForMaintenance.do")
	public ModelAndView getUserDetailsForMaintenance(HttpServletRequest request) {
		logWriter.info("In /getUserDetails.do getUserDetailsForMaintenance");
		HttpSession session = null;
		session = request.getSession(false);
		String userId = (String) session.getAttribute("userid");
		Map<String, Object> responseData = null;
		if (session != null && session.getAttribute("userid") != null) {
			responseData = new HashMap<String, Object>();
			responseData.put("message", "Success");
			responseData.put("userName", session.getAttribute("user"));
			responseData.put("userDetails",
					userMasterService.getUserDetailsForMaintenance(userId));
			logWriter.info("success");
			return new ModelAndView("userDetailsForMaintenance", responseData);
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

	/*
	 * // For maintenance Module
	 * 
	 * @RequestMapping(value = "/viewUserForUpdate.do", method =
	 * RequestMethod.GET) public ModelAndView
	 * viewUserForUpdate(HttpServletRequest request,
	 * 
	 * @RequestParam String userIdentity) {
	 * logWriter.info("In /viewUser.do viewUserForUpdate"); HttpSession session
	 * = null; session = request.getSession(false); Users user = new Users();
	 * Map<String, Object> responseData = null; logWriter.info("userId is: " +
	 * session.getAttribute("userid")); user.setUserIdentity(userIdentity); if
	 * (session.getAttribute("userid") != null) { responseData = new
	 * HashMap<String, Object>(); responseData.put("message", "Success");
	 * responseData.put("userName", session.getAttribute("user"));
	 * responseData.put("updateMaintenance",
	 * userMasterService.viewUserForMaintenance(user)); //
	 * responseData.put("provinceList", //
	 * provinceMasterService.getProvinceDetails()); logWriter.info("success");
	 * return new ModelAndView("updateMaintenance", responseData); } else {
	 * logWriter.info("Session Expired..."); responseData = new HashMap<String,
	 * Object>(); session.setAttribute("error_msg",
	 * "Session Expired... Please Login Again"); responseData.put("error_msg",
	 * "Session Expired... Please Login Again"); return new
	 * ModelAndView("Error", responseData); } }
	 */
	/*
	 * Description : For enable/disable user in Maintenance.
	 */
	@RequestMapping(value = "/updateMaintenanceUser.do", method = RequestMethod.POST)
	public ModelAndView updateMaintenance(HttpServletRequest request,
			@RequestParam String userIdentity, @RequestParam String disableFlage) {
		logWriter.info("In /UpdateUser.do UpdateMaintenance");
		HttpSession session = null;
		session = request.getSession(false);
		Users user = new Users();
		Map<String, Object> responseData = null;
		if (session != null && session.getAttribute("userid") != null) {
			logWriter.info("userId is: " + session.getAttribute("userid"));
			int result = 0;
			user.setUserIdentity(userIdentity);
			user.setDisableFlage(disableFlage);
			try {
				result = userMasterService.updateForMaintenance(user);
				if (result == 0) {
					logWriter.info("No rows updated");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "No rows updated");
					return new ModelAndView("success", responseData);
				} else {
					logWriter.info("user Updated successfully");
					responseData = new HashMap<String, Object>();
					responseData.put("message", "user updated successfully");
					return new ModelAndView("success", responseData);
				}
			} catch (Exception e) {
				responseData = new HashMap<String, Object>();
				responseData.put("message", "Exception while updatinguser");
				return new ModelAndView("authorFailure", responseData);
			}
		} else {
			logWriter.info("Session Expired...");
			responseData = new HashMap<String, Object>();
			responseData.put("error_msg",
					"Session Expired... Please Login Again");
			return new ModelAndView("authorFailure", responseData);
		}
	}

}
