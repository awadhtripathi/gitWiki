package com.icicibank.iMobileCA.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.hibernate.transaction.WebSphereExtendedJTATransactionLookup.TransactionManagerAdapter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.annotation.Transactional;

import com.icicibank.iMobileCA.model.Cities;
import com.icicibank.iMobileCA.model.Scheme;

public class CityMasterDAO {
	@Autowired
	JdbcTemplate jdbcTemplate;
	@Autowired
	DataSourceTransactionManager transactionManager;
	private static final Logger logWriter = Logger
			.getLogger(CityMasterDAO.class.getName());

	@Resource(name = "imbcaproperties")
	private Properties imbcaproperties;
	@Autowired
	private BranchMasterDAO branchMasterDAO;

	public void setBranchMasterDAO(BranchMasterDAO branchMasterDAO) {
		this.branchMasterDAO = branchMasterDAO;
	}

	public List<Cities> getCityDetails() {
		List<Cities> transObjList = new ArrayList<Cities>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETCITYDETAILS"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString());
			logWriter.info("CITYDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for CITYDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Cities cities = new Cities();
				cities.setCityName((String) row.get("CITY_NAME"));
				cities.setProvinceCode((String) row.get("PROVINCE_CODE"));
				cities.setPinCode((String) row.get("PINCODE"));
				cities.setActive((String) row.get("ACTIVE"));
				cities.setMaker((String) row.get("MAKER"));
				cities.setMakerDt((Timestamp) row.get("MAKER_DT"));
				cities.setChecker((String) row.get("CHECKER"));
				cities.setCheckerDt((Timestamp) row.get("CHECKER_DT"));
				cities.setReason((String) row.get("REASON"));
				cities.setCityCode((String) row.get("CITY_CODE"));
				cities.setLatitude((String) row.get("LATITUDE"));
				cities.setLongitude((String) row.get("LONGITUDE"));
				cities.setStatus((String) row.get("STATUS"));
				cities.setBranchCount(branchMasterDAO
						.getNoOfBranches((String) row.get("CITY_CODE")));
				transObjList.add(cities);
			}
		}
		return transObjList;
	}

	public int getNoOfCities(String provinceCode) {
		int count = 0;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETCITYDETAILSWITHPROVINCE"));
		try {
			count = jdbcTemplate.queryForObject(sql.toString(),
					new Object[] { provinceCode }, Integer.class);
			logWriter.info("branchDETAILS size:  " + count);
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for branchDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		return count;
	}

	public List<Cities> getCitiesWithProvince(String provinceCode) {
		List<Cities> transObjList = new ArrayList<Cities>();
		StringBuilder sql = new StringBuilder();
		List<Map<String, Object>> fieldNames = null;
		sql.append(imbcaproperties.get("GETCITIESWITHPROVINCE"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),
					new Object[] { provinceCode, "Authorized" });
			logWriter.info("cityDETAILS size:  " + transObjList.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for cityDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Cities cities = new Cities();
				cities.setCityName((String) row.get("CITY_CODE"));
				transObjList.add(cities);
			}
		}
		return transObjList;
	}

	public List<Cities> getCityDetailsForAuthoring(String userId) {
		List<Cities> transObjList = new ArrayList<Cities>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETCITYDETAILSFORAUTHOR"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),
					new Object[] { userId });
			logWriter.info("CITYDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for CITYDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				if (!row.get("STATUS").equals("Authorized")
						&& !row.get("STATUS").equals("Rejected")
						&& !row.get("STATUS").equals("Deleted and Authorized")) {
					Cities cities = new Cities();
					cities.setCityName((String) row.get("CITY_NAME"));
					cities.setProvinceCode((String) row.get("PROVINCE_CODE"));
					cities.setPinCode((String) row.get("PINCODE"));
					cities.setActive((String) row.get("ACTIVE"));
					cities.setMaker((String) row.get("MAKER"));
					cities.setMakerDt((Timestamp) row.get("MAKER_DT"));
					cities.setChecker((String) row.get("CHECKER"));
					cities.setCheckerDt((Timestamp) row.get("CHECKER_DT"));
					cities.setReason((String) row.get("REASON"));
					cities.setCityCode((String) row.get("CITY_CODE"));
					cities.setLatitude((String) row.get("LATITUDE"));
					cities.setLongitude((String) row.get("LONGITUDE"));
					cities.setStatus((String) row.get("STATUS"));
					transObjList.add(cities);
				}
			}
		}
		return transObjList;
	}

	public List<Cities> searchCity(Cities city) {
		List<Cities> cityList = new ArrayList<Cities>();
		List<Cities> citySearchList = new ArrayList<Cities>();
		cityList = getCityDetails();
		try {
			if ((city.getCityCode().equals("") || city.getCityCode().equals(
					null))
					&& city.getCityName().equals("")
					|| city.getCityName().equals(null)) { // no
				if (city.getStatus().equals("All"))
					return cityList;

				else if (city.getStatus().equals("Authorized")) {
					for (Cities item : cityList) {
						if (item.getStatus().equals(city.getStatus()))
							citySearchList.add(item);
					}
					return citySearchList;
				} else if (city.getStatus().equals("Deleted and Authorized")) {
					for (Cities item : cityList) {
						if (item.getStatus().equals(city.getStatus()))
							citySearchList.add(item);
					}
					return citySearchList;
				} else if (city.getStatus().equals("Deleted")) {
					for (Cities item : cityList) {
						if (item.getStatus().equals(city.getStatus()))
							citySearchList.add(item);
					}
					return citySearchList;
				}

				else {
					for (Cities item : cityList) {
						if (item.getStatus().contains(city.getStatus()))
							citySearchList.add(item);
					}
					return citySearchList;
				}
			} else if (city.getCityCode().equals("") // no ID
					|| city.getCityCode().equals(null)) {
				for (Cities item : cityList) {
					if (item.getCityName().toLowerCase()
							.contains(city.getCityName().toLowerCase())) {
						if (item.getStatus().contains(city.getStatus())
								|| city.getStatus().equals("All")) {
							citySearchList.add(item);
						}
					}
				}
			} else if (city.getCityName().equals("") // no name
					|| city.getCityName().equals(null)) {
				for (Cities item : cityList) {
					if (item.getCityCode().toLowerCase()
							.contains(city.getCityCode().toLowerCase())) {
						if (item.getStatus().contains(city.getStatus())
								|| city.getStatus().equals("All")) {
							citySearchList.add(item);
						}
					}
				}
			} else {
				for (Cities item : cityList) { // both present
					if (item.getCityName().toLowerCase()
							.contains(city.getCityName().toLowerCase())
							&& item.getCityCode().toLowerCase()
									.contains(city.getCityCode().toLowerCase())) {
						if (item.getStatus().contains(city.getStatus())
								|| city.getStatus().equals("All")) {
							citySearchList.add(item);
						}
					}
				}
			}
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for cityList account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		return citySearchList;
	}

	public int addCity(Cities city, String param) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("ADDCITY"));
		Integer count = 0;
		try {
			if (city.getStatus().equals("New") && param.equals("add")) {
				List<Cities> citys = getCityDetails();
				for (Cities Cities : citys) {
					if (Cities.getCityCode().equals(city.getCityCode())) {
						count = 2;
						return (int) count;
					}
					if (Cities.getCityName().equals(city.getCityName())) {
						count = 3;
						return (int) count;
					}
				}
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { city.getCityCode(), city.getCityName(),
								city.getProvinceCode(), city.getMaker(),
								city.getMakerDt(), city.getStatus(),
								city.getActive() });
			} else if (city.getStatus().equals("Authorized")
					&& param.equals("Modified")) {
				count = jdbcTemplate
						.update(sql.toString(),
								new Object[] { city.getCityCode(),
										city.getCityName(),
										city.getProvinceCode(),
										city.getMaker(), city.getMakerDt(),
										"Modified", city.getActive() });
			} else if (city.getStatus().equals("Authorized")
					&& param.equals("delete")) {
				count = jdbcTemplate
						.update(sql.toString(),
								new Object[] { city.getCityCode(),
										city.getCityName(),
										city.getProvinceCode(),
										city.getMaker(), city.getMakerDt(),
										"Deleted", city.getActive() });
			} else if (param.equals("Reject")) {
				int cityCount = rejectCityCount(city.getCityCode());
				if (cityCount > 0) {
					city.setStatus("Rejected");
					deleteCity(city);
				}
				count = jdbcTemplate
						.update(sql.toString(),
								new Object[] { city.getCityCode(),
										city.getCityName(),
										city.getProvinceCode(),
										city.getMaker(), city.getMakerDt(),
										"Rejected", city.getActive() });
				deleteCity(city);
			}
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	@Transactional
	public int authorCity(Cities item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("AUTHORCITY"));
		/*
		 * This is for iMobile channel table
		 */
		StringBuilder sql1 = new StringBuilder();
		sql1.append(imbcaproperties.get("ADDCITYFORCHNL"));
		Integer count = 0;
		try {
			if (item.getStatus().equals("New")) {
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { item.getCityName(), item.getChecker(),
								item.getCheckerDt(), "Authorized", "Y",
								item.getCityCode() });
				/*
				 * This is for iMobile channel table
				 */
				count = jdbcTemplate.update(
						sql1.toString(),
						new Object[] { item.getCityCode(), item.getCityName(),
								item.getProvinceCode(), item.getMaker(),
								item.getMakerDt(), item.getChecker(),
								item.getCheckerDt(), "Authorized", "Y" });

			} else if (item.getStatus().equals("Modified")) {
				count = updateCity(item);
				if (count == 1) {
					count = deleteCity(item);
				}
			} else if (item.getStatus().equals("Deleted")) {
				Cities item2 = new Cities();
				item2.setCityCode(item.getCityCode());
				item2.setChecker(item.getChecker());
				item2.setCheckerDt(item.getCheckerDt());
				count = deleteCity(item);
				count = changeStatus(item2);
			}
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
			transactionManager.rollback(null);
		} catch (Exception e) {
			logWriter.info("error" + e);
			transactionManager.rollback(null);
		}
		return (int) count;
	}

	private Integer changeStatus(Cities item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("CHANGECITYSTATUS"));
		// ------------------------This is for iMobileChannerl Table
		StringBuilder sql1 = new StringBuilder();
		sql1.append(imbcaproperties.get("CHANGECITYSTATUSFORCHNL"));
		// --------------------------------------------------
		Integer count = 0;
		try {
			count = jdbcTemplate.update(
					sql.toString(),
					new Object[] { "N", "Deleted and Authorized",
							item.getChecker(), item.getCheckerDt(),
							item.getCityCode() });
			// ------------------------This is for iMobileChannerl Table
			count = jdbcTemplate.update(
					sql1.toString(),
					new Object[] { "N", "Deleted and Authorized",
							item.getChecker(), item.getCheckerDt(),
							item.getCityCode() });
			// --------------------------------------------------
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("getting deleted count failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public int rejectCityCount(String cityCode) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETREJECTEDCITY"));
		Integer count = 0;
		try {
			count = jdbcTemplate.queryForObject(sql.toString(), new Object[] {
					cityCode, "Rejected" }, Integer.class);
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("getting rejected count failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public int rejectCity(Cities city) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("REJECTCITY"));
		// INSERT INTO IMCA_CITY_DETAILS_MST
		// (CITY_CODE,CITY_NAME,PROVINCE_CODE,MAKER,MAKER_DT,CHECKER,CHECKER_DT,STATUS)
		// VALUES(?,?,?,?,?,?,?,?)
		Integer count = 0;
		try {
			int cityCount = rejectCityCount(city.getCityCode());
			if (cityCount > 0) {
				String status = city.getStatus();
				city.setStatus("Rejected");
				deleteCity(city);
				city.setStatus(status);
			}
			count = jdbcTemplate.update(
					sql.toString(),
					new Object[] { city.getCityCode(), city.getCityName(),
							city.getProvinceCode(), city.getMaker(),
							city.getMakerDt(), city.getChecker(),
							city.getCheckerDt(), "Rejected" });
			deleteCity(city);
			// count = jdbcTemplate.update(sql.toString(), new Object[] {
			// city.getCityName(),city.getProvinceCode(),city.getChecker(),city.getCheckerDt(),"Rejected",city.getCityCode()});
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	@Transactional
	public int updateCity(Cities item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("UPDATECITY"));
		Integer count = 0;
		// This will update scheme into iMobile Channel db.
		StringBuilder sql1 = new StringBuilder();
		sql1.append(imbcaproperties.get("UPDATECITYFORCHNL"));
		try {
			if (item.getStatus().equals("Modified")) {

				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { item.getMaker(), item.getMakerDt(),
								"Authorized", item.getChecker(),
								item.getCheckerDt(), "Y", item.getCityName(),
								item.getCityCode(), "Authorized" });
				/*
				 * This will update scheme into iMobile Channel db.
				 */
				count = jdbcTemplate.update(
						sql1.toString(),
						new Object[] { item.getMaker(), item.getMakerDt(),
								"Authorized", item.getChecker(),
								item.getCheckerDt(), "Y", item.getCityName(),
								item.getCityCode() });
			}
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
			transactionManager.rollback(null);
		} catch (Exception e) {
			logWriter.info("error" + e);
			transactionManager.rollback(null);
		}
		return (int) count;
	}

	public Cities viewCity(String cityCode, String status) {
		Cities cities = new Cities();
		Map<String, Object> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("VIEWCITY"));
		try {
			fieldNames = jdbcTemplate.queryForMap(sql.toString(), new Object[] {
					cityCode, status });
			logWriter.info("CITYDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for CITYDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (!fieldNames.isEmpty()) {
			cities.setCityName((String) fieldNames.get("CITY_NAME"));
			cities.setProvinceCode((String) fieldNames.get("PROVINCE_CODE"));
			cities.setPinCode((String) fieldNames.get("PINCODE"));
			cities.setActive((String) fieldNames.get("ACTIVE"));
			cities.setMaker((String) fieldNames.get("MAKER"));
			cities.setMakerDt((Timestamp) fieldNames.get("MAKER_DT"));
			cities.setChecker((String) fieldNames.get("CHECKER"));
			cities.setCheckerDt((Timestamp) fieldNames.get("CHECKER_DT"));
			cities.setReason((String) fieldNames.get("REASON"));
			cities.setCityCode((String) fieldNames.get("CITY_CODE"));
			cities.setLatitude((String) fieldNames.get("LATITUDE"));
			cities.setLongitude((String) fieldNames.get("LONGITUDE"));
			cities.setStatus((String) fieldNames.get("STATUS"));
		}
		return cities;
	}

	public int deleteCity(Cities city) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("DELETECITY"));
		Integer count = 0;
		try {
			count = jdbcTemplate.update(sql.toString(),
					new Object[] { city.getCityCode(), city.getStatus() });
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("deletion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}
}
