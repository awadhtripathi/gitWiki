package com.icicibank.iMobileCA.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.icicibank.iMobileCA.model.Province;
import com.icicibank.iMobileCA.model.Scheme;

@Repository
public class ProvinceMasterDAO {
	@Autowired
	JdbcTemplate jdbcTemplate;
	private static final Logger logWriter = Logger
			.getLogger(ProvinceMasterDAO.class.getName());

	@Resource(name = "imbcaproperties")
	private Properties imbcaproperties;
	@Autowired
	private CityMasterDAO cityMasterDAO;
	@Autowired
	DataSourceTransactionManager transactionManager;

	public void setCityMasterDAO(CityMasterDAO cityMasterDAO) {
		this.cityMasterDAO = cityMasterDAO;
	}

	public List<Province> getProvinceDetails() {
		List<Province> transObjList = new ArrayList<Province>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETPROVINCEDETAILS"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString());
			logWriter.info("PROVINCEDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for ProvinceDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Province province = new Province();
				province.setProvinceName((String) row.get("PROVINCE_NAME"));
				province.setProvinceCode((String) row.get("PROVINCE_CODE"));
				province.setActive((String) row.get("ACTIVE"));
				province.setMaker((String) row.get("MAKER"));
				province.setMakerDt((Timestamp) row.get("MAKER_DT"));
				province.setChecker((String) row.get("CHECKER"));
				province.setCheckerDt((Timestamp) row.get("CHECKER_DT"));
				province.setReason((String) row.get("REASON"));
				province.setStatus((String) row.get("STATUS"));
				province.setCityCount(cityMasterDAO.getNoOfCities((String) row
						.get("PROVINCE_CODE")));
				transObjList.add(province);
			}
		}
		return transObjList;
	}

	public List<Province> getAuthorizedProvinceDetails() {
		List<Province> transObjList = new ArrayList<Province>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETAUTHORIZEDPROVINCEDETAILS"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),
					new Object[] { "Authorized" });
			logWriter.info("PROVINCEDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for PROVINCEDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Province province = new Province();
				province.setProvinceCode((String) row.get("PROVINCE_CODE"));
				transObjList.add(province);
			}
		}
		return transObjList;
	}

	public Province viewProvince(String provinceCode, String status) {
		Province province = new Province();
		Map<String, Object> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("VIEWPROVINCE"));
		try {
			fieldNames = jdbcTemplate.queryForMap(sql.toString(), new Object[] {
					provinceCode, status });
			logWriter.info("menuDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for menuDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			province.setProvinceName((String) fieldNames.get("PROVINCE_NAME"));
			province.setProvinceCode((String) fieldNames.get("PROVINCE_CODE"));
			province.setActive((String) fieldNames.get("ACTIVE"));
			province.setMaker((String) fieldNames.get("MAKER"));
			province.setMakerDt((Timestamp) fieldNames.get("MAKER_DT"));
			province.setChecker((String) fieldNames.get("CHECKER"));
			province.setCheckerDt((Timestamp) fieldNames.get("CHECKER_DT"));
			province.setReason((String) fieldNames.get("REASON"));
			province.setStatus((String) fieldNames.get("STATUS"));
		}
		return province;
	}

	public List<Province> getProvinceDetailsForAuthoring(String userId) {
		List<Province> transObjList = new ArrayList<Province>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETPROVINCEDETAILSFORAUTHOR"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),
					new Object[] { userId });
			logWriter.info("CITYDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for CITYDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				if (!row.get("STATUS").equals("Authorized")
						&& !row.get("STATUS").equals("Rejected")
						&& !row.get("STATUS").equals("Deleted and Authorized")) {
					Province province = new Province();
					province.setProvinceName((String) row.get("PROVINCE_NAME"));
					province.setProvinceCode((String) row.get("PROVINCE_CODE"));
					province.setActive((String) row.get("ACTIVE"));
					province.setStatus((String) row.get("STATUS"));
					province.setMaker((String) row.get("MAKER"));
					province.setMakerDt((Timestamp) row.get("MAKER_DT"));
					province.setChecker((String) row.get("CHECKER"));
					province.setCheckerDt((Timestamp) row.get("CHECKER_DT"));
					province.setReason((String) row.get("REASON"));
					transObjList.add(province);
				}
			}
		}
		return transObjList;
	}

	public List<Province> searchProvince(Province province) {
		List<Province> provinceList = new ArrayList<Province>();
		List<Province> provinceSearchList = new ArrayList<Province>();
		provinceList = getProvinceDetails();
		try {
			if ((province.getProvinceCode().equals("") || province
					.getProvinceCode().equals(null)) // no
					// name,no
					// ID
					&& province.getProvinceName().equals("")
					|| province.getProvinceName().equals(null)) {
				if (province.getStatus().equals("All"))
					return provinceList;
				else if (province.getStatus().equals("Authorized")) {
					for (Province province1 : provinceList) {
						if (province1.getStatus().equals(province.getStatus()))
							provinceSearchList.add(province1);
					}
					return provinceSearchList;
				} else if (province.getStatus()
						.equals("Deleted and Authorized")) {
					for (Province province1 : provinceList) {
						if (province1.getStatus().equals(province.getStatus()))
							provinceSearchList.add(province1);
					}
					return provinceSearchList;
				} else if (province.getStatus().equals("Deleted")) {
					for (Province province1 : provinceList) {
						if (province1.getStatus().equals(province.getStatus()))
							provinceSearchList.add(province1);
					}
					return provinceSearchList;
				}

				else {
					for (Province province1 : provinceList) {
						if (province1.getStatus()
								.contains(province.getStatus()))
							provinceSearchList.add(province1);
					}
					return provinceSearchList;
				}

			} else if (province.getProvinceCode().equals("") // no ID
					|| province.getProvinceCode().equals(null)) {
				for (Province province1 : provinceList) {
					if (province1.getProvinceName().toLowerCase()
							.contains(province.getProvinceName().toLowerCase())) {
						if (province1.getStatus()
								.contains(province.getStatus())
								|| province.getStatus().equals("All")) {
							provinceSearchList.add(province1);
						}
					}
				}
			} else if (province.getProvinceName().equals("") // no name
					|| province.getProvinceName().equals(null)) {
				for (Province province1 : provinceList) {
					if (province1.getProvinceCode().toLowerCase()
							.contains(province.getProvinceCode().toLowerCase())) {
						if (province1.getStatus()
								.contains(province.getStatus())
								|| province.getStatus().equals("All")) {
							provinceSearchList.add(province1);
						}
					}
				}
			} else {
				for (Province province1 : provinceList) { // both present
					if (province1.getProvinceName().toLowerCase()
							.contains(province.getProvinceName().toLowerCase())
							&& province1
									.getProvinceCode()
									.toLowerCase()
									.contains(
											province.getProvinceCode()
													.toLowerCase())) {
						if (province1.getStatus()
								.contains(province.getStatus())
								|| province.getStatus().equals("All")) {
							provinceSearchList.add(province1);
						}
					}
				}
			}
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for provinceDetails account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		return provinceSearchList;
	}

	public int addProvince(Province province, String param) {

		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("ADDPROVINCE"));
		Integer count = 0;
		try {
			if (province.getStatus().equals("New") && param.equals("add")) {
				List<Province> provinces = getProvinceDetails();
				for (Province menuItem : provinces) {
					if (menuItem.getProvinceCode().equals(
							province.getProvinceCode())) {
						count = 2;
						return (int) count;
					}
					if (menuItem.getProvinceName().equals(
							province.getProvinceName())) {
						count = 3;
						return (int) count;
					}
				}
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { province.getProvinceCode(),
								province.getProvinceName(),
								province.getMaker(), province.getMakerDt(),
								province.getStatus(), province.getActive() });
			} else if (province.getStatus().equals("Authorized")
					&& param.equals("Modified")) {
				count = jdbcTemplate.update(sql.toString(), new Object[] {
						province.getProvinceCode(), province.getProvinceName(),
						province.getMaker(), province.getMakerDt(), "Modified",
						province.getActive() });
			} else if (province.getStatus().equals("Authorized")
					&& param.equals("delete")) {
				count = jdbcTemplate.update(sql.toString(), new Object[] {
						province.getProvinceCode(), province.getProvinceName(),
						province.getMaker(), province.getMakerDt(), "Deleted",
						province.getActive() });
			} else if (param.equals("Reject")) {
				int schemeCount = rejectProvinceCount(province
						.getProvinceCode());
				if (schemeCount > 0) {
					province.setStatus("Rejected");
					deleteProvince(province);
				}
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { province.getProvinceCode(),
								province.getProvinceName(),
								province.getMaker(), province.getMakerDt(),
								"Rejected" });
				deleteProvince(province);
			}
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public int rejectProvinceCount(String provinceCode) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETREJECTEDPROVINCE"));
		Integer count = 0;
		try {
			count = jdbcTemplate.queryForObject(sql.toString(), new Object[] {
					provinceCode, "Rejected" }, Integer.class);
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("getting rejected count failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	@Transactional
	public int authorProvince(Province item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("AUTHORPROVINCE"));
		/*
		 * This is for iMobile channel table
		 */
		StringBuilder sql1 = new StringBuilder();
		sql1.append(imbcaproperties.get("ADDPROVINCEINCHNL"));
		Integer count = 0;
		try {
			if (item.getStatus().equals("New")) {
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { item.getProvinceName(),
								item.getChecker(), item.getCheckerDt(),
								"Authorized", "Y", item.getProvinceCode() });
				/*
				 * This is for iMobile channel table
				 */
				count = jdbcTemplate.update(
						sql1.toString(),
						new Object[] { item.getProvinceCode(),
								item.getProvinceName(), item.getMaker(),
								item.getMakerDt(), "Authorized", "Y",
								item.getChecker(), item.getCheckerDt() });

			} else if (item.getStatus().equals("Modified")) {
				count = updateProvince(item);
				if (count == 1) {
					count = deleteProvince(item);
				}
			} else if (item.getStatus().equals("Deleted")) {

				Province item2 = new Province();
				item2.setProvinceCode(item.getProvinceCode());
				item2.setChecker(item.getChecker());
				item2.setCheckerDt(item.getCheckerDt());
				count = deleteProvince(item);
				count = changeStatus(item2);
			}
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
			transactionManager.rollback(null);
		} catch (Exception e) {
			logWriter.info("error" + e);
			transactionManager.rollback(null);
		}
		return (int) count;
	}

	private Integer changeStatus(Province item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("CHANGEPROVINCESTATUS"));
		// ------------------------This is for iMobileChannerl Table
		StringBuilder sql1 = new StringBuilder();
		sql1.append(imbcaproperties.get("CHANGEPROVINCESTATUSFORCHNL"));
		// --------------------------------------------------
		Integer count = 0;
		try {
			count = jdbcTemplate.update(
					sql.toString(),
					new Object[] { "N", "Deleted and Authorized",
							item.getChecker(), item.getCheckerDt(),
							item.getProvinceCode() });
			// ------------------------This is for iMobileChannerl Table
			count = jdbcTemplate.update(
					sql1.toString(),
					new Object[] { "N", "Deleted and Authorized",
							item.getChecker(), item.getCheckerDt(),
							item.getProvinceCode() });
			// --------------------------------------------------
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("updatation of Field failed..");
			transactionManager.rollback(null);
		} catch (Exception e) {
			logWriter.info("error" + e);
			transactionManager.rollback(null);
		}
		return (int) count;
	}

	@Transactional
	public int updateProvince(Province province) {

		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("UPDATEPROVINCE"));
		/*
		 * This is for iMobileChannel table
		 */
		StringBuilder sql1 = new StringBuilder();
		sql1.append(imbcaproperties.get("UPDATEPROVINCEFORCHNL"));
		Integer count = 0;
		try {
			if (province.getStatus().equals("Modified")) {
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { province.getProvinceName(),
								province.getMaker(), province.getMakerDt(),
								province.getChecker(), province.getCheckerDt(),
								province.getProvinceCode(), "Authorized" });
				/*
				 * This is for iMobileChannel table
				 */
				count = jdbcTemplate.update(
						sql1.toString(),
						new Object[] { province.getProvinceName(),
								province.getMaker(), province.getMakerDt(),
								province.getChecker(), province.getCheckerDt(),
								"Authorized", province.getProvinceCode() });
			}
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("updatation of Field failed..");
			transactionManager.rollback(null);
		} catch (Exception e) {
			logWriter.info("error" + e);
			transactionManager.rollback(null);
		}
		return (int) count;
	}

	public int deleteProvince(Province province) {
		StringBuilder sql = new StringBuilder();

		sql.append(imbcaproperties.get("DELETEPROVINCE"));
		Integer count = 0;
		// final List<AddFields> request=list;
		try {
			count = jdbcTemplate.update(
					sql.toString(),
					new Object[] { province.getProvinceCode(),
							province.getStatus() });
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public int rejectProvince(Province province) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("REJECTPROVINCE"));
		Integer count = 0;
		try {
			int schemeCount = rejectProvinceCount(province.getProvinceCode());
			if (schemeCount > 0) {
				province.setStatus("Rejected");
				deleteProvince(province);
			}
			count = jdbcTemplate.update(
					sql.toString(),
					new Object[] { province.getProvinceName(),
							province.getChecker(), province.getCheckerDt(),
							"Rejected", province.getProvinceCode() });
			deleteProvince(province);
			/*
			 * count = jdbcTemplate.update( sql.toString(), new Object[] {
			 * province.getProvinceName(), province.getChecker(),
			 * province.getCheckerDt(), province.getStatus(),
			 * province.getProvinceCode() });
			 */
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}
}
