package com.icicibank.iMobileCA.dao;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.icicibank.iMobileCA.model.Attempts;

@Repository
public class EdepositStatusDAO {

	@Autowired JdbcTemplate jdbcTemplate;
	private static final Logger logWriter = Logger.getLogger(UserActionDAO.class.getName());
			
	/*@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		hibernateTemplate = new HibernateTemplate(sessionFactory);
	}*/
	@Resource(name = "imbcaproperties")
	private Properties imbcaproperties;
	
	public int updateStatus(Attempts list,String refNumberList) {
		/*StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("UPDATESTATUS"));*/
		Integer count = 0;
		logWriter.info(""+refNumberList.split(",").length);
		List<String> request=new ArrayList<String>();
		//logWriter.info("length of string"+refNumberList.length());
		for(int i=0;i<refNumberList.split(",").length;i++){
			request.add(refNumberList.split(",")[i]);
		}
		String listValues = "";
		for (int i=0; i<request.size(); i++) {
			listValues = listValues + "'"+request.get(i) + "'";
			if(i+1 < request.size()){
				listValues = listValues + ",";
			}
		}
		try {
			String sql3="UPDATE IMCA_ECHEQUE_DETAILS SET CHANGED_STATUS='"+list.getStatus()+"',AUTHORING_STATUS='"+list.getAuthStatus()+"',MAKER='"+list.getMaker()+"',MAKERDT=?"+" where REFERENCENUMBER in ("+listValues+")";
			count = jdbcTemplate.update(sql3,new Object[] {list.getMakerDt()});
			logWriter.info("Count : "+count);
		}
		catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		}
		catch(Exception e){
			logWriter.info("error"+e);
			e.printStackTrace();
		}
		return (int) count;
	}
	public int bulkStatusUpdate(Attempts list,String zoneName, Timestamp timestamp,
			Timestamp timestamp2, String referenceNumber) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("BULKSTATUSUPDATEFORZONES"));
		Integer count = 0;
		//final List<AddFields> request=list;
		try {
			count = jdbcTemplate.update(sql.toString(), new Object[] { list.getStatus(),list.getMaker(),list.getMakerDt(),timestamp,timestamp2,zoneName,referenceNumber});
		}
		catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		}
		catch(Exception e){
			logWriter.info("error"+e);
		}
		return (int) count;
	}
	public int bulkStatusUpdateForDateRefNo(Attempts list,Timestamp timestamp,
			Timestamp timestamp2, String referenceNumber) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("BULKSTATUSUPDATEFORDATEREFNO"));
		Integer count = 0;
		//final List<AddFields> request=list;
		try {
			count = jdbcTemplate.update(sql.toString(), new Object[] { list.getStatus(),list.getMaker(),list.getMakerDt(),timestamp,timestamp2,referenceNumber});
		}
		catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		}
		catch(Exception e){
			logWriter.info("error"+e);
		}
		return (int) count;
	}
	public int bulkStatusUpdateForDate(Attempts list,String zoneName, Timestamp timestamp,
			Timestamp timestamp2) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("BULKSTATUSUPDATEFORDATE"));
		Integer count = 0;
		//final List<AddFields> request=list;
		try {
			count = jdbcTemplate.update(sql.toString(), new Object[] { list.getStatus(),list.getMaker(),list.getMakerDt(),timestamp,timestamp2,zoneName});
		}
		catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		}
		catch(Exception e){
			logWriter.info("error"+e);
		}
		return (int) count;
	}
	public int bulkStatusUpdateForRefNo(Attempts list,String zoneName,String referenceNumber) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("BULKSTATUSUPDATEFORREFNO"));
		Integer count = 0;
		//final List<AddFields> request=list;
		try {
			count = jdbcTemplate.update(sql.toString(), new Object[] { list.getStatus(),list.getMaker(),list.getMakerDt(),zoneName,referenceNumber});
		}
		catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		}
		catch(Exception e){
			logWriter.info("error"+e);
		}
		return (int) count;
	}
	public int authorStatus(final List<Attempts> attempts) {
		/*StringBuilder sql = new StringBuilder();
		//UPDATE IMCA_TRANSATION_RANGE SET CHANGED_VALUE='3',AUTHORING_STATUS='N' WHERE LIMIT_TYPE='SPOT_NOISE';
		sql.append(imbcaproperties.get("AUTHORSTATUS"));*/
		//Integer count1 = 0;
			String sql="UPDATE IMCA_ECHEQUE_DETAILS SET STATUS=?,AUTHORING_STATUS=?,CHECKER=?,CHECKER_DT=? where REFERENCENUMBER =?";
			int[] count=jdbcTemplate.batchUpdate(sql.toString(), new BatchPreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						Attempts attempt = attempts.get(i);
						ps.setString(1,attempt.getStatus());
						ps.setString(2,attempt.getAuthStatus());
						ps.setString(3,attempt.getChecker());
						ps.setTimestamp(4,attempt.getCheckerDt());
						ps.setString(5, attempt.getReferenceNumber());
					}

					@Override
					public int getBatchSize() {
						return attempts.size();
					}
				  });
			/*for (Attempts attempts : attemptlist) {
			
			String sql3="UPDATE IMCA_ECHEQUE_DETAILS SET STATUS='"+attempts.getStatus()+"',AUTHORING_STATUS='"+attempts.getAuthStatus()+"',CHECKER='"+attempts.getChecker()+"',CHECKER_DT=?"+" where REFERENCENUMBER ='"+attempts.getReferenceNumber()+"'";
			
			count = jdbcTemplate.update(sql3,new Object[] {attempts.getCheckerDt()});
			
			}*/
			//count = jdbcTemplate.update(sql.toString(), new Object[] { list.getStatus(),list.getChecker(),list.getCheckerDt(),list.getReferenceNumber()});
		/*}
		catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		}
		catch(Exception e){
			logWriter.info("error"+e);
		}*/
			logWriter.info("count"+count.length);
		return (int) count.length;
	}
	public List<Attempts> getZoneDetails(String zoneName,Timestamp start,Timestamp end,String refNumber) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("SEARCHZONES"));
		try {
			/*String startTime = CommonUtil.getDateTime(start.getTime(),"YYYY-MM-DD HH:mm:ss","EST");
			String endTime = CommonUtil.getDateTime(end.getTime(),"YYYY-MM-DD HH:mm:ss","EST");*/
			fieldNames = jdbcTemplate.queryForList(sql.toString(),start,end,zoneName,refNumber);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Pending");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				//attempts.setStatus((String) row.get("STATUS"));
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	public List<Attempts> getZoneDetailsForAuthor(String userId) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETZONESFORAUTHORING"));
		try {
			/*String startTime = CommonUtil.getDateTime(start.getTime(),"YYYY-MM-DD HH:mm:ss","EST");
			String endTime = CommonUtil.getDateTime(end.getTime(),"YYYY-MM-DD HH:mm:ss","EST");*/
			fieldNames = jdbcTemplate.queryForList(sql.toString(),userId);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setChangedStatus((String) row.get("CHANGED_STATUS"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Pending");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				//attempts.setStatus((String) row.get("STATUS"));
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	public List<Attempts> getZoneDetailsForAuthoring(String zoneName,Timestamp start,Timestamp end,String refNumber,String userId) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("SEARCHZONESFORAUTHOR"));
		try {
			//String startTime = CommonUtil.getDateTime(start.getTime(),"YYYY-MM-DD HH:mm:ss","EST");
			//String endTime = CommonUtil.getDateTime(end.getTime(),"YYYY-MM-DD HH:mm:ss","EST");
			fieldNames = jdbcTemplate.queryForList(sql.toString(),start,end,zoneName,refNumber,userId);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setChangedStatus((String) row.get("CHANGED_STATUS"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Pending");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				//attempts.setStatus((String) row.get("STATUS"));
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	public List<Attempts> getDetailswithDateRefNo(Timestamp start,Timestamp end,String refNumber) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		/*Date startTime=CommonUtil.beginOfDay(selectedDate);
		Date endTime=CommonUtil.endOfDay(selectedDate);*/
		sql.append(imbcaproperties.get("SEARCHWITHDATEREFNO"));
		try {
			//String startTime = CommonUtil.getDateTime(start.getTime(),"YYYY-MM-DD HH:mm:ss","EST");
			//String endTime = CommonUtil.getDateTime(end.getTime(),"YYYY-MM-DD HH:mm:ss","EST");
			fieldNames = jdbcTemplate.queryForList(sql.toString(),start,end,refNumber);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Pending");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				//attempts.setStatus((String) row.get("STATUS"));
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	public List<Attempts> getDetailswithDateRefNoForAuthor(Timestamp start,Timestamp end,String refNumber,String userId) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		/*Date startTime=CommonUtil.beginOfDay(selectedDate);
		Date endTime=CommonUtil.endOfDay(selectedDate);*/
		sql.append(imbcaproperties.get("SEARCHWITHDATEREFNOFORAUTHOR"));
		try {
			//String startTime = CommonUtil.getDateTime(start.getTime(),"YYYY-MM-DD HH:mm:ss","EST");
			//String endTime = CommonUtil.getDateTime(end.getTime(),"YYYY-MM-DD HH:mm:ss","EST");
			fieldNames = jdbcTemplate.queryForList(sql.toString(),start,end,refNumber,userId);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setChangedStatus((String) row.get("CHANGED_STATUS"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Pending");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				//attempts.setStatus((String) row.get("STATUS"));
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	public List<Attempts> getDetailswithRefNo(String zoneName,String refNo) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("SEARCHWITHREFNO"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),zoneName,refNo);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Pending");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				//attempts.setStatus((String) row.get("STATUS"));
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	public List<Attempts> getDetailswithRefNoForAuthor(String zoneName,String refNo,String userId) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("SEARCHWITHREFNOFORAUTHOR"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),zoneName,refNo,userId);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setChangedStatus((String) row.get("CHANGED_STATUS"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Pending");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				//attempts.setStatus((String) row.get("STATUS"));
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	public List<Attempts> getDetailswithDate(Timestamp start,Timestamp end,String zoneName) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("SEARCHWITHDATE"));
		try {
			//String startTime = CommonUtil.getDateTime(start.getTime(),"YYYY-MM-DD HH:mm:ss","EST");
			//String endTime = CommonUtil.getDateTime(end.getTime(),"YYYY-MM-DD HH:mm:ss","EST");
			fieldNames = jdbcTemplate.queryForList(sql.toString(),start,end,zoneName);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Pending");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				//attempts.setStatus((String) row.get("STATUS"));
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	public List<Attempts> getDetailswithDateForAuthor(Timestamp start,Timestamp end,String zoneName,String userId) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("SEARCHWITHDATEFORAUTHOR"));
		try {
			//String startTime = CommonUtil.getDateTime(start.getTime(),"YYYY-MM-DD HH:mm:ss","EST");
			//String endTime = CommonUtil.getDateTime(end.getTime(),"YYYY-MM-DD HH:mm:ss","EST");
			fieldNames = jdbcTemplate.queryForList(sql.toString(),start,end,zoneName,userId);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setChangedStatus((String) row.get("CHANGED_STATUS"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Pending");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				//attempts.setStatus((String) row.get("STATUS"));
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	public List<Attempts> getDetailswithReference(String refNo) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("SEARCHWITHREFERENCENO"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),refNo);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setChangedStatus((String) row.get("CHANGED_STATUS"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Pending");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				//attempts.setStatus((String) row.get("STATUS"));
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	public List<Attempts> getDetailswithReferenceForAuthor(String refNo,String userId) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("SEARCHWITHREFERENCENOFORAUTHOR"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),refNo,userId);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setChangedStatus((String) row.get("CHANGED_STATUS"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Pending");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				//attempts.setStatus((String) row.get("STATUS"));
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	public List<Attempts> getDetailswithSubDate(Timestamp start,Timestamp end) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("SEARCHWITHSUBDATE"));
		try {
			//String startTime = CommonUtil.getDateTime(start.getTime(),"YYYY-MM-DD HH:mm:ss","EST");
			//String endTime = CommonUtil.getDateTime(end.getTime(),"YYYY-MM-DD HH:mm:ss","EST");
			fieldNames = jdbcTemplate.queryForList(sql.toString(),start,end);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setChangedStatus((String) row.get("CHANGED_STATUS"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Pending");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				//attempts.setStatus((String) row.get("STATUS"));
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	public List<Attempts> getDetailswithSubDateForAuthor(Timestamp start,Timestamp end,String userId) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("SEARCHWITHSUBDATEFORAUTHOR"));
		try {
			//String startTime = CommonUtil.getDateTime(start.getTime(),"YYYY-MM-DD HH:mm:ss","EST");
			//String endTime = CommonUtil.getDateTime(end.getTime(),"YYYY-MM-DD HH:mm:ss","EST");
			fieldNames = jdbcTemplate.queryForList(sql.toString(),start,end,userId);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setChangedStatus((String) row.get("CHANGED_STATUS"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Pending");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
}
