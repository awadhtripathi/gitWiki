package com.icicibank.iMobileCA.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.icicibank.iMobileCA.model.MenuItem;

@Repository
public class MenuMasterDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;
	private static final Logger logWriter = Logger
			.getLogger(MenuMasterDAO.class.getName());

	@Resource(name = "imbcaproperties")
	private Properties imbcaproperties;

	public List<MenuItem> getMenuDetails() {
		List<MenuItem> menuItemList = new ArrayList<MenuItem>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETMENUDETAILS"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString());
			logWriter.info("menuDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for menuDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				MenuItem menuItem = new MenuItem();
				menuItem.setMenuName((String) row.get("MENU_NAME"));
				menuItem.setMenuId((String) row.get("MENU_ID"));
				menuItem.setMenuStatus((String) row.get("MENU_STATUS"));
				menuItem.setMaker((String) row.get("MAKER"));
				menuItem.setMakerDt((Timestamp) row.get("MAKER_DT"));
				menuItem.setChecker((String) row.get("CHECKER"));
				menuItem.setCheckerDt((Timestamp) row.get("CHECKER_DT"));
				menuItem.setReason((String) row.get("REASON"));
				menuItem.setStatus((String) row.get("STATUS"));
				menuItemList.add(menuItem);
			}
		}
		return menuItemList;
	}

	public List<MenuItem> getMenuDetailsForAuthoring(String userId) {
		List<MenuItem> menuItemList = new ArrayList<MenuItem>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETMENUDETAILSFORAUTHOR"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),
					new Object[] { userId });
			logWriter.info("MENU DETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MENU DETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				if (!row.get("STATUS").equals("Authorized")
						&& !row.get("STATUS").equals("Rejected")
						&& !row.get("STATUS").equals("Deleted and Authorized")) {
					MenuItem menuItem = new MenuItem();
					menuItem.setMenuName((String) row.get("MENU_NAME"));
					menuItem.setMenuId((String) row.get("MENU_ID"));
					menuItem.setMenuStatus((String) row.get("MENU_STATUS"));
					menuItem.setMaker((String) row.get("MAKER"));
					menuItem.setMakerDt((Timestamp) row.get("MAKER_DT"));
					menuItem.setChecker((String) row.get("CHECKER"));
					menuItem.setCheckerDt((Timestamp) row.get("CHECKER_DT"));
					menuItem.setReason((String) row.get("REASON"));
					menuItem.setStatus((String) row.get("STATUS"));
					menuItemList.add(menuItem);
				}
			}
		}
		return menuItemList;
	}

	public List<MenuItem> searchMenu(MenuItem item) {
		List<MenuItem> menuItemList = new ArrayList<MenuItem>();
		List<MenuItem> menuItemSearchList = new ArrayList<MenuItem>();
		menuItemList = getMenuDetails();
		try {
			if ((item.getMenuId().equals("") || item.getMenuId().equals(null)) // no
																				// name,no
																				// ID
					&& item.getMenuName().equals("")
					|| item.getMenuName().equals(null)) {
				if (item.getStatus().equals("All"))
					return menuItemList;
				else {
					for (MenuItem menuItem : menuItemList) {
						if (menuItem.getStatus().contains(item.getStatus()))
							menuItemSearchList.add(menuItem);
					}
					return menuItemSearchList;
				}

			} else if (item.getMenuId().equals("") // no ID
					|| item.getMenuId().equals(null)) {
				for (MenuItem menuItem : menuItemList) {
					if (menuItem.getMenuName().toLowerCase()
							.contains(item.getMenuName().toLowerCase())) {
						if (menuItem.getStatus().contains(item.getStatus())
								|| item.getStatus().equals("All")) {
							menuItemSearchList.add(menuItem);
						}
					}
				}
			} else if (item.getMenuName().equals("") // no name
					|| item.getMenuName().equals(null)) {
				for (MenuItem menuItem : menuItemList) {
					if (menuItem.getMenuId().toLowerCase()
							.contains(item.getMenuId().toLowerCase())) {
						if (menuItem.getStatus().contains(item.getStatus())
								|| item.getStatus().equals("All")) {
							menuItemSearchList.add(menuItem);
						}
					}
				}
			} else {
				for (MenuItem menuItem : menuItemList) { // both present
					if (menuItem.getMenuName().toLowerCase()
							.contains(item.getMenuName().toLowerCase())
							&& menuItem.getMenuId().toLowerCase()
									.contains(item.getMenuId().toLowerCase())) {
						if (menuItem.getStatus().contains(item.getStatus())
								|| item.getStatus().equals("All")) {
							menuItemSearchList.add(menuItem);
						}
					}
				}
			}
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for menuDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		return menuItemSearchList;
	}

	public int addMenu(MenuItem item, String param) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("ADDMENU"));
		Integer count = 0;
		try {
			if (item.getStatus().equals("New") && param.equals("add")) {
				List<MenuItem> items = getMenuDetails();
				for (MenuItem menuItem : items) {
					if (menuItem.getMenuId().equals(item.getMenuId())) {
						count = 2;
						return (int) count;
					}
					if (menuItem.getMenuName().equals(item.getMenuName())) {
						count = 3;
						return (int) count;
					}
				}
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { item.getMenuId(), item.getMenuName(),
								item.getMaker(), item.getMakerDt(),
								item.getStatus(), item.getMenuStatus(),
								item.getReason() });
			} else if (item.getStatus().equals("Authorized")
					&& param.equals("Modified")) {
				count = jdbcTemplate.update(sql.toString(),
						new Object[] { item.getMenuId(), item.getMenuName(),
								item.getMaker(), item.getMakerDt(), "Modified",
								item.getMenuStatus(), item.getReason() });
			} else if (item.getStatus().equals("Authorized")
					&& param.equals("delete")) {
				count = jdbcTemplate.update(sql.toString(),
						new Object[] { item.getMenuId(), item.getMenuName(),
								item.getMaker(), item.getMakerDt(), "Deleted",
								item.getMenuStatus(), item.getReason() });
			} else if (param.equals("Reject")) {
				int menuCount = rejectMenuCount(item.getMenuId());
				if (menuCount > 0) {
					String status = item.getStatus();
					item.setStatus("Rejected");
					deleteMenu(item);
					item.setStatus(status);
				}
				count = jdbcTemplate.update(sql.toString(),
						new Object[] { item.getMenuId(), item.getMenuName(),
								item.getMaker(), item.getMakerDt(), "Rejected",
								item.getMenuStatus(), item.getReason() });
				deleteMenu(item);
			}
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public int rejectMenuCount(String menuId) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETREJECTEDMENU"));
		Integer count = 0;
		try {
			count = jdbcTemplate.queryForObject(sql.toString(), new Object[] {
					menuId, "Rejected" }, Integer.class);
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("getting rejected count failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public int updateMenu(MenuItem item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("UPDATEMENU"));
		Integer count = 0;
		try {
			if (item.getStatus().equals("Modified")) {
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { item.getMenuName(), item.getMaker(),
								item.getMakerDt(), "Authorized",
								item.getMenuStatus(), item.getReason(),
								item.getChecker(), item.getCheckerDt(),
								item.getMenuId(), "Authorized" });
			}
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	@Transactional
	public int authorMenu(MenuItem item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("AUTHORMENU"));
		Integer count = 0;
		/*
		 * This is will add menu into iMobile channel table.
		 * 
		 * StringBuilder sql1 = new StringBuilder();
		 * sql.append(imbcaproperties.get("ADDMENUFORCHNL"));
		 */

		try {
			if (item.getStatus().equals("New")) {
				count = jdbcTemplate.update(sql.toString(),
						new Object[] { item.getMenuName(), item.getChecker(),
								item.getCheckerDt(), "Authorized", "Active",
								item.getMenuId() });
			} else if (item.getStatus().equals("Modified")) {
				count = updateMenu(item);
				if (count == 1) {
					count = deleteMenu(item);
				}
			} else if (item.getStatus().equals("Deleted")) {
				MenuItem item2 = new MenuItem();
				item2.setMenuId(item.getMenuId());
				item2.setChecker(item.getChecker());
				item2.setCheckerDt(item.getCheckerDt());
				// item2.setStatus("Authorized");
				count = deleteMenu(item);
				// count = deleteMenu(item2);
				count = changeStatus(item2);
			}
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	private Integer changeStatus(MenuItem item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("CHANGEMENUSTATUS"));
		Integer count = 0;
		try {
			count = jdbcTemplate.update(sql.toString(), new Object[] {
					"Inactive", "Deleted and Authorized", item.getChecker(),
					item.getCheckerDt(), item.getMenuId(), "Authorized" });
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public int rejectMenu(MenuItem item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("REJECTMENU"));
		Integer count = 0;
		try {

			int menuCount = rejectMenuCount(item.getMenuId());
			if (menuCount > 0) {
				String status = item.getStatus();
				item.setStatus("Rejected");
				deleteMenu(item);
				item.setStatus(status);
			}
			count = jdbcTemplate.update(
					sql.toString(),
					new Object[] { item.getMenuId(), item.getMenuName(),
							item.getMaker(), item.getMakerDt(),
							item.getChecker(), item.getCheckerDt(), "Rejected",
							item.getMenuStatus(), item.getReason() });
			deleteMenu(item);
			/*
			 * count = jdbcTemplate.update( sql.toString(), new Object[] {
			 * item.getMenuName(), item.getChecker(), item.getCheckerDt(),
			 * item.getStatus(), item.getMenuStatus(), item.getMenuId() });
			 */} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public int deleteMenu(MenuItem item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("DELETEMENU"));
		Integer count = 0;
		try {
			count = jdbcTemplate.update(sql.toString(),
					new Object[] { item.getMenuId(), item.getStatus() });
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("deletion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public MenuItem viewMenu(String menuId, String status) {
		MenuItem menuItem = new MenuItem();
		Map<String, Object> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("SEARCHMENUWITHID"));
		try {
			fieldNames = jdbcTemplate.queryForMap(sql.toString(), new Object[] {
					menuId, status });
			logWriter.info("menuDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for menuDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			menuItem.setMenuName((String) fieldNames.get("MENU_NAME"));
			menuItem.setMenuId((String) fieldNames.get("MENU_ID"));
			menuItem.setMenuStatus((String) fieldNames.get("MENU_STATUS"));
			menuItem.setMaker((String) fieldNames.get("MAKER"));
			menuItem.setMakerDt((Timestamp) fieldNames.get("MAKER_DT"));
			menuItem.setChecker((String) fieldNames.get("CHECKER"));
			menuItem.setCheckerDt((Timestamp) fieldNames.get("CHECKER_DT"));
			menuItem.setReason((String) fieldNames.get("REASON"));
			menuItem.setStatus((String) fieldNames.get("STATUS"));
		}
		return menuItem;
	}

}
