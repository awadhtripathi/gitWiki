package com.icicibank.iMobileCA.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.icicibank.iMobileCA.model.Scheme;

@Repository
public class SchemeMasterDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;
	@Autowired
	DataSourceTransactionManager transactionManager;
	private static final Logger logWriter = Logger
			.getLogger(SchemeMasterDAO.class.getName());

	@Resource(name = "imbcaproperties")
	private Properties imbcaproperties;

	public List<Scheme> getSchemeDetails() {
		List<Scheme> transObjList = new ArrayList<Scheme>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETSCHEMEDETAILS"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString());
			logWriter.info("schemeDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for schemeDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Scheme scheme = new Scheme();
				scheme.setSchemeName((String) row.get("SCHEME_NAME"));
				scheme.setSchemeCode((String) row.get("SCHEME_CODE"));
				scheme.setDescription((String) row.get("DESCRIPTION"));
				scheme.setAccType((String) row.get("ACC_TYPE"));
				scheme.setSchemeType((String) row.get("SCHEME_TYPE"));
				scheme.setActive((String) row.get("ACTIVE"));
				scheme.setMaker((String) row.get("MAKER"));
				scheme.setMakerDt((Timestamp) row.get("MAKER_DT"));
				scheme.setChecker((String) row.get("CHECKER"));
				scheme.setCheckerDt((Timestamp) row.get("CHECKER_DT"));
				scheme.setReason((String) row.get("REASON"));
				scheme.setStatus((String) row.get("STATUS"));
				transObjList.add(scheme);
			}
		}
		return transObjList;
	}

	public List<Scheme> getSchemeDetailsForAuthoring(String userId) {
		List<Scheme> transObjList = new ArrayList<Scheme>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETSCHEMEDETAILSFORAUTHOR"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),
					new Object[] { userId });
			logWriter.info("schemeDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for schemeDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				if (!row.get("STATUS").equals("Authorized")
						&& !row.get("STATUS").equals("Rejected")
						&& !row.get("STATUS").equals("Deleted and Authorized")) {
					Scheme scheme = new Scheme();
					scheme.setSchemeName((String) row.get("SCHEME_NAME"));
					scheme.setSchemeCode((String) row.get("SCHEME_CODE"));
					scheme.setSchemeType((String) row.get("SCHEME_TYPE"));
					scheme.setDescription((String) row.get("DESCRIPTION"));
					scheme.setAccType((String) row.get("ACC_TYPE"));
					scheme.setActive((String) row.get("ACTIVE"));
					scheme.setMaker((String) row.get("MAKER"));
					scheme.setMakerDt((Timestamp) row.get("MAKER_DT"));
					scheme.setChecker((String) row.get("CHECKER"));
					scheme.setCheckerDt((Timestamp) row.get("CHECKER_DT"));
					scheme.setReason((String) row.get("REASON"));
					scheme.setStatus((String) row.get("STATUS"));
					transObjList.add(scheme);
				}
			}
		}
		return transObjList;
	}

	public Scheme viewScheme(String schemeCode, String status) {
		Scheme scheme = new Scheme();
		Map<String, Object> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("SEARCHSCHEMEWITHID"));
		try {
			fieldNames = jdbcTemplate.queryForMap(sql.toString(), new Object[] {
					schemeCode, status });
			logWriter.info("schemeDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for schemeDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			scheme.setSchemeName((String) fieldNames.get("SCHEME_NAME"));
			scheme.setSchemeCode((String) fieldNames.get("SCHEME_CODE"));
			scheme.setSchemeType((String) fieldNames.get("SCHEME_TYPE"));
			scheme.setActive((String) fieldNames.get("ACTIVE"));
			scheme.setMaker((String) fieldNames.get("MAKER"));
			scheme.setDescription((String) fieldNames.get("DESCRIPTION"));
			scheme.setAccType((String) fieldNames.get("ACC_TYPE"));
			scheme.setMakerDt((Timestamp) fieldNames.get("MAKER_DT"));
			scheme.setChecker((String) fieldNames.get("CHECKER"));
			scheme.setCheckerDt((Timestamp) fieldNames.get("CHECKER_DT"));
			scheme.setReason((String) fieldNames.get("REASON"));
			scheme.setStatus((String) fieldNames.get("STATUS"));
		}
		return scheme;
	}

	public List<Scheme> searchScheme(Scheme item) {
		List<Scheme> schemeItemList = new ArrayList<Scheme>();
		List<Scheme> schemeItemSearchList = new ArrayList<Scheme>();
		schemeItemList = getSchemeDetails();
		try {
			// no
			// name,no
			// ID
			if ((item.getSchemeCode().equals("") || item.getSchemeCode()
					.equals(null))
					&& item.getSchemeType().equals("")
					|| item.getSchemeType().equals(null)) {

				if (item.getStatus().equals("All"))
					return schemeItemList;

				else if (item.getStatus().equals("Authorized")) {
					for (Scheme scheme : schemeItemList) {
						if (scheme.getStatus().equals(item.getStatus()))
							schemeItemSearchList.add(scheme);
					}
					return schemeItemSearchList;
				} else if (item.getStatus().equals("Deleted and Authorized")) {
					for (Scheme scheme : schemeItemList) {
						if (scheme.getStatus().equals(item.getStatus()))
							schemeItemSearchList.add(scheme);
					}
					return schemeItemSearchList;
				}

				else if (item.getStatus().equals("Deleted")) {
					for (Scheme scheme : schemeItemList) {
						if (scheme.getStatus().equals(item.getStatus()))
							schemeItemSearchList.add(scheme);
					}
					return schemeItemSearchList;
				}

				else {
					for (Scheme scheme : schemeItemList) {
						if (scheme.getStatus().contains(item.getStatus()))
							schemeItemSearchList.add(scheme);
					}
					return schemeItemSearchList;
				}

			} else if (item.getSchemeCode().equals("") // no ID
					|| item.getSchemeCode().equals(null)) {
				for (Scheme scheme : schemeItemList) {
					if (scheme.getSchemeType().toLowerCase()
							.contains(item.getSchemeType().toLowerCase())) {
						if (scheme.getStatus().contains(item.getStatus())
								|| item.getStatus().equals("All")) {
							schemeItemSearchList.add(scheme);
						}
					}
				}
			} else if (item.getSchemeType().equals("") // no name
					|| item.getSchemeType().equals(null)) {
				for (Scheme scheme : schemeItemList) {
					if (scheme.getSchemeCode().toLowerCase()
							.contains(item.getSchemeCode().toLowerCase())) {
						if (scheme.getStatus().contains(item.getStatus())
								|| item.getStatus().equals("All")) {
							schemeItemSearchList.add(scheme);
						}
					}
				}
			} else {
				for (Scheme scheme : schemeItemList) { // both present
					if (scheme.getSchemeType().toLowerCase()
							.contains(item.getSchemeType().toLowerCase())
							&& scheme
									.getSchemeCode()
									.toLowerCase()
									.contains(
											item.getSchemeCode().toLowerCase())) {
						if (scheme.getStatus().contains(item.getStatus())
								|| item.getStatus().equals("All")) {
							schemeItemSearchList.add(scheme);
						}
					}
				}
			}
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for schemeDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		return schemeItemSearchList;
	}

	public int addScheme(Scheme item, String param) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("ADDSCHEME"));
		Integer count = 0;
		try {
			if (item.getStatus().equals("New") && param.equals("add")) {
				List<Scheme> items = getSchemeDetails();
				for (Scheme scheme : items) {
					if (scheme.getSchemeCode().equals(item.getSchemeCode())) {
						count = 2;
						return (int) count;
					}
				}
				count = jdbcTemplate
						.update(sql.toString(),
								new Object[] { item.getSchemeCode(),
										item.getMaker(), item.getMakerDt(),
										item.getStatus(), item.getSchemeType(),
										item.getReason(), item.getAccType(),
										item.getDescription(), "N" });
			} else if (item.getStatus().equals("Authorized")
					&& param.equals("Modified")) {
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { item.getSchemeCode(), item.getMaker(),
								item.getMakerDt(), "Modified",
								item.getSchemeType(), item.getReason(),
								item.getAccType(), item.getDescription(),
								item.getActive() });
			} else if (item.getStatus().equals("Authorized")
					&& param.equals("delete")) {
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { item.getSchemeCode(), item.getMaker(),
								item.getMakerDt(), "Deleted",
								item.getSchemeType(), item.getReason(),
								item.getAccType(), item.getDescription(),
								item.getActive() });
			} else if (param.equals("Reject")) {
				int schemeCount = rejectSchemeCount(item.getSchemeCode());
				if (schemeCount > 0) {
					item.setStatus("Rejected");
					deleteScheme(item);
				}
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { item.getSchemeCode(), item.getMaker(),
								item.getMakerDt(), "Rejected",
								item.getSchemeType(), item.getReason(),
								item.getAccType(), item.getDescription(),
								item.getActive() });
				deleteScheme(item);
			}
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public int rejectSchemeCount(String schemeCode) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETREJECTEDSCHEME"));
		Integer count = 0;
		try {
			count = jdbcTemplate.queryForObject(sql.toString(), new Object[] {
					schemeCode, "Rejected" }, Integer.class);
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("getting rejected count failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	@Transactional
	public int authorScheme(Scheme item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("AUTHORSCHEME"));
		StringBuilder sql1 = new StringBuilder();
		/*
		 * This will add scheme into iMobile Channel db.
		 */
		sql1.append(imbcaproperties.get("ADDSCHEMECODE"));
		Integer count = 0;

		try {
			if (item.getStatus().equals("New")) {
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { item.getChecker(), item.getCheckerDt(),
								"Authorized", item.getSchemeType(), "Y",
								item.getSchemeCode() });

				/*
				 * This will add scheme into iMobile Channel db.
				 */
				Scheme scheme = new Scheme();
				scheme = getSchemaBySchemeCode(item.getSchemeCode());
				count = jdbcTemplate.update(
						sql1.toString(),
						new Object[] { scheme.getSchemeCode(),
								scheme.getMaker(), scheme.getMakerDt(),
								scheme.getStatus(), scheme.getSchemeType(),
								scheme.getReason(), scheme.getAccType(),
								scheme.getDescription(), "Y",
								scheme.getChecker(), scheme.getCheckerDt() });

			} else if (item.getStatus().equals("Modified")) {
				count = updateScheme(item);
				if (count == 1) {
					count = deleteScheme(item);
				}
			} else if (item.getStatus().equals("Deleted")) {

				Scheme item2 = new Scheme();
				item2.setSchemeCode(item.getSchemeCode());
				item2.setChecker(item.getChecker());
				item2.setCheckerDt(item.getCheckerDt());
				count = deleteScheme(item);
				count = changeStatus(item2);
			}
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
			transactionManager.rollback(null);
		} catch (Exception e) {
			logWriter.info("error" + e);
			transactionManager.rollback(null);
		}
		return (int) count;
	}

	@Transactional
	private Integer changeStatus(Scheme item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("CHANGESCHEMESTATUS"));
		/*
		 * This is for iMobileChannel Table
		 */
		StringBuilder sql1 = new StringBuilder();
		sql1.append(imbcaproperties.get("CHANGESCHEMESTATUSCODE"));

		Integer count = 0;
		try {
			count = jdbcTemplate.update(
					sql.toString(),
					new Object[] { "N", "Deleted and Authorized",
							item.getChecker(), item.getSchemeCode() });
			// ------------------------This is for iMobileChannerl Table
			count = jdbcTemplate.update(
					sql1.toString(),
					new Object[] { "N", "Deleted and Authorized",
							item.getChecker(), item.getSchemeCode() });
			// --------------------------------------------------
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
			transactionManager.rollback(null);
		} catch (Exception e) {
			logWriter.info("error" + e);
			transactionManager.rollback(null);
		}
		return (int) count;
	}

	public int rejectScheme(Scheme item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("REJECTSCHEME"));
		Integer count = 0;
		try {

			int schemeCount = rejectSchemeCount(item.getSchemeCode());
			if (schemeCount > 0) {
				item.setStatus("Rejected");
				deleteScheme(item);
			}
			count = jdbcTemplate.update(
					sql.toString(),
					new Object[] { item.getSchemeCode(), item.getMaker(),
							item.getMakerDt(), item.getChecker(),
							item.getCheckerDt(), "Rejected",
							item.getSchemeType(), item.getReason(),
							item.getAccType(), item.getDescription(),
							item.getActive() });
			deleteScheme(item);
			/*
			 * count = jdbcTemplate.update( sql.toString(), new Object[] {
			 * item.getChecker(), item.getCheckerDt(), item.getStatus(),
			 * item.getSchemeType(), item.getSchemeCode() });
			 */
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	@Transactional
	public int updateScheme(Scheme item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("UPDATESCHEME"));
		Integer count = 0;
		/*
		 * This will update scheme into iMobile Channel db.
		 */
		StringBuilder sql1 = new StringBuilder();
		sql1.append(imbcaproperties.get("UPDATESCHEMECODE"));
		try {
			if (item.getStatus().equals("Modified")) {

				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { item.getMaker(), item.getMakerDt(),
								"Authorized", item.getSchemeType(),
								item.getReason(), item.getAccType(),
								item.getDescription(), item.getChecker(),
								item.getCheckerDt(), item.getActive(),
								item.getSchemeCode(), "Authorized" });
				// This will update scheme into iMobile Channel db.
				count = jdbcTemplate.update(
						sql1.toString(),
						new Object[] { item.getMaker(), item.getMakerDt(),
								"Authorized", item.getSchemeType(),
								item.getReason(), item.getAccType(),
								item.getDescription(), item.getChecker(),
								item.getCheckerDt(), item.getActive(),
								item.getSchemeCode(), "Authorized" });
			}
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
			transactionManager.rollback(null);
		} catch (Exception e) {
			logWriter.info("error" + e);
			transactionManager.rollback(null);
		}
		return (int) count;
	}

	public int deleteScheme(Scheme item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("DELETESCHEME"));
		Integer count = 0;

		count = jdbcTemplate.update(sql.toString(),
				new Object[] { item.getSchemeCode(), item.getStatus() });

		return (int) count;
	}

	Scheme getSchemaBySchemeCode(String schemeCode) {
		Scheme scheme = new Scheme();
		Map<String, Object> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("SEARCHSCHEMEBYID"));
		try {
			fieldNames = jdbcTemplate.queryForMap(sql.toString(),
					new Object[] { schemeCode });
			logWriter.info("schemeDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for schemeDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			scheme.setSchemeName((String) fieldNames.get("SCHEME_NAME"));
			scheme.setSchemeCode((String) fieldNames.get("SCHEME_CODE"));
			scheme.setSchemeType((String) fieldNames.get("SCHEME_TYPE"));
			scheme.setActive((String) fieldNames.get("ACTIVE"));
			scheme.setMaker((String) fieldNames.get("MAKER"));
			scheme.setDescription((String) fieldNames.get("DESCRIPTION"));
			scheme.setAccType((String) fieldNames.get("ACC_TYPE"));
			scheme.setMakerDt((Timestamp) fieldNames.get("MAKER_DT"));
			scheme.setChecker((String) fieldNames.get("CHECKER"));
			scheme.setCheckerDt((Timestamp) fieldNames.get("CHECKER_DT"));
			scheme.setReason((String) fieldNames.get("REASON"));
			scheme.setStatus((String) fieldNames.get("STATUS"));
		}
		return scheme;

	}
}
