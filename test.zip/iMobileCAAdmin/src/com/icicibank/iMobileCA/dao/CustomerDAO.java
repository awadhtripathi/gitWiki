package com.icicibank.iMobileCA.dao;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.persistence.Column;
import javax.persistence.Id;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.web.servlet.ModelAndView;

import com.icicibank.iMobileCA.model.Customer;
import com.icicibank.iMobileCA.model.CustomerDevice;
import com.icicibank.iMobileCA.model.ManageCustomer;
import com.icicibank.iMobileCA.model.MenuItem;

@Repository
public class CustomerDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;
	private static final Logger logWriter = Logger.getLogger(CustomerDAO.class
			.getName());

	@Resource(name = "imbcaproperties")
	private Properties imbcaproperties;

	public List<Customer> getCustomerDetails() { // from IMCA_CUSTOMERS
													// table for cutomer
													// management only
		List<Customer> customerList = new ArrayList<Customer>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETCUSTOMERDETAILS"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString());
			logWriter.info("customerDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for customerDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Customer customer = new Customer();
				customer.setBayUserId((String) row.get("BAYUSERID"));
				customer.setCustFName((String) row.get("CUST_FNAME"));
				customer.setCustLName((String) row.get("CUST_LNAME"));
				/* customer.setCustLoginPref((int) row.get("CUST_LOGIN_PREF")); */
				customer.setCustMPin((String) row.get("CUST_MPIN"));
				customer.setMobileNo((String) row.get("MOBILE_NO"));
				customer.setPassword((String) row.get("PASSWORD"));
				customer.setCustId((String) row.get("CUSTID"));
				/* customer.setStatus((int) row.get("STATUS")); */
				customer.setTokenId((String) row.get("TOKENID"));
				customer.setCustMName((String) row.get("CUST_MNAME"));
				customer.setCustAlias((String) row.get("CUST_ALIAS"));
				customer.setLastLogin((Timestamp) row.get("LAST_LOGIN"));

				customerList.add(customer);
			}
		}
		return customerList;
	}

	public List<Customer> getCustomerWithMobileNo(String mobileNo) {
		List<Customer> customerList = new ArrayList<Customer>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETCUSTOMERWITHMOBILENO"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),
					new Object[] { mobileNo });
			logWriter.info("customerWithMobileNoDETAILS size:  "
					+ fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter
					.info("No data found for customerWithMobileNoDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Customer customer = new Customer();
				customer.setBayUserId((String) row.get("BAYUSERID"));
				customer.setCustFName((String) row.get("CUST_FNAME"));
				customer.setCustLName((String) row.get("CUST_LNAME"));
				/* customer.setCustLoginPref((int) row.get("CUST_LOGIN_PREF")); */
				customer.setCustMPin((String) row.get("CUST_MPIN"));
				customer.setMobileNo((String) row.get("MOBILE_NO"));
				customer.setPassword((String) row.get("PASSWORD"));
				customer.setCustId((String) row.get("CUSTID"));
				/* customer.setStatus((int) row.get("STATUS")); */
				customer.setTokenId((String) row.get("TOKENID"));
				customer.setCustMName((String) row.get("CUST_MNAME"));
				customer.setCustAlias((String) row.get("CUST_ALIAS"));
				customer.setLastLogin((Timestamp) row.get("LAST_LOGIN"));
				customerList.add(customer);
			}
		}
		return customerList;
	}

	public List<Customer> getCustomerWithCustomerID(String custId) {
		List<Customer> customerList = new ArrayList<Customer>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETCUSTOMERWITHCUSTOMERID"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),
					new Object[] { custId });
			logWriter.info("customerWithCustIdDETAILS size:  "
					+ fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter
					.info("No data found for customerWithCustIdDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Customer customer = new Customer();
				customer.setBayUserId((String) row.get("BAYUSERID"));
				customer.setCustFName((String) row.get("CUST_FNAME"));
				customer.setCustLName((String) row.get("CUST_LNAME"));
				/* customer.setCustLoginPref((int) row.get("CUST_LOGIN_PREF")); */
				customer.setCustMPin((String) row.get("CUST_MPIN"));
				customer.setMobileNo((String) row.get("MOBILE_NO"));
				customer.setPassword((String) row.get("PASSWORD"));
				customer.setCustId((String) row.get("CUSTID"));
				/* customer.setStatus((int) row.get("STATUS")); */
				customer.setTokenId((String) row.get("TOKENID"));
				customer.setCustMName((String) row.get("CUST_MNAME"));
				customer.setCustAlias((String) row.get("CUST_ALIAS"));
				customer.setLastLogin((Timestamp) row.get("LAST_LOGIN"));
				customerList.add(customer);
			}
		}
		return customerList;
	}

	public Customer getCustomer(String custMobileNo, String custID,
			String selected) {
		Customer customer = new Customer();
		if (selected.equals("1")) {
			if (!custID.equals(null) && !custID.equals("")) {
				List<Customer> customerList = getCustomerWithCustomerID(custID);
				if (customerList.size() > 0) {
					customer = customerList.get(0);
				}
				customer.setCustFName(customer.getCustFName()
						+ customer.getCustMName() + customer.getCustLName());
				return customer;
			}
		}
		if (selected.equals("2")) {
			if (!custMobileNo.equals(null) && !custMobileNo.equals("")) {
				List<Customer> customerList = getCustomerWithMobileNo(custMobileNo);
				if (customerList.size() > 0) {
					customer = customerList.get(0);
				}
				customer.setCustFName(customer.getCustFName()
						+ customer.getCustMName() + customer.getCustLName());
				return customer;
			}
		}
		return customer;
	}

	public int updateCustomerDevice(CustomerDevice customerDevice) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("UPDATECUSTOMERDEVICE"));
		Integer count = 0;
		try {

			count = jdbcTemplate.update(
					sql.toString(),
					new Object[] { customerDevice.getDevice_Blocked_By(),
							customerDevice.getDevice_Blocked_Dt(),
							customerDevice.getDevice_Blocked_Reaon(), 3,
							customerDevice.getBay_User_Id(),
							customerDevice.getWl_Device_Id() });

		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;

	}

	public List<Customer> searchCustomer(String custMobileNo, String custID) {
		List<Customer> customerList = new ArrayList<>();
		List<Customer> manageCustomers = getCustomerDetails();

		if (custID.equals(null) || custID.equals("")) {
			for (Customer customer : manageCustomers) {
				if (customer.getMobileNo().toLowerCase().contains(custMobileNo)) {
					customerList.add(customer);
				}
			}
			return customerList;

		} else if (custMobileNo.equals(null) || custMobileNo.equals("")) {
			for (Customer customer : manageCustomers) {
				if (customer.getCustId().toLowerCase().contains(custID)) {
					customerList.add(customer);
				}
			}
			return customerList;
		} else {
			for (Customer customer : manageCustomers) {
				if (customer.getMobileNo().toLowerCase().contains(custMobileNo)
						&& customer.getCustId().toLowerCase().contains(custID)) {
					customerList.add(customer);
				}
			}
			return customerList;
		}
	}

	public Customer getCustomerForUpdate(String custId) {
		Map<String, Object> row = null;
		StringBuilder sql = new StringBuilder();
		Customer customer = new Customer();
		sql.append(imbcaproperties.get("GETCUSTOMERFORUPDATE"));
		try {
			row = jdbcTemplate.queryForMap(sql.toString(),
					new Object[] { custId });
			logWriter.info("customerWithCustIdDETAILS size:  " + row.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for customer for update account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (row != null) {

			customer.setBayUserId((String) row.get("BAYUSERID"));
			customer.setCustFName((String) row.get("CUST_FNAME"));
			customer.setCustLName((String) row.get("CUST_LNAME"));
			/* customer.setCustLoginPref((int) row.get("CUST_LOGIN_PREF")); */
			customer.setCustMPin((String) row.get("CUST_MPIN"));
			customer.setMobileNo((String) row.get("MOBILE_NO"));
			/* customer.setPassword((String) row.get("PASSWORD")); */
			customer.setCustId((String) row.get("CUSTID"));
			/* customer.setStatus((int) row.get("STATUS")); */
			customer.setTokenId((String) row.get("TOKENID"));
			customer.setCustMName((String) row.get("CUST_MNAME"));
			customer.setCustAlias((String) row.get("CUST_ALIAS"));
			customer.setLastLogin((Timestamp) row.get("LAST_LOGIN"));

			/*
			 * customer.setId((String) fieldNames.get("ID"));
			 * customer.setCustId((String) fieldNames.get("CUSTID"));
			 * customer.setCustAliasName((String) fieldNames
			 * .get("CUST_ALIAS_NAME")); customer.setMobileNo((String)
			 * fieldNames.get("MOBILENO")); customer.setRegDt((Timestamp)
			 * fieldNames.get("REG_DATE")); customer.setTokenId((String)
			 * fieldNames.get("TOKENID"));
			 * customer.setInvalidLoginAttempts((int) fieldNames
			 * .get("INVALID_LOGIN_ATTEMPTS")); customer.setLocked((String)
			 * fieldNames.get("LOCKED")); customer.setUpdatedDt((Timestamp)
			 * fieldNames.get("UPDATED_DATE"));
			 */
		}
		return customer;
	}

	public List<CustomerDevice> getCustomerDevice(String bayUserId) {
		List<CustomerDevice> customerDeviceList = new ArrayList<CustomerDevice>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETCUSTOMERDEVICES"));
		try {
			/*
			 * fetch devices for bayUserId which are active... 1- active 2-
			 * inactive 3-block -> so pass integer 1 for that.
			 */
			fieldNames = jdbcTemplate.queryForList(sql.toString(),
					new Object[] { bayUserId, 1 });
			logWriter.info("customerDeviceList size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for customerDeviceList account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				CustomerDevice device = new CustomerDevice();
				device.setBay_User_Id((String) row.get("BAYUSERID"));
				device.setWl_Device_Id((String) row.get("WLDEVICEID"));
				device.setDevice_Os_Version((String) row
						.get("DEVICE_OS_VERSION"));
				device.setDevice_Os_Type((String) row.get("DEVICE_OS_TYPE"));
				device.setApp_Version((String) row.get("APP_VERSION"));
				device.setDevice_Status_Flag((BigDecimal) row
						.get("DEVICE_STATUS_FLAG"));
				device.setLast_Login_Success_Dt((Timestamp) row
						.get("LAST_LOGIN_SUCCESS_DATE"));
				device.setTouch_Enabled((BigDecimal) row.get("TOUCH_ENABLED"));
				device.setFirst_Activated_Dt((Timestamp) row
						.get("FIRST_ACTIVATED_DATE"));
				device.setLast_ReActivated_Dt((Timestamp) row
						.get("LAST_REACTIVATED_DATE"));
				device.setOTP_Status((BigDecimal) row.get("OTP_STATUS"));
				device.setOTP_Verification_Dt((Timestamp) row
						.get("OTP_VERIFICATION_DATE"));
				device.setDevice_Blocked_By((String) row
						.get("DEVICE_BLOCKEDBY"));
				device.setDevice_Blocked_Reaon((String) row
						.get("DEVICE_BLOCKED_REASON"));
				device.setDevice_Blocked_Dt((Timestamp) row
						.get("DEVICE_BLOCKED_DATE"));
				device.setDevice_Model((String) row.get("DEVICE_MODEL"));
				device.setUser_Agent((String) row.get("USERAGENT"));
				device.setGCM_Key((String) row.get("GCMKEY"));
				device.setX_Id((String) row.get("XID"));
				customerDeviceList.add(device);
			}
		}
		return customerDeviceList;
	}

	public int blockDevice(CustomerDevice customerDevice) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("ADDBLOCKEDDEVICE"));
		Integer count = 0, value = 0;
		try {
			count = updateCustomerDevice(customerDevice);
			if (count == 1) {
				value = 1;
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { customerDevice.getBay_User_Id(),
								customerDevice.getWl_Device_Id(),
								customerDevice.getDevice_Os_Version(),
								customerDevice.getDevice_Os_Type(),
								customerDevice.getApp_Version(),
								customerDevice.getDevice_Blocked_By(),
								customerDevice.getDevice_Blocked_Reaon(),
								customerDevice.getDevice_Blocked_Dt(),
								customerDevice.getDevice_Model() });
				if (count == 1) {
					value = 2;
				}
			}

		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) value;
	}

	public String getUrl(String type) {

		Map<String, Object> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		String url = "";
		sql.append(imbcaproperties.get("VIEWURL"));
		try {
			fieldNames = jdbcTemplate.queryForMap(sql.toString(),
					new Object[] { type });
			logWriter.info("PARAM VALUE size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for PARAM VALUE.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (!fieldNames.isEmpty()) {
			url = ((String) fieldNames.get("PARAM_VALUE"));

		}
		return url;
	}
}
