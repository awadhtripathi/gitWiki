package com.icicibank.iMobileCA.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.icicibank.iMobileCA.model.Branches;
import com.icicibank.iMobileCA.model.Cities;
import com.icicibank.iMobileCA.model.MenuItem;
import com.icicibank.iMobileCA.model.Users;

public class BranchMasterDAO {
	@Autowired
	JdbcTemplate jdbcTemplate;
	private static final Logger logWriter = Logger
			.getLogger(BranchMasterDAO.class.getName());

	@Resource(name = "imbcaproperties")
	private Properties imbcaproperties;

	public List<Branches> getBranchDetails() {
		List<Branches> transObjList = new ArrayList<Branches>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETBRANCHDETAILS"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString());
			logWriter.info("branchDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for branchDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Branches branches = new Branches();
				branches.setBranchName((String) row.get("BRANCH_NAME"));
				branches.setProvinceCode((String) row.get("PROVINCE_CODE"));
				branches.setStatus((String) row.get("STATUS"));
				branches.setPostalCode((String) row.get("POSTAL_CODE"));
				branches.setActive((String) row.get("ACTIVE"));
				branches.setMaker((String) row.get("MAKER"));
				branches.setMakerDt((Timestamp) row.get("MAKERDT"));
				branches.setChecker((String) row.get("CHECKER"));
				branches.setCheckerDt((Timestamp) row.get("CHECKER_DT"));
				branches.setTelephone((String) row.get("TELEPHONE"));
				branches.setAddress((String) row.get("ADDRESS"));
				branches.setFax((String) row.get("FAX"));
				branches.setCityCode((String) row.get("CITY_CODE"));
				branches.setStatus((String) row.get("STATUS"));
				branches.setBranchCode((String) row.get("BRANCH_CODE"));
				branches.setTimings((String) row.get("TIMINGS"));
				branches.setReason((String) row.get("REASON"));
				branches.setBranchCode((String) row.get("BRANCH_CODE"));
				branches.setLatitude(row.get("LATITUDE").toString());
				branches.setLongitude(row.get("LONGITUDE").toString());
				transObjList.add(branches);
			}
		}
		return transObjList;
	}

	public Branches getBranchWithBranchCode(String branchCode) {
		Map<String, Object> row = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("VIEWBRANCH"));
		try {
			row = jdbcTemplate.queryForMap(sql.toString(), new Object[] {
					branchCode, "Authorized" });
			logWriter.info("branchDETAILS :  " + row.values());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for branchDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		Branches branches = new Branches();
		if (row != null) {
			branches.setBranchName((String) row.get("BRANCH_NAME"));
			branches.setProvinceCode((String) row.get("PROVINCE_CODE"));
			branches.setStatus((String) row.get("STATUS"));
			branches.setPostalCode((String) row.get("POSTAL_CODE"));
			branches.setActive((String) row.get("ACTIVE"));
			branches.setMaker((String) row.get("MAKER"));
			branches.setMakerDt((Timestamp) row.get("MAKERDT"));
			branches.setChecker((String) row.get("CHECKER"));
			branches.setCheckerDt((Timestamp) row.get("CHECKER_DT"));
			branches.setTelephone((String) row.get("TELEPHONE"));
			branches.setAddress((String) row.get("ADDRESS"));
			branches.setFax((String) row.get("FAX"));
			branches.setCityCode((String) row.get("CITY_CODE"));
			branches.setStatus((String) row.get("AUTH_STATUS"));
			branches.setBranchCode((String) row.get("BRANCH_CODE"));
			branches.setTimings((String) row.get("TIMINGS"));
			branches.setReason((String) row.get("REASON"));
			branches.setBranchCode((String) row.get("BRANCH_CODE"));
			branches.setLatitude(row.get("LATITUDE").toString());
			branches.setLongitude(row.get("LONGITUDE").toString());
		}
		return branches;
	}

	public int getNoOfBranches(String cityCode) {
		int count = 0;
		/*
		 * List<Branches> transObjList = new ArrayList<Branches>();
		 * List<Map<String, Object>> fieldNames = null;
		 */
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETBRANCHDETAILSWITHCITY"));
		try {
			count = jdbcTemplate.queryForObject(sql.toString(),
					new Object[] { cityCode }, Integer.class);
			logWriter.info("branchDETAILS size:  " + count);
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for branchDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		return count;
	}

	public List<Branches> getBranchDetailsForAuthoring(String userId) {
		List<Branches> transObjList = new ArrayList<Branches>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETBRANCHDETAILSFORAUTHOR"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),
					new Object[] { userId });
			logWriter.info("BRANCH DETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for BRANCH DETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				if (!row.get("STATUS").equals("Authorized")
						&& !row.get("STATUS").equals("Rejected")
						&& !row.get("STATUS").equals("Deleted and Authorized")) {
					Branches branches = new Branches();
					branches.setBranchName((String) row.get("BRANCH_NAME"));
					branches.setProvinceCode((String) row.get("PROVINCE_CODE"));
					branches.setStatus((String) row.get("STATUS"));
					branches.setPostalCode((String) row.get("POSTAL_CODE"));
					branches.setCityCode((String) row.get("CITY_CODE"));
					branches.setActive((String) row.get("ACTIVE"));
					branches.setMaker((String) row.get("MAKER"));
					branches.setMakerDt((Timestamp) row.get("MAKERDT"));
					branches.setChecker((String) row.get("CHECKER"));
					branches.setCheckerDt((Timestamp) row.get("CHECKER_DT"));
					branches.setTelephone((String) row.get("TELEPHONE"));
					branches.setAddress((String) row.get("ADDRESS"));
					branches.setFax((String) row.get("FAX"));
					branches.setBranchCode((String) row.get("BRANCH_CODE"));
					branches.setTimings((String) row.get("TIMINGS"));
					branches.setReason((String) row.get("REASON"));
					branches.setBranchCode((String) row.get("BRANCH_CODE"));
					branches.setLatitude(row.get("LATITUDE").toString());
					branches.setLongitude(row.get("LONGITUDE").toString());
					transObjList.add(branches);
				}
			}
		}
		return transObjList;
	}

	public List<Cities> getCityList() {
		List<Cities> transObjList = new ArrayList<Cities>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETCITYLIST"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString());
			logWriter.info("CITYDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for CITYDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Cities cities = new Cities();
				cities.setCityName((String) row.get("CITY_NAME"));
				cities.setCityCode((String) row.get("CITY_CODE"));
				transObjList.add(cities);
			}
		}
		return transObjList;
	}

	public List<Branches> searchBranch(Branches branch) {
		List<Branches> branchList = new ArrayList<Branches>();
		List<Branches> branchSearchList = new ArrayList<Branches>();
		branchList = getBranchDetails();
		// no name,no ID
		try {
			if ((branch.getBranchCode().toLowerCase().equals("") || branch
					.getBranchCode().toLowerCase().equals(null))
					&& (branch.getBranchName().toLowerCase().equals("") || branch
							.getBranchName().toLowerCase().equals(null))) {
				if (branch.getStatus().equals("All"))
					return branchList;
				else {
					for (Branches branches : branchList) {
						if (branches.getStatus().contains(branch.getStatus()))
							branchSearchList.add(branches);
					}
					return branchSearchList;
				}
			} else if (branch.getBranchCode().toLowerCase().equals("") // no ID
					|| branch.getBranchCode().toLowerCase().equals(null)) {
				for (Branches branches : branchList) {
					if (branches.getBranchName().toLowerCase()
							.contains(branch.getBranchName().toLowerCase())) {
						if (branches.getStatus().contains(branch.getStatus())
								|| branch.getStatus().equals("All")) {
							branchSearchList.add(branches);
						}
					}
				}// no name
			} else if (branch.getBranchName().toLowerCase().equals("")
					|| branch.getBranchName().toLowerCase().equals(null)) {
				for (Branches branches : branchList) {
					if (branches.getBranchCode().toLowerCase()
							.contains(branch.getBranchCode().toLowerCase())) {
						if (branches.getStatus().contains(branch.getStatus())
								|| branch.getStatus().equals("All")) {
							branchSearchList.add(branches);
						}
					}
				}
			} else {
				for (Branches branches : branchList) { // both present
					if (branches.getBranchName().toLowerCase()
							.contains(branch.getBranchName().toLowerCase())
							&& branches
									.getBranchCode()
									.toLowerCase()
									.contains(
											branch.getBranchCode()
													.toLowerCase())) {
						if (branches.getStatus().contains(branch.getStatus())
								|| branch.getStatus().equals("All")) {
							branchSearchList.add(branches);
						}
					}
				}
			}
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for branchDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		return branchSearchList;
	}

	public int authorBranch(Branches item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("AUTHORBRANCH"));
		Integer count = 0;
		try {
			if (item.getStatus().equals("New")) {
				count = jdbcTemplate.update(sql.toString(), new Object[] { "Y",
						item.getChecker(), item.getCheckerDt(), "Authorized",
						item.getBranchCode() });
			} else if (item.getStatus().equals("Modified")) {
				count = updateBranch(item);
				if (count == 1) {
					count = deleteBranch(item);
				}
			} else if (item.getStatus().equals("Deleted")) {
				Branches item2 = new Branches();
				item2.setBranchCode(item.getBranchCode());
				item2.setChecker(item.getChecker());
				item2.setCheckerDt(item.getCheckerDt());
				// item2.setStatus("Authorized");
				count = deleteBranch(item);
				count = changeStatus(item2);
			}
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	private Integer changeStatus(Branches item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("CHANGEBRANCHSTATUS"));
		Integer count = 0;
		try {
			count = jdbcTemplate.update(
					sql.toString(),
					new Object[] { "N", "Deleted and Authorized",
							item.getChecker(), item.getCheckerDt(),
							item.getBranchCode(), "Authorized" });
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public int deleteBranch(Branches item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("DELETEBRANCH"));
		Integer count = 0;
		try {
			count = jdbcTemplate.update(sql.toString(),
					new Object[] { item.getBranchCode(), item.getStatus() });
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public int updateBranch(Branches branch) {
		StringBuilder sql = new StringBuilder();
		// UPDATE IMCA_branch_DETAILS SET
		// branch_NAME=?,PROVINCE_CODE=?,MARKER=?,MAKER_DT=? where branch_CODE=?
		sql.append(imbcaproperties.get("UPDATEBRANCH"));
		Integer count = 0;
		try {
			count = jdbcTemplate.update(
					sql.toString(),
					new Object[] { branch.getActive(), branch.getBranchName(),
							branch.getAddress(), branch.getCityCode(),
							branch.getPostalCode(), branch.getTelephone(),
							branch.getFax(), branch.getLatitude(),
							branch.getLongitude(), branch.getProvinceCode(),
							branch.getMaker(), branch.getMakerDt(),
							"Authorized", branch.getTimings(),
							branch.getBranchCode() });
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public int addBranch(Branches item, String param) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("ADDBRANCH"));
		Integer count = 0;
		try {
			if (item.getStatus().equals("New") && param.equals("add")) {
				List<Branches> items = getBranchDetails();
				for (Branches branches : items) {
					if (branches.getBranchCode().equals(item.getBranchCode())) {
						count = 2;
						return (int) count;
					}
					if (branches.getBranchName().equals(item.getBranchName())) {
						count = 3;
						return (int) count;
					}
				}
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { "N", item.getBranchCode(),
								item.getBranchName(), item.getAddress(),
								item.getCityCode(), item.getProvinceCode(),
								item.getPostalCode(), item.getTelephone(),
								item.getFax(), item.getLatitude(),
								item.getLongitude(), item.getTimings(),
								item.getMaker(), item.getMakerDt(), "New" });
			} else if (item.getStatus().equals("Authorized")
					&& param.equals("Modified")) {
				Branches branches = getBranchWithBranchCode(item
						.getBranchCode());
				count = jdbcTemplate
						.update(sql.toString(),
								new Object[] { item.getActive(),
										branches.getBranchCode(),
										branches.getBranchName(),
										item.getAddress(), item.getCityCode(),
										item.getProvinceCode(),
										branches.getPostalCode(),
										branches.getTelephone(),
										branches.getFax(),
										branches.getLatitude(),
										branches.getLongitude(),
										branches.getTimings(), item.getMaker(),
										item.getMakerDt(), "Modified" });
			} else if (item.getStatus().equals("Authorized")
					&& param.equals("Delete")) {
				Branches branch = getBranchWithBranchCode(item.getBranchCode());
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { "N", item.getBranchCode(),
								branch.getBranchName(), branch.getAddress(),
								branch.getCityCode(), branch.getProvinceCode(),
								branch.getPostalCode(), branch.getTelephone(),
								branch.getFax(), branch.getLatitude(),
								branch.getLongitude(), branch.getTimings(),
								branch.getMaker(), branch.getMakerDt(),
								"Deleted" });
			} else if (param.equals("Reject")) {
				Branches branch = getBranchWithBranchCode(item.getBranchCode());
				int branchCount = rejectBranchCount(item.getBranchCode());
				if (branchCount > 0) {
					String status = item.getStatus();
					item.setStatus("Rejected");
					count = deleteBranch(item);
					item.setStatus(status);
				}
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { item.getActive(), item.getBranchCode(),
								branch.getBranchName(), branch.getAddress(),
								branch.getCityCode(), branch.getProvinceCode(),
								branch.getPostalCode(), branch.getTelephone(),
								branch.getFax(), branch.getLatitude(),
								branch.getLongitude(), branch.getTimings(),
								branch.getMaker(), branch.getMakerDt(),
								"Rejected" });
				deleteBranch(item);
			}
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public int rejectBranch(Branches item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("REJECTBRANCH"));
		Integer count = 0;
		try {
			Branches branch = getBranchWithBranchCode(item.getBranchCode());
			int branchCount = rejectBranchCount(item.getBranchCode());
			if (branchCount > 0) {
				String status = item.getStatus();
				item.setStatus("Rejected");
				count = deleteBranch(item);
				item.setStatus(status);
			}
			count = jdbcTemplate.update(
					sql.toString(),
					new Object[] { item.getActive(), item.getBranchCode(),
							branch.getBranchName(), branch.getAddress(),
							branch.getCityCode(), branch.getProvinceCode(),
							branch.getPostalCode(), branch.getTelephone(),
							branch.getFax(), branch.getLatitude(),
							branch.getLongitude(), branch.getTimings(),
							branch.getMaker(), branch.getMakerDt(),
							branch.getChecker(), branch.getCheckerDt(),
							"Rejected" });
			deleteBranch(item);

			/*
			 * count = jdbcTemplate.update(sql.toString(), new Object[] {
			 * "Rejected", branch.getChecker(), branch.getCheckerDt(),
			 * branch.getBranchCode() });
			 */
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public int rejectBranchCount(String branchCode) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETREJECTEDBRANCH"));
		Integer count = 0;
		try {
			count = jdbcTemplate.queryForObject(sql.toString(), new Object[] {
					branchCode, "Rejected" }, Integer.class);
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("getting rejected count failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}
}
