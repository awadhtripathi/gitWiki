package com.icicibank.iMobileCA.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Logger;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.icicibank.iMobileCA.model.Parameters;

@Repository
public class ParameterMasterDAO {
	@Autowired
	JdbcTemplate jdbcTemplate;
	private static final Logger logWriter = Logger
			.getLogger(ParameterMasterDAO.class.getName());

	@Resource(name = "imbcaproperties")
	private Properties imbcaproperties;

	public List<Parameters> getParamDetails() {
		List<Parameters> transObjList = new ArrayList<Parameters>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETPARAMDETAILS").toString());

		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString());

			logWriter.info("paramDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for paramDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Parameters parameters = new Parameters();
				parameters.setParam((String) row.get("PARAM"));
				parameters.setParamValue((String) row.get("PARAM_VALUE"));
				transObjList.add(parameters);

			}
		}
		return transObjList;
	}
	public int updateParameter(Parameters list) {
		StringBuilder sql = new StringBuilder();
	
		sql.append(imbcaproperties.get("UPDATEFIELDINPARAM"));
		Integer count = 0;
		//final List<AddFields> request=list;
		try {
			count = jdbcTemplate.update(sql.toString(), new Object[] { list.getParamValue(),list.getMaker(),list.getMakerDt(),list.getParam()});
		}
		catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		}
		catch(Exception e){
			logWriter.info("error"+e);
		}
		return (int) count;
	}
}
