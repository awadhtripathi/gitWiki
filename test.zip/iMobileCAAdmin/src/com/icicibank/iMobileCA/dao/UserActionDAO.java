package com.icicibank.iMobileCA.dao;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.icicibank.iMobileCA.model.Attempts;
import com.icicibank.iMobileCA.model.AuditLog;
import com.icicibank.iMobileCA.model.EchequeDepositBean;
import com.icicibank.iMobileCA.model.ExchangeATMs;
import com.icicibank.iMobileCA.model.Limits;
import com.icicibank.iMobileCA.util.CommonUtil;



@Repository
@SuppressWarnings("unchecked")
public class UserActionDAO {
	//private HibernateTemplate hibernateTemplate;
	@Autowired JdbcTemplate jdbcTemplate;
	private static final Logger logWriter = Logger.getLogger(UserActionDAO.class.getName());
			
	/*@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		hibernateTemplate = new HibernateTemplate(sessionFactory);
	}*/
	@Resource(name = "imbcaproperties")
	private Properties imbcaproperties;
	
	public void addField(Limits list) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("ADDFIELD"));
		Integer count = 0;
		//final List<AddFields> request=list;
		try {
			count = jdbcTemplate.update(sql.toString(), new Object[] { list.getLimitType(),list.getLimit() });
		}
		catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		}
		catch(Exception e){
			logWriter.info("error"+e);
		}
		//return (int) count;
	}
	/*public int updateField(Limits list) {
		StringBuilder sql = new StringBuilder();
		//UPDATE IMCA_TRANSATION_RANGE SET CHANGED_VALUE='3',AUTHORING_STATUS='N' WHERE LIMIT_TYPE='SPOT_NOISE';
		sql.append(imbcaproperties.get("UPDATEFIELD"));
		Integer count = 0;
		//final List<AddFields> request=list;
		try {
			count = jdbcTemplate.update(sql.toString(), new Object[] { list.getChangedValue(),list.getAuthoringStatus(),list.getMaker(),list.getMakerDt(),list.getLimitType()});
		}
		catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		}
		catch(Exception e){
			logWriter.info("error"+e);
		}
		return (int) count;
	}*/
	public int updateField(final List<Limits> attempts) {
		/*StringBuilder sql = new StringBuilder();
		//UPDATE IMCA_TRANSATION_RANGE SET CHANGED_VALUE=?,AUTHORING_STATUS=?,MAKER=?,MAKERDT=? WHERE LIMIT_TYPE=?
		sql.append(imbcaproperties.get("AUTHORSTATUS"));*/
		//Integer count = 0;
			String sql="UPDATE IMCA_TRANSATION_RANGE SET CHANGED_VALUE=?,AUTHORING_STATUS=?,MAKER=?,MAKERDT=? WHERE LIMIT_TYPE=?";
			int[] count=jdbcTemplate.batchUpdate(sql.toString(), new BatchPreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						Limits limit = attempts.get(i);
						ps.setString(1,limit.getChangedValue());
						ps.setString(2,limit.getAuthoringStatus());
						ps.setString(3,limit.getMaker());
						ps.setTimestamp(4,limit.getMakerDt());
						ps.setString(5, limit.getLimitType());
					}

					@Override
					public int getBatchSize() {
						return attempts.size();
					}
				  });
		return (int) count.length;
	}
		
		public int updateABMData(ExchangeATMs list) {
		StringBuilder sql = new StringBuilder();
		//INSERT INTO ABM_DETAILS (LONGITUDE,LATITUDE,BRANCH_NAME,ADDRESS) values('-83.1082678','42.0999419','Windsor Family Credit Union','322 Sandwich St. S., Amherstburg, Ontario N9V 0C7')
		sql.append(imbcaproperties.get("INSERTABMDATA"));
		Integer count = 0;
		//final List<AddFields> request=list;
		try {
			count = jdbcTemplate.update(sql.toString(), new Object[] { list.getLONGITUDE(),list.getLATITUDE(),list.getBRANCH_NAME(),list.getADDRESS()});
		}
		catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		}
		catch(Exception e){
			logWriter.info("error"+e);
		}
		return (int) count;
	}
	/*public int authorField(Limits list) {
		StringBuilder sql = new StringBuilder();
		//UPDATE IMCA_TRANSATION_RANGE SET LIMIT='3',AUTHORING_STATUS='Y' WHERE LIMIT_TYPE='SPOT_NOISE';
		sql.append(imbcaproperties.get("AUTHORFIELD"));
		Integer count = 0;
		//final List<AddFields> request=list;
		try {
			count = jdbcTemplate.update(sql.toString(), new Object[] { list.getChangedValue(),"Y",list.getChecker(),list.getCheckerDt(),list.getLimitType()});
		}
		catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		}
		catch(Exception e){
			logWriter.info("error"+e);
		}
		return (int) count;
	}*/
	public int authorField(final List<Limits> attempts) {
		/*StringBuilder sql = new StringBuilder();
		//UPDATE IMCA_TRANSATION_RANGE SET CHANGED_VALUE=?,AUTHORING_STATUS=?,MAKER=?,MAKERDT=? WHERE LIMIT_TYPE=?
		sql.append(imbcaproperties.get("AUTHORSTATUS"));*/
		//Integer count = 0;
			String sql="UPDATE IMCA_TRANSATION_RANGE SET LIMIT=?,AUTHORING_STATUS=?,CHECKER=?,CHECKER_DT=? WHERE LIMIT_TYPE=?";
			int[] count=jdbcTemplate.batchUpdate(sql.toString(), new BatchPreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						Limits limit = attempts.get(i);
						ps.setString(1,limit.getChangedValue());
						ps.setString(2,limit.getAuthoringStatus());
						ps.setString(3,limit.getChecker());
						ps.setTimestamp(4,limit.getCheckerDt());
						ps.setString(5, limit.getLimitType());
					}

					@Override
					public int getBatchSize() {
						return attempts.size();
					}
				  });
		return (int) count.length;
	}
	public int authorField1(Limits list) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("UPDATEFIELDINLIMITS"));
		Integer count = 0;
		//final List<AddFields> request=list;
		try {
			count = jdbcTemplate.update(sql.toString(), new Object[] { list.getChangedValue(),list.getChecker(),list.getCheckerDt(),list.getLimitType()});
		}
		catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		}
		catch(Exception e){
			logWriter.info("error"+e);
		}
		return (int) count;
	}
	public int authorLimit(final List<Limits> attempts) {
		/*StringBuilder sql = new StringBuilder();
		//UPDATE IMCA_TRANSATION_RANGE SET CHANGED_VALUE=?,AUTHORING_STATUS=?,MAKER=?,MAKERDT=? WHERE LIMIT_TYPE=?
		sql.append(imbcaproperties.get("AUTHORSTATUS"));*/
		//Integer count = 0;
			String sql="UPDATE IMCA_TRANSACTION_LIMITS SET LIMIT=?,CHECKER=?,CHECKER_DT=? WHERE LIMIT_TYPE=?";
			int[] count=jdbcTemplate.batchUpdate(sql.toString(), new BatchPreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						Limits limit = attempts.get(i);
						ps.setString(1,limit.getChangedValue());
						ps.setString(2,limit.getAuthoringStatus());
						ps.setString(3,limit.getChecker());
						ps.setTimestamp(4,limit.getCheckerDt());
						ps.setString(5, limit.getLimitType());
					}

					@Override
					public int getBatchSize() {
						return attempts.size();
					}
				  });
		return (int) count.length;
	}
	/*public int checkField(Limits request) {
		StringBuilder sql = new StringBuilder();
		// sql.append("SELECT count(*) from STELLAR_PAYEE_MASTER where PAYER_USER_ID=lower(?) and PAYEE_ACCOUNT_NO=?");
		sql.append(imbcaproperties.get("CHECKFIELDEXIST"));
		Integer count = 0;
		try {
			count = jdbcTemplate.queryForObject(sql.toString(), Integer.class, new Object[] { request.getLimitType() });
		}
		catch (EmptyResultDataAccessException ex) {
			logWriter.info("No data found for this user..");
		}
		return (int) count;
	}*/
	/*public Long getCuttOffTime() {
		Long time=null;
		Map<String, Object> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETFILECUTTOFFTIME"));
		try {
			fieldNames = jdbcTemplate.queryForMap(sql.toString());
			logWriter.info("CITYDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for CITYDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if(!fieldNames.isEmpty()){
			time=Long.parseLong((String)fieldNames.get("LIMIT"));
		}
		return time;
	}*/
	public String getCuttOffTime() {
		String time=null;
		Map<String, Object> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETFILECUTTOFFTIME"));
		try {
			fieldNames = jdbcTemplate.queryForMap(sql.toString());
			logWriter.info("CITYDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for CITYDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if(!fieldNames.isEmpty()){
			time=(String)fieldNames.get("LIMIT");
		}
		return time;
	}
	public List<Limits> getFields() {
		List<Limits> transObjList = new ArrayList<Limits>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETFIELD"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString());
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Limits limits = new Limits();
				limits.setLimitType((String) row.get("LIMIT_TYPE"));
				limits.setLimitValue((String) row.get("LIMIT_VALUE"));
				limits.setLimit((String) row.get("LIMIT"));
				limits.setActive((String) row.get("ACTIVE"));
				limits.setTxnType((String) row.get("TXN_TYPE"));
				limits.setAuthoringStatus((String) row.get("AUTHORING_STATUS"));
				limits.setChangedValue((String) row.get("CHANGED_VALUE"));
				limits.setMaker((String) row.get("MAKER"));
				limits.setMakerDt((Timestamp) row.get("MAKERDT"));
				transObjList.add(limits);
			}
		}
		return transObjList;
	}
	
	public List<Attempts> getZones() {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETZONES"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString());
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setClearingZone((String) row.get("CLEARING_ZONE"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	
	/*public int getEchequeAttempts(Attempts list) {
		StringBuilder sql = new StringBuilder();
		//INSERT INTO ABM_DETAILS (LONGITUDE,LATITUDE,BRANCH_NAME,ADDRESS) values('-83.1082678','42.0999419','Windsor Family Credit Union','322 Sandwich St. S., Amherstburg, Ontario N9V 0C7')
		sql.append(imbcaproperties.get("INSERTABMDATA"));
		Integer count = 0;
		//final List<AddFields> request=list;
		try {
			count = jdbcTemplate.update(sql.toString(), new Object[] { list.getLONGITUDE(),list.getLATITUDE(),list.getBRANCH_NAME(),list.getADDRESS()});
		}
		catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		}
		catch(Exception e){
			logWriter.info("error"+e);
		}
		return (int) count;
	}*/
	public List<Attempts> getFailureEchequeAttempts(Date fromDate,Date toDate) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GENERATEFAILUREATTEMPTSREPORT"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),fromDate,toDate);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Failed");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	public List<Attempts> getEchequeAttempts(Date fromDate,Date toDate,String status) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GENERATEATTEMPTSREPORT"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),fromDate,toDate,status);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Pending");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				//attempts.setStatus((String) row.get("STATUS"));
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	public List<Attempts> getReportForCustomerActivitiesWithStatus(Date fromDate,Date toDate) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		List<Map<String, Object>> fieldNames1 = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GENERATEFAILUREATTEMPTSREPORT"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),fromDate,toDate);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for getReportForCustomerActivities.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Failed");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		StringBuilder sql1 = new StringBuilder();
		sql1.append(imbcaproperties.get("GENERATEATTEMPTSREPORTFORALL"));
		try {
			fieldNames1 = jdbcTemplate.queryForList(sql1.toString(),fromDate,toDate);
			logWriter.info("fieldNames1 size:  " + fieldNames1.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for getReportForCustomerActivities.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames1 != null) {
			for (Map<String, Object> row : fieldNames1) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Pending");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				//attempts.setStatus((String) row.get("STATUS"));
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	public List<Attempts> getPendingEchequeAttempts(Date fromDate,Date toDate,String status) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETECHEQUEDETAILS1"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),fromDate,toDate,status);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Pending");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				//attempts.setStatus((String) row.get("STATUS"));
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	public List<Attempts> getPendingEchequeAttemptswithMobile(Date fromDate,Date toDate,String mobileNo) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETECHEQUEDETAILSWITHMOBILE"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),fromDate,toDate,mobileNo);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Pending");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				//attempts.setStatus((String) row.get("STATUS"));
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	public List<Attempts> getReportForCustomerActivities(Date fromDate,Date toDate,String mobileNumber) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		List<Map<String, Object>> fieldNames1 = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GENERATECUSTOMERSUCCESSREPORT"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),fromDate,toDate,mobileNumber);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for getReportForCustomerActivities.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Pending");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				//attempts.setStatus((String) row.get("STATUS"));
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		StringBuilder sql1 = new StringBuilder();
		sql1.append(imbcaproperties.get("GENERATECUSTOMERFAILUREREPORT"));
		try {
			fieldNames1 = jdbcTemplate.queryForList(sql1.toString(),fromDate,toDate,mobileNumber);
			logWriter.info("fieldNames1 size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for getReportForCustomerActivities.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames1 != null) {
			for (Map<String, Object> row : fieldNames1) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Failed");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	public List<Attempts> getCustomerSuccessReport(Date fromDate,Date toDate,String mobileNumber,String status) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GENERATEPROCESSEDCUSTOMERREPORT"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),fromDate,toDate,mobileNumber,status);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Pending");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				//attempts.setStatus((String) row.get("STATUS"));
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	public List<Attempts> getCustomerFailureReport(Date fromDate,Date toDate,String mobileNumber) {
		List<Attempts> transObjList = new ArrayList<Attempts>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GENERATECUSTOMERFAILUREREPORT"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),fromDate,toDate,mobileNumber);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Attempts attempts = new Attempts();
				attempts.setCIFNumber((String) row.get("CIFNUMBER"));
				attempts.setMobileNo((String) row.get("MOBILENO"));
				attempts.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				attempts.setChequeDate((Timestamp) row.get("CHEQUE_DATE"));
				attempts.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				attempts.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				attempts.setTransitNumber((String) row.get("TRANSIT_NUMBER"));
				attempts.setInstitutionId((String) row.get("INSTITUTION_ID"));
				attempts.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				attempts.setMemo((String) row.get("MEMO"));
				attempts.setSubmittedDate((Timestamp) row.get("SUBMITTED_DATE"));
				attempts.setReason((String) row.get("REASON"));
				attempts.setMaker((String) row.get("MAKER"));
				attempts.setMakerDt((Timestamp) row.get("MAKERDT"));
				if(row.get("STATUS")==null ||row.get("STATUS")==""){
					attempts.setStatus("Failed");
				}else{
					attempts.setStatus((String)row.get("STATUS"));
				}
				attempts.setReferenceNumber((String) row.get("REFERENCENUMBER"));
				transObjList.add(attempts);
			}
		}
		return transObjList;
	}
	/*public List<Limits> getFieldsByType(Limits limit) {
		List<Limits> transObjList = new ArrayList<Limits>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETFIELDByType"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),limit.getLimitType());
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Limits limits = new Limits();
				limits.setLimitType((String) row.get("LIMIT_TYPE"));
				limits.setLimitValue((String) row.get("LIMIT_VALUE"));
				limits.setLimit((String) row.get("LIMIT"));
				limits.setActive((String) row.get("ACTIVE"));
				limits.setTxnType((String) row.get("TXN_TYPE"));
				limits.setAuthoringStatus((String) row.get("AUTHORING_STATUS"));
				limits.setChangedValue((String) row.get("CHANGED_VALUE"));
				limits.setMaker((String) row.get("MAKER"));
				limits.setMakerDt((Timestamp) row.get("MAKERDT"));
				transObjList.add(limits);
			}
		}
		return transObjList;
	}*/
	public List<Limits> getFieldsForAuthoring(String userId) {
		List<Limits> transObjList = new ArrayList<Limits>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETFIELDSFORAUTHOR"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),userId);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Limits limits = new Limits();
				limits.setLimitType((String) row.get("LIMIT_TYPE"));
				limits.setLimitValue((String) row.get("LIMIT_VALUE"));
				limits.setLimit((String) row.get("LIMIT"));
				limits.setActive((String) row.get("ACTIVE"));
				limits.setTxnType((String) row.get("TXN_TYPE"));
				limits.setAuthoringStatus((String) row.get("AUTHORING_STATUS"));
				limits.setChangedValue((String) row.get("CHANGED_VALUE"));
				limits.setMaker((String) row.get("MAKER"));
				limits.setMakerDt((Timestamp) row.get("MAKERDT"));
				transObjList.add(limits);
			}
		}
		return transObjList;
	}
	
	/*public List<Limits> getFieldsForAuthor() {
		List<Limits> transObjList = new ArrayList<Limits>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETFIELDSFORAUTHORING"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString());
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Limits limits = new Limits();
				limits.setLimitType((String) row.get("LIMIT_TYPE"));
				limits.setLimitValue((String) row.get("LIMIT_VALUE"));
				limits.setLimit((String) row.get("LIMIT"));
				limits.setActive((String) row.get("ACTIVE"));
				limits.setTxnType((String) row.get("TXN_TYPE"));
				limits.setAuthoringStatus((String) row.get("AUTHORING_STATUS"));
				limits.setChangedValue((String) row.get("CHANGED_VALUE"));
				limits.setMaker((String) row.get("MAKER"));
				limits.setMakerDt((Timestamp) row.get("MAKERDT"));
				transObjList.add(limits);
			}
		}
		return transObjList;
	}*/
	public List<List<EchequeDepositBean>> generateRequestPacketData(Timestamp toDate) throws ParseException
	{//zone
		logWriter.info("Inside generateRequestPacket method of EChequeDepositDAOImpl");
		logWriter.info("tOdATE:"+toDate);
		List<List<EchequeDepositBean>> transObjList = new ArrayList<List<EchequeDepositBean>>();
		List<EchequeDepositBean> zone1 = new ArrayList<EchequeDepositBean>();
		List<EchequeDepositBean> zone2 = new ArrayList<EchequeDepositBean>();
		List<EchequeDepositBean> icicizone = new ArrayList<EchequeDepositBean>();	
		
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		//SELECT * FROM IMCA_ECHEQUE_DETAILS where SUBMITTED_DATE between '31-10-16' and '1-11-16' and STATUS IS NULL
		sql.append(imbcaproperties.get("GETECHEQUEDETAILS"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),toDate.toString(),"Pending");
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				EchequeDepositBean ebean = new EchequeDepositBean();
				ebean.setCusId((String) row.get("CUSTID"));
				ebean.setMobileNo((String) row.get("MOBILENO"));
				ebean.setChequeDate((Timestamp)row.get("CHEQUE_DATE"));
				ebean.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				ebean.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				ebean.setTransitNo((String) row.get("TRANSIT_NUMBER"));
				ebean.setInstitutionId((String) row.get("INSTITUTION_ID"));
				ebean.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				ebean.setMemo((String) row.get("MEMO"));
				ebean.setSubmittedDate((Timestamp)row.get("SUBMITTED_DATE"));
				/*String sub_date = (String)row.get("SUBMITTED_DATE");
				SimpleDateFormat datetimeFormatter1 = new SimpleDateFormat(
		                "yyyy-MM-dd hh:mm:ss");
				java.util.Date lFromDate1 = datetimeFormatter1.parse(sub_date);
				System.out.println("gpsdate :" + lFromDate1);
				Timestamp fromTS1 = new Timestamp(lFromDate1.getTime());
				logWriter.info("time : "+row.get("SUBMITTED_DATE"));
				String sub_date = (String)row.get("SUBMITTED_DATE");
				try {
					CommonUtil.getDateTime(sub_date, "dd-MM-yyyy hh:mm");
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				Timestamp ts = Timestamp.valueOf((String)row.get("SUBMITTED_DATE"));
				ebean.setSubmittedDate(fromTS1);
				//ebean.setSubmittedDate((Timestamp)row.get("SUBMITTED_DATE"));
				logWriter.info("hours : "+ebean.getSubmittedDate().getHours());
				logWriter.info("minutes :  "+ebean.getSubmittedDate().getMinutes());*/
				ebean.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
			//	ebean.setClearingZone((String) row.get("CLEARING_ZONE"));
				ebean.setReportCode((String) row.get("REPORT_CODE"));
				ebean.setTranCode((String) row.get("TRAN_CODE"));	
				ebean.setFrontImagePath((String) row.get("IMAGE_FRONT_LOCATION"));
				ebean.setBackImagePath((String) row.get("IMAGE_BACK_LOCATION"));
				ebean.setBackImageSize((String) row.get("IMAGE_BACK_SIZE"));
				ebean.setFrontImageSize((String) row.get("IMAGE_FRONT_SIZE"));
				ebean.setStatus((String) row.get("STATUS"));
				String zone = (String) row.get("CLEARING_ZONE");				
				ebean.setClearingZone(zone);
				if(zone.equalsIgnoreCase("OWMCAD4"))
				{
					logWriter.info("in OWMCAD4");
					zone1.add(ebean);
				}else if(zone.equalsIgnoreCase("OWMCAD5"))
				{
					logWriter.info("in OWMCAD5");
					zone2.add(ebean);
				}else{
					icicizone.add(ebean);
				}
			//	transObjList.add(ebean);	
			}
			if(zone1.size()>0)
			{
			transObjList.add(zone1);
			}
			if(zone2.size()>0)
			{
			transObjList.add(zone2);
			}
			if(icicizone.size()>0)
			{
			transObjList.add(icicizone);
			}
		}
		return transObjList;
	}
	public List<EchequeDepositBean> generateRequestPacketDataForZone(Timestamp toDate,String zone)
	{
		logWriter.info("Inside generateRequestPacket method of EChequeDepositDAOImpl");
		List<EchequeDepositBean> transObjList = new ArrayList<EchequeDepositBean>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GENERATEBATCHFORZONE"));
		logWriter.info("toDate:  " + toDate.toString());
		try {
			String str = CommonUtil.getDateTime(toDate.getTime(),"YYYY-MM-dd HH:mm:ss","EST");
			logWriter.info("strDate:  " + str);
			fieldNames = jdbcTemplate.queryForList(sql.toString(),str,zone,"Pending");
			logWriter.info("jdbcTemplate :  " + jdbcTemplate.toString());
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
			e.printStackTrace();
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				EchequeDepositBean ebean = new EchequeDepositBean();
				ebean.setCusId((String) row.get("CUSTID"));
				ebean.setMobileNo((String) row.get("MOBILENO"));
				ebean.setChequeDate((Timestamp)row.get("CHEQUE_DATE"));
				ebean.setChequeAmount((BigDecimal) row.get("CHEQUE_AMOUNT"));
				ebean.setChequeNumber((String) row.get("CHEQUE_NUMBER"));
				ebean.setTransitNo((String) row.get("TRANSIT_NUMBER"));
				ebean.setInstitutionId((String) row.get("INSTITUTION_ID"));
				ebean.setIssuerAccNo((String) row.get("ISSUER_ACC_NO"));
				ebean.setMemo((String) row.get("MEMO"));
				ebean.setSubmittedDate((Timestamp)row.get("SUBMITTED_DATE"));
				ebean.setBeneficiaryAccount((String) row.get("BENEFICIARY_ACCOUNT"));
				ebean.setClearingZone(zone);
				ebean.setReportCode((String) row.get("REPORT_CODE"));
				ebean.setTranCode((String) row.get("TRAN_CODE"));	
				ebean.setFrontImagePath((String) row.get("IMAGE_FRONT_LOCATION"));
				ebean.setBackImagePath((String) row.get("IMAGE_BACK_LOCATION"));
				ebean.setBackImageSize((String) row.get("IMAGE_BACK_SIZE"));
				ebean.setFrontImageSize((String) row.get("IMAGE_FRONT_SIZE"));
				ebean.setStatus((String) row.get("STATUS"));
				transObjList.add(ebean);	
			}
		}
		return transObjList;
	}
	public String getLastLogin(String userId){
		 String LastLoginTime=null;
		 try{
			 String query1 ="select LAST_LOGIN_DATE from IMCA_ADMIN_DETAILS where upper(USER_ID)=upper(?)";	
			 LastLoginTime=jdbcTemplate.queryForObject(query1, String.class, new Object[] { userId });
		 }
		 catch (EmptyResultDataAccessException ex) {
				logWriter.info("No record found for the user"+userId);
			}
			catch(Exception e){
				logWriter.info("error"+e);
			}
		return LastLoginTime;
	}
	public int updateLastLogin(String userId,String password,Timestamp currentTime){
		 int result = 0;
		 //String LastLoginTime=null;
		 try{
			 //jdbcTemplate = new JdbcTemplate(DBConnection.getDbConnection());
			/* String query1 ="select  LAST_LOGIN_DATE from IMCA_ADMIN_DETAILS where USER_ID=? ";	
			 LastLoginTime=jdbcTemplate.queryForObject(query1, String.class, new Object[] { userId.toLowerCase() });*/
			 //java.util.Date utilDate = new java.util.Date();.
			 /*Calendar cal = Calendar.getInstance();
			 cal.setTime(utilDate);
			 cal.set(Calendar.MILLISECOND, 0);
			 Timestamp currentTime = new java.sql.Timestamp(utilDate.getTime());
			 System.out.println(new java.sql.Timestamp(utilDate.getTime()));*/
			 String query = "update IMCA_ADMIN_DETAILS uld set uld.LAST_LOGIN_DATE=? where uld.USER_ID=? ";
			 //String query = "update IMCA_ADMIN_DETAILS uld set uld.LAST_LOGIN_DATE=?,uld.USER_PASS=? where uld.USER_ID=? ";
			 //java.util.Date date = new java.util.Date();
			// result =jdbcTemplate.update(query,new Object[]{currentTime,password,userId.toLowerCase()});
			 result =jdbcTemplate.update(query,new Object[]{currentTime,userId.toUpperCase()});
			 if(result == 0){
				// String queryStr = "insert into IMCA_ADMIN_DETAILS (USER_ID,LAST_LOGIN_DATE,USER_PASS) values (?,?,?)";
				 String queryStr = "insert into IMCA_ADMIN_DETAILS (USER_ID,LAST_LOGIN_DATE) values (?,?)";
				 //result = jdbcTemplate.update(queryStr,new Object[]{userId.toLowerCase(),currentTime,password});
				 result = jdbcTemplate.update(queryStr,new Object[]{userId.toUpperCase(),currentTime});
			 }
			 
		 }
		catch (Exception e) {			
			e.printStackTrace();

		}
		return result;
	}
	public int updateEchequeDetails(EchequeDepositBean v){
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("UPDATEECHEQUEDETAILS"));
		Integer count = 0;
		try {
			count = jdbcTemplate.update(sql.toString(), new Object[] { v.getStatus(),v.getChequeNumber() });
		}
		catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		}
		catch(Exception e){
			logWriter.info("error"+e);
		}
		return (int) count;
	}
	
	public int updateAuditLogStatus(AuditLog auditlist){
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("ADDAUDITLOG"));
		Integer count = 0;
		try {
			count = jdbcTemplate.update(sql.toString(), new Object[] {auditlist.getTableName(), auditlist.getRequest(),auditlist.getMakerCd(),auditlist.getMakerDt(),auditlist.getAuthorCd(),auditlist.getAuthorDt(),auditlist.getOperation() });
		}
		catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		}
		catch(Exception e){
			logWriter.info("error"+e);
		}
		return (int) count;
	}
	public int updateAuditLogStatus(final List<AuditLog> attempts) {
		/*StringBuilder sql = new StringBuilder();
		//INSERT INTO ADMIN_AUDIT_TRAIL_DTL (TABLE_NAME,COLUMN_NAME,OLD_VALUE,NEW_VALUE,BANK_ID,MAKER_CD,MAKER_DT,AUTHOR_CD,AUTHOR_DT,AUTH_STATUS)  VALUES(?,?,?,?,?,?,?,?,?,?)
		sql.append(imbcaproperties.get("AUTHORSTATUS"));*/
		//Integer count = 0;
			String sql="INSERT INTO ADMIN_AUDIT_TRAIL_DTL (TABLE_NAME,COLUMN_NAME,OLD_VALUE,NEW_VALUE,USER_ID,USER_ROLE,USER_DT,AUTH_STATUS)  VALUES(?,?,?,?,?,?,?,?)";
			int[] count=jdbcTemplate.batchUpdate(sql.toString(), new BatchPreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						AuditLog attempt = attempts.get(i);
						ps.setString(1,attempt.getTableName());
						/*ps.setString(2,attempt.getColumnName());
						ps.setString(3,attempt.getOldValue());
						ps.setString(4,attempt.getNewValue());
						ps.setString(5, attempt.getUserId());
						ps.setString(6, attempt.getUserRole());
						ps.setTimestamp(7,attempt.getUserDt());
						ps.setString(8, attempt.getAuthorCd());
						ps.setTimestamp(9,attempt.getAuthorDt());
						ps.setString(8, attempt.getAuthStatus());*/
					}

					@Override
					public int getBatchSize() {
						return attempts.size();
					}
				  });
		return (int) count.length;
	}
	/*public List<AdminUser> getAdminUserDtls(String adminId) {
		List<AdminUser> transObjList = new ArrayList<AdminUser>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETADMINDETAILS"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),adminId);
			logWriter.info("fieldNames size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for MeraIMobile account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				AdminUser adminUser=new AdminUser();
				adminUser.setUserId((String) row.get("USER_ID"));
				adminUser.setUserName((String) row.get("USER_NAME"));
				adminUser.setUserPwd((String) row.get("USER_PASS"));
				adminUser.setLastLogin((Timestamp) row.get("LAST_LOGIN_DATE"));
				transObjList.add(adminUser);
			}
		}
		return transObjList;
	}*/
	
}
