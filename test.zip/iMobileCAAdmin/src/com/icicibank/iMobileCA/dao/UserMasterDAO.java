package com.icicibank.iMobileCA.dao;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Logger;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.icicibank.iMobileCA.model.MenuItem;
import com.icicibank.iMobileCA.model.Users;

@Repository
public class UserMasterDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;
	private static final Logger logWriter = Logger
			.getLogger(UserMasterDAO.class.getName());

	@Resource(name = "imbcaproperties")
	private Properties imbcaproperties;

	public List<Users> getuserDetails() {
		List<Users> transObjList = new ArrayList<Users>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETUSERDETAILS").toString());

		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString());

			logWriter.info("userDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for userDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				Users users = new Users();
				users.setUserIdentity((String) row.get("USER_IDENTITY"));
				users.setUserName((String) row.get("USER_NAME"));
				users.setEmployeeNo((String) row.get("EMPLOYEE_NO"));
				users.setUserRole((String) row.get("USER_ROLE"));
				users.setStatus((String) row.get("STATUS"));
				users.setActiveStatus((String) row.get("ACTIVE_STATUS"));
				users.setValidUpto((String) row.get("VALID_UPTO"));
				users.setIsAdmin((String) row.get("ISADMIN"));
				users.setDisableFlage((String) row.get("DISABLE_FLAGE"));
				users.setMaker((String) row.get("MAKER"));
				users.setMakerDt((Timestamp) row.get("MAKER_DT"));

				transObjList.add(users);

			}
		}
		return transObjList;
	}

	public List<Users> getuserDetailsForAuthorization(String userId) {
		List<Users> transObjList = new ArrayList<Users>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETUSERDETAILSFORAUTHOR"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),
					new Object[] { userId });

			logWriter.info("userDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for userDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				if (!row.get("STATUS").equals("Authorized")
						&& !row.get("STATUS").equals("Rejected")
						&& !row.get("STATUS").equals("Deleted and Authorized")) {
					Users users = new Users();
					users.setUserIdentity((String) row.get("USER_IDENTITY"));
					users.setUserName((String) row.get("USER_NAME"));
					users.setEmployeeNo((String) row.get("EMPLOYEE_NO"));
					users.setUserRole((String) row.get("USER_ROLE"));
					users.setStatus((String) row.get("STATUS"));
					users.setActiveStatus((String) row.get("ACTIVE_STATUS"));
					users.setValidUpto((String) row.get("VALID_UPTO"));
					users.setIsAdmin((String) row.get("ISADMIN"));
					users.setDisableFlage((String) row.get("DISABLE_FLAGE"));
					users.setMaker((String) row.get("MAKER"));
					users.setMakerDt((Timestamp) row.get("MAKER_DT"));// 13
					// users.setReason((String) row.get("REASON"));

					transObjList.add(users);
				}
			}
		}
		return transObjList;
	}

	private Integer changeStatus(Users user) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("CHANGEUSERSTATUS"));
		Integer count = 0;
		try {
			count = jdbcTemplate.update(sql.toString(),
					new Object[] { "Deleted and Authorized", user.getChecker(),
							user.getCheckerDt(), user.getUserIdentity(),
							"Authorized" });
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public int updateUser(Users item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("UPDATEUSER"));
		Integer count = 0;
		try {
			count = jdbcTemplate.update(
					sql.toString(),
					new Object[] { item.getEmployeeNo(), item.getUserRole(),
							item.getActiveStatus(), item.getValidUpto(),
							item.getIsAdmin(), item.getDisableFlage(),
							item.getMaker(), item.getMakerDt(),
							item.getChecker(), item.getCheckerDt(),
							item.getUserIdentity(), "Authorized" });
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public int addUser(Users item, String param) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("ADDUSER"));
		StringBuilder sql1 = new StringBuilder();
		sql1.append(imbcaproperties.get("ADDREJECT"));
		Integer count = 0;
		try {
			if (item.getStatus().equals("New") && param.equals("add")) {
				List<Users> items = getuserDetails();
				for (Users users : items) {
					if (users.getUserIdentity().equals(item.getUserIdentity())) {
						count = 2;
						return (int) count;
					}
					if (users.getUserName().equals(item.getUserName())) {
						count = 3;
						return (int) count;
					}
				}
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { item.getUserIdentity(),
								item.getUserName(), item.getEmployeeNo(),
								item.getUserRole(), "New",
								item.getActiveStatus(), item.getValidUpto(),
								item.getIsAdmin(), item.getDisableFlage(),
								item.getMaker(), item.getMakerDt() });
			} else if (item.getStatus().equals("Authorized")
					&& param.equals("Modified")) {
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { item.getUserIdentity(),
								item.getUserName(), item.getEmployeeNo(),
								item.getUserRole(), "Modified",
								item.getActiveStatus(), item.getValidUpto(),
								item.getIsAdmin(), item.getDisableFlage(),
								item.getMaker(), item.getMakerDt() });
			} else if (item.getStatus().equals("Authorized")
					&& param.equals("delete")) {
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { item.getUserIdentity(),
								item.getUserName(), item.getEmployeeNo(),
								item.getUserRole(), "Deleted",
								item.getActiveStatus(), item.getValidUpto(),
								item.getIsAdmin(), item.getDisableFlage(),
								item.getMaker(), item.getMakerDt() });
			} else if (param.equals("Reject")) {
				int userCount = rejectUserCount(item.getUserIdentity());
				if (userCount > 0) {
					String status = item.getStatus();
					item.setStatus("Rejected");
					deleteUser(item);
					item.setStatus(status);
				}
				count = jdbcTemplate.update(
						sql1.toString(),
						new Object[] { item.getUserIdentity(),
								item.getUserName(), item.getEmployeeNo(),
								item.getUserRole(), "Rejected",
								item.getActiveStatus(), item.getValidUpto(),
								item.getIsAdmin(), item.getDisableFlage(),
								item.getMaker(), item.getMakerDt(),
								item.getChecker(), item.getCheckerDt() });

				deleteUser(item);
			}

		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	/*
	 * Return no of rejected User
	 */
	public int rejectUserCount(String userIdentity) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETREJECTEDUSER"));
		Integer count = 0;
		try {
			count = jdbcTemplate.queryForObject(sql.toString(), new Object[] {
					userIdentity, "Rejected" }, Integer.class);
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("getting rejected count failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public int deleteUser(Users item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("DELETEUSER"));
		Integer count = 0;
		try {
			count = jdbcTemplate.update(sql.toString(),
					new Object[] { item.getUserIdentity(), item.getStatus() });
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public List<Users> searchUser(Users user) {
		List<Users> userList = new ArrayList<Users>();
		List<Users> userSearchList = new ArrayList<Users>();
		userList = getuserDetails();
		// no name,no ID

		try {
			if ((user.getUserIdentity().toLowerCase().equals("") || user
					.getUserIdentity().toLowerCase().equals(null))
					&& (user.getUserName().toLowerCase().equals("") || user
							.getUserName().toLowerCase().equals(null))) {
				if (user.getStatus().equals("All")) {
					return userList;
				} else if (user.getStatus().equals("Deleted")) {
					for (Users users : userList) {
						if (users.getStatus().equals(user.getStatus()))
							userSearchList.add(users);
					}
					return userSearchList;
				} else if (user.getStatus().equals("Authorized")) {
					for (Users users : userList) {
						if (users.getStatus().equals(user.getStatus()))
							userSearchList.add(users);
					}
					return userSearchList;
				} else if (user.getStatus().equals("Deleted and Authorized")) {
					for (Users users : userList) {
						if (users.getStatus().equals(user.getStatus()))
							userSearchList.add(users);
					}
					return userSearchList;
				} else {
					for (Users users : userList) {
						if (users.getStatus().contains(user.getStatus()))
							userSearchList.add(users);
					}
					return userSearchList;
				}

			} else if (user.getUserIdentity().toLowerCase().equals("") // no ID
					|| user.getUserIdentity().toLowerCase().equals(null)) {
				for (Users users : userList) {
					if (users.getUserName().toLowerCase()
							.contains(user.getUserName().toLowerCase())) {
						if (users.getStatus().contains(user.getStatus())
								|| user.getStatus().equals("All")) {
							userSearchList.add(users);
						}
					}
				}// no name
			} else if (user.getUserName().toLowerCase().equals("")
					|| user.getUserName().toLowerCase().equals(null)) {

				for (Users beans : userList) {

					if (beans.getUserIdentity().toLowerCase()
							.contains(user.getUserIdentity().toLowerCase())) {
						if (beans.getStatus().contains(user.getStatus())
								|| user.getStatus().equals("All")) {
							userSearchList.add(beans);

						}
					}
				}

			}
			// no name no status
			/*
			 * else if ((user.getUserName().equals("") ||
			 * user.getUserName().equals
			 * (null))&&(user.getStatus().equals("")||user
			 * .getStatus().equals(null))){
			 * 
			 * } for (Users beans : userList) {
			 * 
			 * if (beans.getUserIdentity() .contains(user.getUserIdentity())) {
			 * 
			 * 
			 * userSearchList.add(beans);
			 * 
			 * } } }
			 */

			else {
				for (Users users : userList) { // both present
					if (users.getUserName().toLowerCase()
							.contains(user.getUserName().toLowerCase())
							&& users.getUserIdentity()
									.toLowerCase()
									.contains(
											user.getUserIdentity()
													.toLowerCase())) {
						if (users.getStatus().contains(user.getStatus())
								|| user.getStatus().equals("All")) {
							userSearchList.add(users);
						}
					}
				}
			}

		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for userDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		return userSearchList;
	}

	public Users viewUser(Users user) throws ParseException {
		Users users = new Users();
		Map<String, Object> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("VIEWUSER"));
		try {
			fieldNames = jdbcTemplate.queryForMap(sql.toString(), new Object[] {
					user.getUserIdentity(), user.getStatus() });
			logWriter.info("USERDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for USERDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (!fieldNames.isEmpty()) {
			users.setUserIdentity((String) fieldNames.get("USER_IDENTITY"));
			users.setUserName((String) fieldNames.get("USER_NAME"));
			users.setEmployeeNo((String) fieldNames.get("EMPLOYEE_NO"));
			users.setValidUpto((String) fieldNames.get("VALID_UPTO"));
			users.setUserRole((String) fieldNames.get("USER_ROLE"));
			users.setActiveStatus((String) fieldNames.get("ACTIVE_STATUS"));
			users.setMaker((String) fieldNames.get("MAKER"));
			users.setStatus((String) fieldNames.get("STATUS"));
			users.setMakerDt((Timestamp) fieldNames.get("MAKERDT"));
			users.setChecker((String) fieldNames.get("CHECKER"));
			users.setCheckerDt((Timestamp) fieldNames.get("CHECKER_DT"));
			users.setIsAdmin((String) fieldNames.get("ISADMIN"));
			users.setDisableFlage((String) fieldNames.get("DISABLE_FLAGE"));

		}
		return users;
	}

	public Users viewUserForMaintenance(Users user) {
		Users users = new Users();
		Map<String, Object> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("VIEWUSERFORMAINTENANCE"));
		try {
			fieldNames = jdbcTemplate.queryForMap(sql.toString(), new Object[] {
					user.getUserIdentity(), "New" });
			logWriter.info("USERDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for USERDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (!fieldNames.isEmpty()) {
			users.setUserIdentity((String) fieldNames.get("USER_IDENTITY"));
			users.setUserName((String) fieldNames.get("USER_NAME"));
			users.setDisableFlage((String) fieldNames.get("DISABLE_FLAGE"));

		}
		return users;
	}

	public int rejectUser(Users user) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("REJECTUSER"));
		Integer count = 0;
		try {
			count = jdbcTemplate.update(
					sql.toString(),
					new Object[] { "Rejected", user.getChecker(),
							user.getCheckerDt(), user.getUserIdentity() });
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public int authorUser(Users item) {
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("AUTHORUSER"));
		Integer count = 0;
		try {
			if (item.getStatus().equals("New")) {
				count = jdbcTemplate.update(
						sql.toString(),
						new Object[] { item.getUserName(),
								item.getEmployeeNo(), item.getUserRole(),
								"Authorized", item.getActiveStatus(),
								item.getValidUpto(), item.getIsAdmin(),
								item.getDisableFlage(), item.getMaker(),
								item.getMakerDt(), item.getUserIdentity(), });
			} else if (item.getStatus().equals("Modified")) {
				count = updateUser(item);
				if (count == 1) {
					count = deleteUser(item);
				}
			} else if (item.getStatus().equals("Deleted")) {
				Users item2 = new Users();
				item2.setUserIdentity(item.getUserIdentity());
				item2.setStatus(item.getChecker());
				item2.setCheckerDt(item.getCheckerDt());
				count = deleteUser(item);
				count = changeStatus(item2);
			}
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}

	public List<Users> getUserDetailsForMaintenance(String userId) {
		List<Users> transObjList = new ArrayList<Users>();
		List<Map<String, Object>> fieldNames = null;
		StringBuilder sql = new StringBuilder();
		sql.append(imbcaproperties.get("GETUSERDETAILSFORAUTHOR"));
		try {
			fieldNames = jdbcTemplate.queryForList(sql.toString(),
					new Object[] { userId });

			logWriter.info("userDETAILS size:  " + fieldNames.size());
		} catch (EmptyResultDataAccessException e) {
			logWriter.info("No data found for userDETAILS account.");
		} catch (Exception e) {
			logWriter.info(e.getMessage());
		}
		if (fieldNames != null) {
			for (Map<String, Object> row : fieldNames) {
				if (!row.get("STATUS").equals("Rejected")
						&& !row.get("STATUS").equals("Deleted and Authorized")) {
					Users users = new Users();
					users.setUserIdentity((String) row.get("USER_IDENTITY"));
					users.setUserName((String) row.get("USER_NAME"));
					users.setEmployeeNo((String) row.get("EMPLOYEE_NO"));
					users.setUserRole((String) row.get("USER_ROLE"));
					users.setStatus((String) row.get("STATUS"));
					users.setActiveStatus((String) row.get("ACTIVE_STATUS"));
					users.setValidUpto((String) row.get("VALID_UPTO"));
					users.setIsAdmin((String) row.get("ISADMIN"));
					users.setDisableFlage((String) row.get("DISABLE_FLAGE"));
					users.setMaker((String) row.get("MAKER"));
					users.setMakerDt((Timestamp) row.get("MAKER_DT"));// 13
					// users.setReason((String) row.get("REASON"));
					transObjList.add(users);
				}
			}
		}
		return transObjList;
	}

	public int updateForMaintenance(Users user) {
		StringBuilder sql = new StringBuilder();

		sql.append(imbcaproperties.get("UPDATEFORMAINTENANCE"));
		Integer count = 0;
		try {

			count = jdbcTemplate.update(
					sql.toString(),
					new Object[] { user.getDisableFlage(),
							user.getUserIdentity() });
		} catch (EmptyResultDataAccessException ex) {
			logWriter.info("Insertion of Field failed..");
		} catch (Exception e) {
			logWriter.info("error" + e);
		}
		return (int) count;
	}
}
