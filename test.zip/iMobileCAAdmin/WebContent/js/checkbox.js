/*$(document).ready(function() {
	*//************* View click function ********************//*
	$('.checkbox-main').click(function() {
		 $(this).toggleClass("checked");
	});
});
*/