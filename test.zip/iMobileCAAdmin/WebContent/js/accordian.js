$(document).ready(
		function() {
			var parentDivs = $('#nestedAccordion div'), childDivs = $(
					'#nestedAccordion h3').siblings('div');
			parentDivs.slideUp();
			childDivs.slideUp();
			$('#nestedAccordion h2').click(function() {
				parentDivs.slideUp();
				if ($(this).next().is(':hidden')) {
					$(this).next().slideDown();
					$(this).removeClass('down-arrow');
					$('.accordian h2').removeClass('up-arrow');
					$('.accordian h2').addClass('down-arrow');
					$(this).addClass('up-arrow');
				} else {
					$(this).next().slideUp();
					$(this).removeClass('up-arrow');
					$(this).addClass('down-arrow');
				}
			});
			$('#nestedAccordion h3').click(function() {
				$('#nestedAccordion h3').removeClass('active');
				$(this).addClass('active');
				childDivs.slideUp();
				if ($(this).next().is(':hidden')) {
					$(this).next().slideDown();
				} else {
					$(this).next().slideUp();
				}
			});
		});
/** ************** accordion function of view and update ********************* */
$(document).ready(function() {
	var pDiv = $('.tble-row2');
	pDiv.slideUp();
	
	/************* View click function ********************/
	$('.view').click(function() {
		pDiv.slideUp();
		$('.tble').css('background', '#ffffff');
		if ($(this).parent().parent().next('.tble-row2').is(':hidden')) {
			$('.del-sec').css('display', 'none');
			$('.upd-sec').css('display', 'none');
			$(this).parent().parent().next('.tble-row2').slideDown();
			$(this).parent().parent().parent().css('background', '#f1f1f1');
			$('.read-sec').css('display', 'block');
		} else {
			$('.del-sec').css('display', 'none');
			$('.upd-sec').css('display', 'none');
			$(this).parent().parent().next('.tble-row2').slideDown();
			$(this).parent().parent().parent().css('background', '#f1f1f1');
			$('.read-sec').css('display', 'block');
			// $(this).parent().parent().next('.tble-row2').slideUp();
		}
	});
	/** *********** End of View click function ******************* */
	/** *********** Update click function ******************* */
	$('.update').click(function() {
		pDiv.slideUp();
		$('.tble').css('background', '#ffffff');
		if ($(this).parent().parent().next('.tble-row2').is(':hidden')) {
			$('.del-sec').css('display', 'none');
			$('.read-sec').css('display', 'none');
			$(this).parent().parent().next('.tble-row2').slideDown();
			$(this).parent().parent().parent().css('background', '#f1f1f1');
			$('.upd-sec').css('display', 'block');
		} else {
			$('.del-sec').css('display', 'none');
			$('.read-sec').css('display', 'none');
			$(this).parent().parent().next('.tble-row2').slideDown();
			$(this).parent().parent().parent().css('background', '#f1f1f1');
			$('.upd-sec').css('display', 'block');
			// $(this).parent().parent().next('.tble-row2').slideUp();
		}
	});

	/** *********** End of update click function ******************* */
	/** *********** Delete click function ******************* */

	$('.delete').click(function() {
		pDiv.slideUp();
		$('.tble').css('background', '#ffffff');
		if ($(this).parent().parent().next('.tble-row2').is(':hidden')) {
			$('.read-sec').css('display', 'none');
			$('.upd-sec').css('display', 'none');
			$(this).parent().parent().next('.tble-row2').slideDown();
			$(this).parent().parent().parent().css('background', '#f1f1f1');
			$('.del-sec').css('display', 'block');
		} else {
			$('.read-sec').css('display', 'none');
			$('.upd-sec').css('display', 'none');
			$(this).parent().parent().next('.tble-row2').slideDown();
			$(this).parent().parent().parent().css('background', '#f1f1f1');
			$('.del-sec').css('display', 'block');
			// $(this).parent().parent().next('.tble-row2').slideUp();
		}
	});
	/** *********** End of Delete click function ******************* */
	/** ********** cancel button across application******** */

	$('.cancel-btn').click(function() {
		$('.tble').css('background', '#ffffff');
		pDiv.slideUp();
	});
	/** ********** End of cancel button across application******** */
});
/** ************End of accordion function of view and update ***************** */
/** **************************** Check box ******************************** */
$(document).ready(function() {
	/** *********** View click function ******************* */
	$('.checkbox-main').click(function() {
		$(this).toggleClass("checked");
		$('#selectAll').removeClass('checked');
	});
	$('#selectAll').click(function() {
		/*
		 * $(this).toggleClass("checked"); if(
		 * $('.checkbox-main').hasClass('checked')){
		 * $('.checkbox-main').removeClass('checked'); }else{
		 * $('.checkbox-main').addClass('checked'); }
		 */
		if ($(this).hasClass("checked")) {
			$(this).removeClass("checked");
			$('.checkbox-main').removeClass('checked');
		} else {
			$(this).addClass("checked");
			$('.checkbox-main').addClass('checked');
		}

	});
});
/** ****************************** End of check box ************************** */

/** ********************** Update function ********************************* */

$(document).ready(function() {
	$('#bulkUpdate').click(function() {
		var checkeIds=[];
		/*var x = $('.trLength').length;
		if ($('.checkbox-main').hasClass("checked")) {
			
		}*/
		$(".checked").each(function(){
	          // alert($(this).find('.checkbox-custom').attr('id'));
			if(($(this).find('.checkbox-custom').attr != "") && ($(this).find('.checkbox-custom').attr('id')!=undefined))
				{
				/*var obj={}
				obj.id=$(this).find('.checkbox-custom').attr('id');
				obj.status=$(this).find('.checkbox-custom').attr('value');
				checkeIds.push(obj);*/
			checkeIds.push($(this).find('.checkbox-custom').attr('id'));
				}
	        });
		$('#checkedValues').val(checkeIds);
	});

});
$(document).ready(function() {
	$('#bulkApprove').click(function() {
		var checkeIds=[];
		/*var x = $('.trLength').length;
		if ($('.checkbox-main').hasClass("checked")) {
			
		}*/
		$(".checked").each(function(){
	          // alert($(this).find('.checkbox-custom').attr('id'));
			if(($(this).find('.checkbox-custom').attr != "") && ($(this).find('.checkbox-custom').attr('id')!=undefined))
				{
				/*var obj={}
				obj.id=$(this).find('.checkbox-custom').attr('id');
				obj.status=$(this).find('.checkbox-custom').attr('value');
				checkeIds.push(obj);*/
			checkeIds.push($(this).find('.checkbox-custom').attr('id')+"#"+$(this).find('.checkbox-custom').attr('value'));
				}
	        });
		$('#checkedValues').val(checkeIds);
	});

});

/** ****************** End of update function *************************** */
